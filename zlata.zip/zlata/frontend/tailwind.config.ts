import type { Config } from 'tailwindcss'

export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Vazirmatn', 'Tahoma', 'Arial', 'sans-serif'],
      },
      colors: {
        primary: {
          50:  '#eff6ff',
          100: '#dbeafe',
          200: '#bfdbfe',
          300: '#93c5fd',
          400: '#60a5fa',
          500: '#2d6a9f',
          600: '#1e3a5f',
          700: '#162d4a',
          800: '#0f1f35',
          900: '#091525',
        },
      },
      screens: {
        xs: '420px',
      },
    },
  },
  plugins: [],
} satisfies Config
