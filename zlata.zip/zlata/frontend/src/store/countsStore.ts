import { create } from 'zustand'
import { kartablApi, MeCounts } from '@/api/kartabl'

interface CountsState {
  counts: MeCounts | null
  loading: boolean
  fetch: () => Promise<void>
}

export const useCountsStore = create<CountsState>((set) => ({
  counts: null,
  loading: false,
  fetch: async () => {
    set({ loading: true })
    try {
      const { data } = await kartablApi.counts()
      set({ counts: data, loading: false })
    } catch {
      set({ loading: false })
    }
  },
}))
