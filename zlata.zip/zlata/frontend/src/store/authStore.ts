import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import { User } from '@/types/common'
import { authApi } from '@/api/auth'

interface AuthState {
  user: User | null
  isAuthenticated: boolean
  isLoading: boolean
  login: (mobile: string, password: string) => Promise<void>
  logout: () => Promise<void>
  loadMe: () => Promise<void>
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      user: null,
      isAuthenticated: false,
      isLoading: false,

      login: async (mobile, password) => {
        set({ isLoading: true })
        const { data } = await authApi.login(mobile, password)
        localStorage.setItem('access_token', data.access_token)
        localStorage.setItem('refresh_token', data.refresh_token)
        const me = await authApi.me()
        set({ user: me.data, isAuthenticated: true, isLoading: false })
      },

      logout: async () => {
        const refresh_token = localStorage.getItem('refresh_token') || ''
        try { await authApi.logout(refresh_token) } catch { /* ignore */ }
        localStorage.removeItem('access_token')
        localStorage.removeItem('refresh_token')
        set({ user: null, isAuthenticated: false })
      },

      loadMe: async () => {
        const token = localStorage.getItem('access_token')
        if (!token) { set({ isAuthenticated: false }); return }
        try {
          const me = await authApi.me()
          set({ user: me.data, isAuthenticated: true })
        } catch {
          set({ user: null, isAuthenticated: false })
        }
      },
    }),
    {
      name: 'auth-store',
      partialize: (state) => ({ isAuthenticated: state.isAuthenticated }),
    }
  )
)
