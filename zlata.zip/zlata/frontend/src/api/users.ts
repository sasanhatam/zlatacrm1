import api from './client'
import { User, Team } from '@/types/common'

export const usersApi = {
  list: (params?: { team_id?: string; is_active?: boolean; search?: string }) =>
    api.get<User[]>('/users', { params }),

  get: (id: string) => api.get<User>(`/users/${id}`),

  create: (data: Partial<User> & { password: string }) => api.post<User>('/users', data),

  update: (id: string, data: Partial<User>) => api.put<User>(`/users/${id}`, data),

  deactivate: (id: string) => api.delete(`/users/${id}`),

  permanentDelete: (id: string) => api.delete(`/users/${id}/permanent`),

  updateMyProfile: (data: Partial<User>) => api.put<User>('/users/me/profile', data),

  uploadAvatar: (file: File) => {
    const form = new FormData()
    form.append('file', file)
    return api.post('/users/me/avatar', form, { headers: { 'Content-Type': 'multipart/form-data' } })
  },

  resetPassword: (userId: string, new_password: string) =>
    api.post(`/users/${userId}/reset-password`, null, { params: { new_password } }),

  // Teams
  listTeams: () => api.get<Team[]>('/teams'),
  getTeam: (id: string) => api.get<Team>(`/teams/${id}`),
  createTeam: (data: Partial<Team>) => api.post<Team>('/teams', data),
  updateTeam: (id: string, data: Partial<Team>) => api.put<Team>(`/teams/${id}`, data),
  getTeamMembers: (id: string) => api.get<User[]>(`/teams/${id}/members`),

  // Phonebook
  phonebook: (params?: { team_id?: string; search?: string }) =>
    api.get('/phonebook', { params }),
}
