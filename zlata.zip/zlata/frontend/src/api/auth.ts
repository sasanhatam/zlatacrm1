import api from './client'
import { User } from '@/types/common'

export const authApi = {
  login: (mobile: string, password: string) =>
    api.post<{ access_token: string; refresh_token: string; expires_in: number }>(
      '/auth/login', { mobile, password }
    ),

  logout: (refresh_token: string) =>
    api.post('/auth/logout', { refresh_token }),

  me: () => api.get<User>('/auth/me'),

  changePassword: (current_password: string, new_password: string) =>
    api.post('/auth/change-password', { current_password, new_password }),

  registerRequest: (full_name: string, mobile: string, password: string, organization_ids: string[] = []) =>
    api.post('/auth/register-request', { full_name, mobile, password, organization_ids }),

  listCompaniesPublic: () =>
    api.get<{ id: string; name: string }[]>('/auth/companies-public'),

  listRegisterRequests: (status = 'pending') =>
    api.get('/auth/register-requests', { params: { status } }),

  approveRegisterRequest: (id: string) =>
    api.post(`/auth/register-requests/${id}/approve`),

  rejectRegisterRequest: (id: string, reason?: string) =>
    api.post(`/auth/register-requests/${id}/reject`, { reason }),
}
