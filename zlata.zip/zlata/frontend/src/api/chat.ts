import api from './client'
import { ChatRoom, Message } from '@/types/chat'

export const chatApi = {
  listRooms: () => api.get<ChatRoom[]>('/chat/rooms'),

  createRoom: (data: { name?: string; type: string; member_ids: string[] }) =>
    api.post<ChatRoom>('/chat/rooms', data),

  getMessages: (roomId: string, params?: { before?: string; limit?: number }) =>
    api.get<Message[]>(`/chat/rooms/${roomId}/messages`, { params }),

  sendMessage: (roomId: string, data: { content?: string; file_id?: string; mentioned_user_ids?: string[] }) =>
    api.post<Message>(`/chat/rooms/${roomId}/messages`, data),

  uploadFile: (roomId: string, file: File) => {
    const form = new FormData()
    form.append('file', file)
    return api.post(`/chat/rooms/${roomId}/files`, form, {
      headers: { 'Content-Type': 'multipart/form-data' }
    })
  },

  markRead: (roomId: string) => api.post(`/chat/rooms/${roomId}/read`),
}
