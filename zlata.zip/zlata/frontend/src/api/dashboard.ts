import api from './client'

export const dashboardApi = {
  overview: (params?: { team_id?: string; user_id?: string; from_date?: string; to_date?: string }) =>
    api.get('/dashboard/overview', { params }),

  userPerformance: (params?: { team_id?: string; from_date?: string; to_date?: string }) =>
    api.get('/dashboard/user-performance', { params }),

  staleTasks: (days?: number) =>
    api.get('/dashboard/stale-tasks', { params: { days } }),

  exportExcel: (params?: { team_id?: string; from_date?: string; to_date?: string }) =>
    api.get('/dashboard/export/excel', { params, responseType: 'blob' }),
}
