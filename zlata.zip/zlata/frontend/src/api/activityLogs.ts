import api from './client'

export interface ActivityLog {
  id: string
  user_id: string | null
  user_name: string
  user_mobile: string
  action: string
  resource_type: string
  resource_id: string
  resource_title: string
  details: Record<string, unknown>
  ip_address: string
  jalali_datetime: string
  created_at: string
}

export interface ActivityLogsResponse {
  total: number
  page: number
  limit: number
  items: ActivityLog[]
}

export interface ActivityLogUser {
  id: string
  full_name: string
  mobile: string
}

export const activityLogsApi = {
  list: (params?: { action?: string; resource_type?: string; user_id?: string; from_date?: string; to_date?: string; page?: number; limit?: number }) =>
    api.get<ActivityLogsResponse>('/activity-logs', { params }),
  listUsers: () => api.get<ActivityLogUser[]>('/activity-logs/users'),
}
