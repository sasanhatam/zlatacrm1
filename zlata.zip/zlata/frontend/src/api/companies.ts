import api from './client'
import { Company } from '@/types/common'

export const companiesApi = {
  list: () => api.get<Company[]>('/companies'),
  get: (id: string) => api.get<Company>(`/companies/${id}`),
  create: (data: Partial<Company>) => api.post<Company>('/companies', data),
  update: (id: string, data: Partial<Company>) => api.put<Company>(`/companies/${id}`, data),
  getUsers: (id: string) => api.get<any[]>(`/companies/${id}/users`),
  addUser: (orgId: string, userId: string) => api.post(`/companies/${orgId}/users/${userId}`),
  removeUser: (orgId: string, userId: string) => api.delete(`/companies/${orgId}/users/${userId}`),
  uploadLetterheadHeader: (id: string, file: File) => {
    const fd = new FormData()
    fd.append('file', file)
    return api.post(`/companies/${id}/letterhead/header`, fd, { headers: { 'Content-Type': 'multipart/form-data' } })
  },
  uploadLetterheadFooter: (id: string, file: File) => {
    const fd = new FormData()
    fd.append('file', file)
    return api.post(`/companies/${id}/letterhead/footer`, fd, { headers: { 'Content-Type': 'multipart/form-data' } })
  },
  deleteLetterheadHeader: (id: string) => api.delete(`/companies/${id}/letterhead/header`),
  deleteLetterheadFooter: (id: string) => api.delete(`/companies/${id}/letterhead/footer`),
}
