import api from './client'

export type LeaveType = 'annual' | 'sick' | 'maternity' | 'emergency' | 'unpaid' | 'hourly'
export type LeaveStatus = 'pending' | 'approved' | 'rejected' | 'cancelled'

export interface LeaveRequest {
  id: string
  user_id: string
  user_name?: string
  leave_type: LeaveType
  status: LeaveStatus
  start_date: string
  end_date: string
  days_count: number
  reason?: string
  manager_note?: string
  reviewed_by?: string
  reviewed_at?: string
  created_at: string
}

export interface LeaveBalance {
  id: string
  user_id: string
  year: number
  annual_total: number
  annual_used: number
  sick_used: number
  remaining: number
}

export const leavesApi = {
  request: (data: Partial<LeaveRequest>) => api.post<LeaveRequest>('/leaves', data),
  list: (params?: { user_id?: string; status?: LeaveStatus }) =>
    api.get<LeaveRequest[]>('/leaves', { params }),
  get: (id: string) => api.get<LeaveRequest>(`/leaves/${id}`),
  teamLeaves: () => api.get<LeaveRequest[]>('/leaves/team'),
  balance: () => api.get<LeaveBalance>('/leaves/balance'),
  review: (id: string, approved: boolean, note?: string) =>
    api.post<LeaveRequest>(`/leaves/${id}/review`, { approved, note }),
  cancel: (id: string) => api.delete(`/leaves/${id}`),
}
