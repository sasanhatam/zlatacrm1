import api from './client'

export type LetterType = 'outgoing' | 'incoming' | 'internal'
export type LetterStatus = 'draft' | 'pending' | 'approved' | 'sent' | 'archived' | 'rejected'
export type LetterPriority = 'normal' | 'urgent' | 'very_urgent' | 'confidential'
export type ReferralAction = 'for_action' | 'for_info' | 'for_response' | 'for_review' | 'for_archive'

export interface Letter {
  id: string
  letter_number: string
  letter_type: LetterType
  status: LetterStatus
  priority: LetterPriority
  subject: string
  body: string
  sender_id: string
  recipient_name: string
  recipient_user_id?: string
  cc_user_ids: string[]
  signer_id?: string
  additional_signer_ids?: string[]
  requester_id?: string
  actor_id?: string
  dispatcher_id?: string
  organization_id?: string
  signed_at?: string
  approved_by?: string
  approved_at?: string
  rejection_reason?: string
  reply_to_id?: string
  jalali_date: string
  letter_date?: string
  referral_ids: string[]
  archive_code?: string
  created_at: string
  updated_at: string
  is_referred?: boolean
}

export interface LetterReferral {
  id: string
  letter_id: string
  from_user_id: string
  from_user_name: string
  to_user_id: string
  to_user_name: string
  action: ReferralAction
  note?: string
  deadline?: string
  is_read: boolean
  read_at?: string
  created_at: string
}

export const lettersApi = {
  create: (data: Partial<Letter>) => api.post<Letter>('/letters', data),
  list: (params?: { letter_type?: LetterType; status?: LetterStatus; skip?: number; limit?: number }) =>
    api.get<Letter[]>('/letters', { params }),
  get: (id: string) => api.get<Letter>(`/letters/${id}`),
  update: (id: string, data: Partial<Letter>) => api.put<Letter>(`/letters/${id}`, data),
  delete: (id: string) => api.delete(`/letters/${id}`),

  // کارتابل
  inbox: () => api.get<Letter[]>('/letters/inbox'),
  outbox: () => api.get<Letter[]>('/letters/outbox'),
  drafts: () => api.get<Letter[]>('/letters/drafts'),
  pendingApproval: () => api.get<Letter[]>('/letters/pending-approval'),

  // جریان کاری
  submit: (id: string) => api.post<Letter>(`/letters/${id}/submit`),
  approve: (id: string) => api.post<Letter>(`/letters/${id}/approve`),
  reject: (id: string, reason?: string) =>
    api.post<Letter>(`/letters/${id}/reject`, { reason }),
  send: (id: string) => api.post<Letter>(`/letters/${id}/send`),
  archive: (id: string) => api.post<Letter>(`/letters/${id}/archive`),

  // ارجاع
  refer: (id: string, data: { to_user_id: string; action: ReferralAction; note?: string; deadline?: string }) =>
    api.post(`/letters/${id}/refer`, data),
  getReferrals: (id: string) => api.get<LetterReferral[]>(`/letters/${id}/referrals`),
  markReferralRead: (letterId: string, referralId: string) =>
    api.post(`/letters/${letterId}/referrals/${referralId}/read`),

  // نظرات
  getComments: (id: string) => api.get(`/letters/${id}/comments`),
  addComment: (id: string, content: string, is_private = false) =>
    api.post(`/letters/${id}/comments`, { content, is_private }),

  // پاسخ
  reply: (id: string, data: Partial<Letter>) => api.post<Letter>(`/letters/${id}/reply`, data),
}
