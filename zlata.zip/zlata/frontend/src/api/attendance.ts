import api from './client'

export interface AttendanceRecord {
  id: string
  user_id: string
  user_name: string
  user_mobile?: string
  work_date: string
  jalali_date: string
  clock_in: string | null
  clock_out: string | null
  duration_minutes: number | null
  note: string | null
  is_active: boolean
}

export interface TodayStatus {
  today: string
  records: AttendanceRecord[]
  is_clocked_in: boolean
  active_record: AttendanceRecord | null
  total_minutes_today: number
}

export interface AttendanceReport {
  items: AttendanceRecord[]
  summary: {
    user_id: string
    user_name: string
    user_mobile: string
    days_present: number
    total_minutes: number
  }[]
}

export const attendanceApi = {
  clockIn: (note?: string) => api.post<AttendanceRecord>('/attendance/clock-in', { note }),
  clockOut: (note?: string) => api.post<AttendanceRecord>('/attendance/clock-out', { note }),
  today: () => api.get<TodayStatus>('/attendance/today'),
  myRecords: (params?: { from_date?: string; to_date?: string; page?: number }) =>
    api.get<{ total: number; page: number; items: AttendanceRecord[] }>('/attendance/my', { params }),
  report: (params?: { from_date?: string; to_date?: string; user_id?: string }) =>
    api.get<AttendanceReport>('/attendance/report', { params }),
  usersList: () => api.get<{ id: string; full_name: string; mobile: string }[]>('/attendance/users-list'),
}
