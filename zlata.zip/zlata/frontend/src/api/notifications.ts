import api from './client'
import { Notification, Announcement } from '@/types/chat'

export const notificationsApi = {
  list: (params?: { is_read?: boolean; limit?: number }) =>
    api.get<Notification[]>('/notifications', { params }),

  unreadCount: () => api.get<{ count: number }>('/notifications/unread-count'),

  markRead: (id: string) => api.post(`/notifications/mark-read/${id}`),

  markAllRead: () => api.post('/notifications/mark-all-read'),

  listAnnouncements: () => api.get<Announcement[]>('/notifications/announcements'),

  createAnnouncement: (data: Partial<Announcement> & { target_team_ids?: string[] }) =>
    api.post('/notifications/announcements', data),

  subscribePush: (subscription: { endpoint: string; p256dh: string; auth: string }) =>
    api.post('/notifications/push/subscribe', subscription),
}
