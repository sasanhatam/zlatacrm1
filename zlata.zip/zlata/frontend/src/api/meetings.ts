import api from './client'

export type MeetingStatus = 'scheduled' | 'in_progress' | 'completed' | 'cancelled'
export type MeetingType = 'in_person' | 'online' | 'hybrid'
export type AttendeeStatus = 'pending' | 'accepted' | 'declined' | 'tentative'

export interface Attendee {
  user_id: string
  status: AttendeeStatus
  full_name?: string
  position?: string
}

export interface ProposedTime {
  user_id: string
  start_time: string
  end_time: string
  note?: string
  proposed_at: string
}

export interface Meeting {
  id: string
  title: string
  description?: string
  meeting_type: MeetingType
  status: MeetingStatus
  organizer_id: string
  team_id?: string
  is_all_org: boolean
  attendees: Attendee[]
  proposed_times: ProposedTime[]
  start_time: string
  end_time: string
  location?: string
  online_link?: string
  agenda?: string
  minutes_id?: string
  created_at: string
  updated_at: string
}

export interface MeetingMinutes {
  id: string
  meeting_id: string
  content: string
  written_by: string
  action_items: Array<{ task: string; responsible: string; deadline?: string }>
  approved_by?: string
  created_at: string
}

export const meetingsApi = {
  create: (data: Partial<Meeting> & { attendee_ids?: string[] }) =>
    api.post<Meeting>('/meetings', data),
  list: (params?: { upcoming?: boolean; team_id?: string }) =>
    api.get<Meeting[]>('/meetings', { params }),
  get: (id: string) => api.get<Meeting>(`/meetings/${id}`),
  update: (id: string, data: Partial<Meeting>) => api.put<Meeting>(`/meetings/${id}`, data),
  cancel: (id: string) => api.delete(`/meetings/${id}`),
  respond: (id: string, status: AttendeeStatus) =>
    api.post(`/meetings/${id}/respond`, null, { params: { status } }),
  proposeTime: (id: string, data: { start_time: string; end_time: string; note?: string }) =>
    api.post(`/meetings/${id}/propose-time`, data),
  acceptProposedTime: (id: string, user_id: string) =>
    api.post(`/meetings/${id}/accept-proposed-time`, { user_id }),
  createMinutes: (id: string, data: Partial<MeetingMinutes>) =>
    api.post(`/meetings/${id}/minutes`, data),
  getMinutes: (id: string) => api.get<MeetingMinutes>(`/meetings/${id}/minutes`),
}
