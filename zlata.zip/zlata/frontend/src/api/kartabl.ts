import api from './client'

export interface KartablItem {
  id: string
  item_type: 'task' | 'letter' | 'referral'
  title: string
  priority: string
  status: string
  date: string
  jalali_date: string
  is_read: boolean
  sender_name: string
  due_date?: string
  is_overdue: boolean
  company_id?: string
  letter_id?: string
}

export interface KartablCounts {
  total: number
  tasks: number
  letters: number
  referrals: number
  unread: number
  overdue: number
}

export interface KartablResponse {
  items: KartablItem[]
  counts: KartablCounts
}

export interface MeCounts {
  kartabl_pending: number
  kartabl_unread: number
  letters_inbox: number
  letters_referrals: number
  tasks_overdue: number
  tasks_pending: number
}

export interface SearchResult {
  tasks: Array<{ id: string; title: string; status: string; priority: string }>
  letters: Array<{ id: string; subject: string; letter_number: string; status: string }>
  users: Array<{ id: string; full_name: string; email: string; role: string }>
}

export const kartablApi = {
  list: (params?: {
    type?: string
    sort?: string
    status?: string
    company_id?: string
  }) => api.get<KartablResponse>('/kartabl', { params }),
  search: (q: string, limit = 20) =>
    api.get<SearchResult>('/kartabl/search', { params: { q, limit } }),
  counts: () => api.get<MeCounts>('/kartabl/counts'),
}
