import api from './client'
import { Task, SubTask, TaskComment, AuditLog, TaskStatus, TaskPriority } from '@/types/task'
import { PaginatedResponse } from '@/types/common'

export interface TaskFilters {
  team_id?: string
  assignee_id?: string
  status?: TaskStatus
  priority?: TaskPriority
  search?: string
  page?: number
  page_size?: number
}

export const tasksApi = {
  list: (filters: TaskFilters = {}) =>
    api.get<PaginatedResponse<Task>>('/tasks', { params: filters }),

  get: (id: string) => api.get<Task>(`/tasks/${id}`),

  create: (data: Partial<Task>) => api.post<Task>('/tasks', data),

  update: (id: string, data: Partial<Task>) => api.put<Task>(`/tasks/${id}`, data),

  delete: (id: string) => api.delete(`/tasks/${id}`),

  // Subtasks
  getSubtasks: (taskId: string) => api.get<SubTask[]>(`/tasks/${taskId}/subtasks`),
  createSubtask: (taskId: string, data: Partial<SubTask>) =>
    api.post<SubTask>(`/tasks/${taskId}/subtasks`, data),
  updateSubtask: (taskId: string, subId: string, data: Partial<SubTask>) =>
    api.put<SubTask>(`/tasks/${taskId}/subtasks/${subId}`, data),

  // Comments
  getComments: (taskId: string) => api.get<TaskComment[]>(`/tasks/${taskId}/comments`),
  addComment: (taskId: string, content: string, mentioned_user_ids: string[] = []) =>
    api.post<TaskComment>(`/tasks/${taskId}/comments`, { content, mentioned_user_ids }),

  // Audit log
  getAuditLog: (taskId: string) => api.get<AuditLog[]>(`/tasks/${taskId}/audit-log`),

  // Files
  uploadFile: (taskId: string, file: File) => {
    const form = new FormData()
    form.append('file', file)
    return api.post(`/tasks/${taskId}/files`, form, {
      headers: { 'Content-Type': 'multipart/form-data' }
    })
  },

  // Checklist
  updateChecklist: (taskId: string, checklist: Array<{ text: string; is_done: boolean }>) =>
    api.patch(`/tasks/${taskId}/checklist`, checklist),

  // Referral
  refer: (taskId: string, data: {
    to_user_id?: string
    to_team_id?: string
    to_manager?: boolean
    note?: string
    due_date?: string
    file_ids?: string[]
  }) => api.post(`/tasks/${taskId}/refer`, data),
  getReferrals: (taskId: string) => api.get(`/tasks/${taskId}/referrals`),

  // Overdue summary (for managers)
  overdueSummary: () => api.get('/tasks/overdue/summary'),
}
