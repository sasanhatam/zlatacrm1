// در dev (و وقتی روی همان دامنه با nginx پراکسی می‌شود) این مقدار خالی است
// و آدرس‌ها نسبی (/api/...) خواهند بود. در دیپلوی Netlify باید آدرس کامل
// بک‌اند (مثلاً https://api.yourdomain.com) را در VITE_API_BASE_URL ست کنید.
export const API_BASE_URL = (import.meta.env.VITE_API_BASE_URL || '').replace(/\/$/, '')

export function apiUrl(path: string): string {
  return `${API_BASE_URL}${path}`
}
