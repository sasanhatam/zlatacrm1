import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { Toaster } from 'react-hot-toast'
import { Suspense, lazy } from 'react'
import { AppLayout } from '@/components/layout/AppLayout'

const Login = lazy(() => import('@/pages/Login'))
const Dashboard = lazy(() => import('@/pages/Dashboard'))
const Tasks = lazy(() => import('@/pages/Tasks'))
const TaskDetail = lazy(() => import('@/pages/TaskDetail'))
const Chat = lazy(() => import('@/pages/Chat'))
const Notifications = lazy(() => import('@/pages/Notifications'))
const Letters = lazy(() => import('@/pages/Letters'))
const Inbox = lazy(() => import('@/pages/Inbox'))
const Outbox = lazy(() => import('@/pages/Outbox'))
const Meetings = lazy(() => import('@/pages/Meetings'))
const Leaves = lazy(() => import('@/pages/Leaves'))
const Phonebook = lazy(() => import('@/pages/Phonebook'))
const Profile = lazy(() => import('@/pages/Profile'))
const UserManagement = lazy(() => import('@/pages/admin/UserManagement'))
const SystemSettings = lazy(() => import('@/pages/admin/SystemSettings'))
const Companies = lazy(() => import('@/pages/admin/Companies'))
const ActivityLogs = lazy(() => import('@/pages/admin/ActivityLogs'))
const Attendance = lazy(() => import('@/pages/Attendance'))
const AttendanceReport = lazy(() => import('@/pages/admin/AttendanceReport'))
const Kartabl = lazy(() => import('@/pages/Kartabl'))
const SEO = lazy(() => import('@/pages/SEO'))

function LoadingFallback() {
  return (
    <div className="flex items-center justify-center h-full min-h-[200px]">
      <div className="w-8 h-8 border-4 border-primary-500 border-t-transparent rounded-full animate-spin" />
    </div>
  )
}

export default function App() {
  return (
    <BrowserRouter>
      <Toaster
        position="top-center"
        toastOptions={{
          style: { fontFamily: 'Vazirmatn, Tahoma, sans-serif', direction: 'rtl', textAlign: 'right' },
          duration: 4000,
        }}
      />
      <Suspense fallback={<LoadingFallback />}>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/" element={<AppLayout />}>
            <Route index element={<Dashboard />} />
            <Route path="tasks" element={<Tasks />} />
            <Route path="tasks/:id" element={<TaskDetail />} />
            <Route path="chat" element={<Chat />} />
            <Route path="notifications" element={<Notifications />} />
            <Route path="letters" element={<Letters />} />
            <Route path="inbox" element={<Inbox />} />
            <Route path="outbox" element={<Outbox />} />
            <Route path="meetings" element={<Meetings />} />
            <Route path="leaves" element={<Leaves />} />
            <Route path="phonebook" element={<Phonebook />} />
            <Route path="profile" element={<Profile />} />
            <Route path="kartabl" element={<Kartabl />} />
            <Route path="seo" element={<SEO />} />
            <Route path="seo/:id" element={<SEO />} />
            <Route path="admin/users" element={<UserManagement />} />
            <Route path="admin/settings" element={<SystemSettings />} />
            <Route path="admin/companies" element={<Companies />} />
            <Route path="admin/activity-logs" element={<ActivityLogs />} />
            <Route path="attendance" element={<Attendance />} />
            <Route path="admin/attendance" element={<AttendanceReport />} />
          </Route>
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Suspense>
    </BrowserRouter>
  )
}
