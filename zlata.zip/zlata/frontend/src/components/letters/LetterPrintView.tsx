import { useEffect, useRef } from 'react'
import { X, Printer } from 'lucide-react'
import type { ReactNode } from 'react'

interface Letterhead {
  org_name: string
  org_name_en: string
  address: string
  phone: string
  fax: string
  postal_code: string
  website: string
  email: string
  reg_number: string
  logo_data: string | null
  stamp_data: string | null
  footer_text: string
  color: string
  secondary_color: string
  letterhead_header_data?: string | null
  letterhead_footer_data?: string | null
}

interface PrintLetter {
  id: string
  letter_number: string
  letter_type: string
  status: string
  priority: string
  subject: string
  body: string
  jalali_date: string
  letter_date: string
  recipient_name: string
  recipient_organization: string
  recipient_department: string
  sender_name: string
  sender_position: string
  sender_signature: string | null
  signer_name: string
  signer_position: string
  signer_signature: string | null
  signer_stamp: string | null
  additional_signers?: { id: string; full_name: string; position: string; signature: string | null; stamp: string | null }[]
  is_stamped: boolean
  stamped_by_name: string
  archive_code: string | null
}

interface Props {
  letter: PrintLetter
  letterhead: Letterhead
  onClose: () => void
  extraActions?: ReactNode
}

const TYPE_LABELS: Record<string, string> = {
  outgoing: 'صادره',
  incoming: 'وارده',
  internal: 'داخلی',
}

const PRIORITY_LABELS: Record<string, string> = {
  normal: 'عادی',
  urgent: 'فوری',
  very_urgent: 'خیلی فوری',
  confidential: 'محرمانه',
}

export default function LetterPrintView({ letter, letterhead, onClose, extraActions }: Props) {
  const printRef = useRef<HTMLDivElement>(null)

  const color = letterhead.color || '#1e3a5f'
  const secondaryColor = letterhead.secondary_color || '#2d6a9f'

  const handlePrint = () => {
    const printContent = printRef.current?.innerHTML
    if (!printContent) return
    const win = window.open('', '_blank')
    if (!win) return
    win.document.write(`
      <!DOCTYPE html>
      <html dir="rtl" lang="fa">
      <head>
        <meta charset="UTF-8">
        <title>${letter.subject}</title>
        <style>
          @import url('https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;500;600;700&display=swap');
          * { box-sizing: border-box; margin: 0; padding: 0; }
          body {
            font-family: 'Vazirmatn', Tahoma, Arial, sans-serif;
            direction: rtl;
            background: white;
            print-color-adjust: exact;
            -webkit-print-color-adjust: exact;
          }
          .page {
            width: 210mm;
            min-height: 297mm;
            margin: 0 auto;
            background: white;
            position: relative;
            display: flex;
            flex-direction: column;
          }
          .page-header-img {
            width: 100%;
            display: block;
            margin: 0;
            padding: 0;
          }
          .page-footer-img {
            width: 100%;
            display: block;
            margin: 0;
            padding: 0;
            margin-top: auto;
          }
          .page-content {
            flex: 1;
            padding: 10mm 20mm 12mm 20mm;
            display: flex;
            flex-direction: column;
          }
          .page-content-no-img {
            flex: 1;
            padding: 15mm 20mm 20mm 20mm;
            display: flex;
            flex-direction: column;
          }
          .page-header-img, .page-footer-img {
            width: 100% !important;
            display: block !important;
            margin: 0 !important;
            padding: 0 !important;
          }
          .page-content {
            flex: 1;
            padding: 10mm 20mm 12mm 20mm;
            display: flex;
            flex-direction: column;
          }
          .page-content-no-img {
            flex: 1;
            padding: 15mm 20mm 20mm 20mm;
            display: flex;
            flex-direction: column;
          }
          .lh-header {
            display: flex;
            align-items: center;
            border-bottom: 3px solid ${color};
            padding-bottom: 12px;
            margin-bottom: 12px;
          }
          .lh-logo { width: 80px; height: 80px; object-fit: contain; margin-left: 16px; flex-shrink: 0; }
          .lh-center { flex: 1; text-align: center; }
          .lh-org-name { font-size: 20pt; font-weight: 700; color: ${color}; }
          .lh-org-name-en { font-size: 9pt; color: ${secondaryColor}; margin-top: 3px; direction: ltr; }
          .lh-info { display: flex; gap: 24px; font-size: 7.5pt; color: #555; margin-top: 8px; justify-content: center; flex-wrap: wrap; }
          .lh-info span::before { content: '| '; color: ${color}; }
          .lh-info span:first-child::before { content: ''; }
          .letter-meta {
            background: #f8f9fa;
            border: 1px solid #ddd;
            border-right: 4px solid ${color};
            padding: 10px 14px;
            margin-bottom: 14px;
            display: grid;
            grid-template-columns: 1fr 1fr 1fr;
            gap: 6px 16px;
            font-size: 8.5pt;
          }
          .meta-item { display: flex; gap: 6px; align-items: center; }
          .meta-label { color: ${color}; font-weight: 600; }
          .meta-value { color: #222; }
          .priority-badge {
            display: inline-block;
            padding: 1px 8px;
            border-radius: 10px;
            font-size: 7.5pt;
            font-weight: 600;
            background: ${letter.priority === 'urgent' ? '#fef3c7' : letter.priority === 'very_urgent' ? '#fee2e2' : letter.priority === 'confidential' ? '#ede9fe' : '#f3f4f6'};
            color: ${letter.priority === 'urgent' ? '#92400e' : letter.priority === 'very_urgent' ? '#991b1b' : letter.priority === 'confidential' ? '#5b21b6' : '#374151'};
          }
          .recipient-box {
            border: 1px solid #e5e7eb;
            padding: 10px 14px;
            margin-bottom: 14px;
            font-size: 9pt;
          }
          .recipient-title { font-weight: 600; color: ${color}; margin-bottom: 6px; font-size: 9pt; }
          .subject-line {
            font-size: 12pt;
            font-weight: 700;
            color: #111;
            margin-bottom: 16px;
            padding-bottom: 8px;
            border-bottom: 1px dashed #ccc;
          }
          .subject-label { color: ${color}; margin-left: 8px; }
          .letter-body {
            flex: 1;
            font-size: 10pt;
            line-height: 2.2;
            color: #1a1a1a;
            text-align: justify;
          }
          .letter-body p { margin: 0.3em 0; }
          .letter-body h1 { font-size: 1.6em; font-weight: 700; margin: 0.5em 0; }
          .letter-body h2 { font-size: 1.3em; font-weight: 700; margin: 0.5em 0; }
          .letter-body h3 { font-size: 1.1em; font-weight: 600; margin: 0.5em 0; }
          .letter-body ul { list-style: disc; padding-right: 1.5em; margin: 0.4em 0; }
          .letter-body ol { list-style: decimal; padding-right: 1.5em; margin: 0.4em 0; }
          .letter-body li { margin: 0.2em 0; }
          .letter-body table { border-collapse: collapse; width: 100%; max-width: 100%; table-layout: fixed; margin: 0.6em 0; }
          .letter-body td, .letter-body th { border: 1px solid #ccc; padding: 6px 10px; word-break: break-word; overflow-wrap: break-word; white-space: normal; min-width: 0; }
          .letter-body th { background: #f3f4f6; font-weight: 600; }
          .letter-body a { color: #1d4ed8; text-decoration: underline; }
          .letter-body mark { border-radius: 2px; padding: 0 2px; }
          .signature-area {
            margin-top: 40px;
            display: flex;
            justify-content: flex-left;
            align-items: flex-end;
            gap: 60px;
          }
          .sig-block { text-align: center; min-width: 140px; }
          .sig-label { font-size: 8pt; color: #666; margin-bottom: 4px; }
          .sig-name { font-size: 9pt; font-weight: 600; color: #222; margin-top: 8px; }
          .sig-position { font-size: 7.5pt; color: #888; }
          .sig-img { height: 60px; max-width: 160px; object-fit: contain; display: block; margin: 0 auto; }
          .sig-line { border-top: 1px solid #999; width: 140px; margin: 4px auto 0; }
          .stamp-area { position: absolute; bottom: 60mm; left: 25mm; }
          .stamp-img { height: 100px; width: 100px; object-fit: contain; opacity: 0.85; }
          .footer {
            border-top: 2px solid ${color};
            padding-top: 8px;
            margin-top: 20px;
            font-size: 7pt;
            color: #888;
            text-align: center;
          }
          @media print {
            body { margin: 0; }
            .page { margin: 0; page-break-after: always; }
          }
        </style>
      </head>
      <body>
        ${printContent}
      </body>
      </html>
    `)
    // Images are embedded as base64 in the DOM, no extra work needed
    win.document.close()
    setTimeout(() => { win.focus(); win.print() }, 500)
  }

  return (
    <div className="fixed inset-0 z-50 bg-black/60 overflow-auto" dir="rtl">
      {/* Toolbar */}
      <div className="sticky top-0 z-10 bg-gray-900 text-white flex items-center justify-between px-6 py-3 gap-4 print:hidden">
        <div className="flex items-center gap-3 flex-wrap">
          <button onClick={handlePrint} className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-lg text-sm font-medium transition-colors">
            <Printer size={16} />
            پرینت / ذخیره PDF
          </button>
          {extraActions}
          <span className="text-gray-400 text-sm hidden md:inline">برای ذخیره PDF: مقصد پرینت را "Save as PDF" انتخاب کنید</span>
        </div>
        <button onClick={onClose} className="p-2 hover:bg-gray-700 rounded-lg transition-colors">
          <X size={20} />
        </button>
      </div>

      {/* A4 Preview */}
      <div className="flex justify-center py-8">
        <div
          ref={printRef}
          className="page"
          style={{
            width: '210mm',
            minHeight: '297mm',
            background: 'white',
            boxShadow: '0 4px 32px rgba(0,0,0,0.3)',
            fontFamily: "'Vazirmatn', Tahoma, Arial, sans-serif",
            direction: 'rtl',
            position: 'relative',
            display: 'flex',
            flexDirection: 'column',
          }}
        >
          {/* Full-width header image — zero margin/padding */}
          {letterhead.letterhead_header_data && (
            <img
              src={letterhead.letterhead_header_data}
              alt="letterhead header"
              className="page-header-img"
              style={{ width: '100%', display: 'block', margin: 0, padding: 0 }}
            />
          )}

          {/* Content wrapper — padded */}
          <div
            className={letterhead.letterhead_header_data ? 'page-content' : 'page-content-no-img'}
            style={{
              flex: 1,
              padding: letterhead.letterhead_header_data ? '10mm 20mm 12mm 20mm' : '15mm 20mm 20mm 20mm',
              display: 'flex',
              flexDirection: 'column',
            }}
          >

          {/* Text Letterhead (only when no image header) */}
          {!letterhead.letterhead_header_data && (
            <div style={{ display: 'flex', alignItems: 'center', borderBottom: `3px solid ${color}`, paddingBottom: '12px', marginBottom: '12px' }}>
              {letterhead.logo_data && (
                <img src={letterhead.logo_data} alt="logo" style={{ width: 80, height: 80, objectFit: 'contain', marginLeft: 16, flexShrink: 0 }} />
              )}
              <div style={{ flex: 1, textAlign: 'center' }}>
                <div style={{ fontSize: '20pt', fontWeight: 700, color }}>{letterhead.org_name || 'نام سازمان'}</div>
                {letterhead.org_name_en && (
                  <div style={{ fontSize: '9pt', color: secondaryColor, marginTop: 3, direction: 'ltr' }}>{letterhead.org_name_en}</div>
                )}
                <div style={{ display: 'flex', gap: 24, fontSize: '7.5pt', color: '#555', marginTop: 8, justifyContent: 'center', flexWrap: 'wrap' }}>
                  {letterhead.address && <span>📍 {letterhead.address}</span>}
                  {letterhead.phone && <span>☎ {letterhead.phone}</span>}
                  {letterhead.fax && <span>📠 {letterhead.fax}</span>}
                  {letterhead.website && <span>🌐 {letterhead.website}</span>}
                  {letterhead.email && <span>✉ {letterhead.email}</span>}
                  {letterhead.postal_code && <span>کد پستی: {letterhead.postal_code}</span>}
                </div>
              </div>
            </div>
          )}

          {/* Letter Meta */}
          <div style={{
            background: '#f8f9fa',
            border: '1px solid #ddd',
            borderRight: `4px solid ${color}`,
            padding: '10px 14px',
            marginBottom: 14,
            display: 'grid',
            gridTemplateColumns: '1fr 1fr 1fr',
            gap: '6px 16px',
            fontSize: '8.5pt',
          }}>
            <div style={{ display: 'flex', gap: 6 }}>
              <span style={{ color, fontWeight: 600 }}>شماره نامه:</span>
              <span style={{ color: '#222', direction: 'ltr' }}>{letter.letter_number || '---'}</span>
            </div>
            <div style={{ display: 'flex', gap: 6 }}>
              <span style={{ color, fontWeight: 600 }}>تاریخ:</span>
              <span>{letter.jalali_date || '---'}</span>
            </div>
            <div style={{ display: 'flex', gap: 6 }}>
              <span style={{ color, fontWeight: 600 }}>نوع:</span>
              <span>{TYPE_LABELS[letter.letter_type] || letter.letter_type}</span>
            </div>
            <div style={{ display: 'flex', gap: 6 }}>
              <span style={{ color, fontWeight: 600 }}>اولویت:</span>
              <span style={{
                display: 'inline-block',
                padding: '1px 8px',
                borderRadius: 10,
                fontSize: '7.5pt',
                fontWeight: 600,
                background: letter.priority === 'urgent' ? '#fef3c7' : letter.priority === 'very_urgent' ? '#fee2e2' : letter.priority === 'confidential' ? '#ede9fe' : '#f3f4f6',
                color: letter.priority === 'urgent' ? '#92400e' : letter.priority === 'very_urgent' ? '#991b1b' : letter.priority === 'confidential' ? '#5b21b6' : '#374151',
              }}>
                {PRIORITY_LABELS[letter.priority] || letter.priority}
              </span>
            </div>
            {letter.archive_code && (
              <div style={{ display: 'flex', gap: 6 }}>
                <span style={{ color, fontWeight: 600 }}>کد بایگانی:</span>
                <span>{letter.archive_code}</span>
              </div>
            )}
            {letterhead.reg_number && (
              <div style={{ display: 'flex', gap: 6 }}>
                <span style={{ color, fontWeight: 600 }}>شماره ثبت:</span>
                <span>{letterhead.reg_number}</span>
              </div>
            )}
          </div>

          {/* Recipient */}
          <div style={{ border: '1px solid #e5e7eb', padding: '10px 14px', marginBottom: 14, fontSize: '9pt' }}>
            <div style={{ fontWeight: 600, color, marginBottom: 6 }}>گیرنده:</div>
            <div>
              {letter.recipient_name && <span style={{ fontWeight: 600 }}>{letter.recipient_name}</span>}
              {letter.recipient_organization && <span> — {letter.recipient_organization}</span>}
              {letter.recipient_department && <span> / {letter.recipient_department}</span>}
            </div>
          </div>

          {/* Subject */}
          <div style={{ fontSize: '12pt', fontWeight: 700, color: '#111', marginBottom: 16, paddingBottom: 8, borderBottom: '1px dashed #ccc' }}>
            <span style={{ color, marginLeft: 8 }}>موضوع:</span>
            {letter.subject}
          </div>

          {/* Body */}
          {letter.body.trim().startsWith('<') ? (
            <div
              className="letter-body"
              style={{ flex: 1, fontSize: '10pt', lineHeight: 2.2, color: '#1a1a1a' }}
              dangerouslySetInnerHTML={{ __html: letter.body }}
            />
          ) : (
            <div style={{ flex: 1, fontSize: '10pt', lineHeight: 2.2, color: '#1a1a1a', textAlign: 'justify', whiteSpace: 'pre-wrap' }}>
              {letter.body}
            </div>
          )}

          {/* Signature area */}
          {(() => {
            const allSigners = []
            // Primary signer (or sender fallback)
            if (letter.signer_name || letter.sender_name) {
              allSigners.push({
                label: 'امضاکننده',
                name: letter.signer_name || letter.sender_name,
                position: letter.signer_position || letter.sender_position,
                signature: letter.signer_signature || letter.sender_signature,
                stamp: letter.signer_stamp,
              })
            }
            // Additional signers
            ;(letter.additional_signers || []).forEach(s => {
              allSigners.push({
                label: 'امضاکننده',
                name: s.full_name,
                position: s.position,
                signature: s.signature,
                stamp: s.stamp,
              })
            })
            return (
              <div style={{ marginTop: 48, display: 'flex', justifyContent: 'flex-start', alignItems: 'flex-end', flexWrap: 'wrap', gap: 40 }}>
                {allSigners.map((s, i) => (
                  <div key={i} style={{ textAlign: 'center', minWidth: 130, position: 'relative' }}>
                    <div style={{ fontSize: '8pt', color: '#666', marginBottom: 4 }}>{s.label}</div>
                    {s.stamp && (
                      <img src={s.stamp} alt="stamp" style={{ position: 'absolute', top: 0, left: '50%', transform: 'translateX(-50%)', height: 70, width: 70, objectFit: 'contain', opacity: 0.75 }} />
                    )}
                    {s.signature ? (
                      <img src={s.signature} alt="signature" style={{ height: 56, maxWidth: 150, objectFit: 'contain', display: 'block', margin: '0 auto', position: 'relative', zIndex: 1 }} />
                    ) : (
                      <div style={{ height: 56 }} />
                    )}
                    <div style={{ borderTop: '1px solid #999', width: 130, margin: '4px auto 0' }} />
                    <div style={{ fontSize: '9pt', fontWeight: 600, color: '#222', marginTop: 4 }}>{s.name}</div>
                    {s.position && <div style={{ fontSize: '7.5pt', color: '#888' }}>{s.position}</div>}
                  </div>
                ))}
              </div>
            )
          })()}

          {/* Stamp (absolute positioned) */}
          {letter.is_stamped && letterhead.stamp_data && (
            <div style={{ position: 'absolute', bottom: letterhead.letterhead_footer_data ? '60mm' : '20mm', left: '25mm' }}>
              <img src={letterhead.stamp_data} alt="stamp" style={{ height: 110, width: 110, objectFit: 'contain', opacity: 0.85 }} />
            </div>
          )}

          {/* Text footer — only when no footer image */}
          {!letterhead.letterhead_footer_data && letterhead.footer_text && (
            <div style={{ borderTop: `2px solid ${color}`, paddingTop: 8, marginTop: 20, fontSize: '7pt', color: '#888', textAlign: 'center' }}>
              {letterhead.footer_text}
            </div>
          )}

          </div>{/* end page-content */}

          {/* Full-width footer image — zero margin/padding, flush to page bottom */}
          {letterhead.letterhead_footer_data && (
            <img
              src={letterhead.letterhead_footer_data}
              alt="letterhead footer"
              className="page-footer-img"
              style={{ width: '100%', display: 'block', margin: 0, padding: 0, marginTop: 'auto' }}
            />
          )}
        </div>
      </div>
    </div>
  )
}
