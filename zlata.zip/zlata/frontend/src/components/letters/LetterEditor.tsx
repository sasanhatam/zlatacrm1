import { useEditor, EditorContent, Extension } from '@tiptap/react'
import StarterKit from '@tiptap/starter-kit'
import { Table } from '@tiptap/extension-table'
import { TableRow } from '@tiptap/extension-table-row'
import { TableCell } from '@tiptap/extension-table-cell'
import { TableHeader } from '@tiptap/extension-table-header'
import { TextStyle } from '@tiptap/extension-text-style'
import { Color } from '@tiptap/extension-color'
import Highlight from '@tiptap/extension-highlight'
import TextAlign from '@tiptap/extension-text-align'
import Underline from '@tiptap/extension-underline'
import FontFamily from '@tiptap/extension-font-family'
import Link from '@tiptap/extension-link'
import { useEffect, useRef } from 'react'
import {
  Bold as BoldIcon, Italic as ItalicIcon, Underline as UnderlineIcon, Strikethrough,
  AlignRight, AlignCenter, AlignLeft, AlignJustify,
  List, ListOrdered, Link2, Undo2, Redo2, Trash2,
  Eraser, Table as TableIcon, Highlighter, Baseline,
} from 'lucide-react'

// Custom FontSize extension — adds fontSize attribute to textStyle mark
const FontSize = Extension.create({
  name: 'fontSize',
  addOptions() {
    return { types: ['textStyle'] }
  },
  addGlobalAttributes() {
    return [{
      types: this.options.types,
      attributes: {
        fontSize: {
          default: null,
          parseHTML: (el: HTMLElement) => el.style.fontSize || null,
          renderHTML: (attrs: Record<string, unknown>) =>
            attrs.fontSize ? { style: `font-size: ${attrs.fontSize}` } : {},
        },
      },
    }]
  },
  addCommands() {
    return {
      setFontSize: (size: string) => ({ chain }: any) =>
        chain().setMark('textStyle', { fontSize: size }).run(),
      unsetFontSize: () => ({ chain }: any) =>
        chain().setMark('textStyle', { fontSize: null }).removeEmptyTextStyle().run(),
    }
  },
})

const FONTS = [
  { label: 'وزیرمتن', value: 'Vazirmatn, Tahoma, sans-serif' },
  { label: 'تاهوما', value: 'Tahoma, sans-serif' },
  { label: 'آریال', value: 'Arial, sans-serif' },
  { label: 'Times New Roman', value: '"Times New Roman", serif' },
  { label: 'کوریر', value: '"Courier New", monospace' },
]

const SIZES = ['8pt', '9pt', '10pt', '11pt', '12pt', '14pt', '16pt', '18pt', '20pt', '24pt', '28pt', '36pt']

function ToolBtn({
  onClick, active = false, title, children, danger = false,
}: {
  onClick: () => void
  active?: boolean
  title: string
  children: React.ReactNode
  danger?: boolean
}) {
  return (
    <button
      type="button"
      title={title}
      onMouseDown={e => { e.preventDefault(); onClick() }}
      className={`p-1.5 rounded transition-colors text-[13px] leading-none ${
        danger
          ? 'text-red-500 hover:bg-red-50'
          : active
          ? 'bg-primary-100 text-primary-700'
          : 'text-gray-600 hover:bg-gray-200 hover:text-gray-900'
      }`}
    >
      {children}
    </button>
  )
}

function Sep() {
  return <span className="w-px h-5 bg-gray-300 mx-0.5 flex-shrink-0" />
}

interface Props {
  value: string
  onChange: (html: string) => void
}

export function LetterEditor({ value, onChange }: Props) {
  const editor = useEditor({
    extensions: [
      StarterKit,
      TextStyle,
      Color,
      FontSize,
      FontFamily,
      Highlight.configure({ multicolor: true }),
      TextAlign.configure({ types: ['heading', 'paragraph'], defaultAlignment: 'right' }),
      Underline,
      Table.configure({ resizable: false }),
      TableRow,
      TableHeader,
      TableCell,
      Link.configure({ openOnClick: false, autolink: true }),
    ],
    content: value || '<p></p>',
    onUpdate({ editor }) {
      onChange(editor.getHTML())
    },
    editorProps: {
      attributes: {
        dir: 'rtl',
        spellcheck: 'false',
      },
    },
  })

  // Sync external value reset (e.g., form clear)
  const lastHtml = useRef(value)
  useEffect(() => {
    if (!editor || value === lastHtml.current) return
    lastHtml.current = value
    if (!value || value === '<p></p>') {
      editor.commands.clearContent()
    } else if (editor.getHTML() !== value) {
      editor.commands.setContent(value)
    }
  }, [value, editor])

  if (!editor) return null

  const inTable = editor.isActive('table')

  const promptLink = () => {
    const prev = editor.getAttributes('link').href || ''
    const url = window.prompt('آدرس لینک:', prev)
    if (url === null) return
    if (!url) {
      editor.chain().focus().extendMarkRange('link').unsetLink().run()
    } else {
      editor.chain().focus().extendMarkRange('link').setLink({ href: url }).run()
    }
  }

  const currentFontSize = editor.getAttributes('textStyle').fontSize || '11pt'
  const currentFont = editor.getAttributes('textStyle').fontFamily || FONTS[0].value

  return (
    <div className="letter-editor-wrap border border-gray-300 rounded-xl overflow-hidden focus-within:ring-2 focus-within:ring-primary-300 bg-white">
      {/* ── Toolbar ── */}
      <div className="flex flex-wrap items-center gap-0.5 px-2 py-1.5 bg-gray-50 border-b border-gray-200 overflow-x-auto">

        {/* Undo / Redo */}
        <ToolBtn onClick={() => editor.chain().focus().undo().run()} title="بازگشت (Ctrl+Z)">
          <Undo2 size={14} />
        </ToolBtn>
        <ToolBtn onClick={() => editor.chain().focus().redo().run()} title="جلو (Ctrl+Y)">
          <Redo2 size={14} />
        </ToolBtn>

        <Sep />

        {/* Paragraph / Heading */}
        <select
          title="قالب متن"
          value={
            editor.isActive('heading', { level: 1 }) ? 'h1' :
            editor.isActive('heading', { level: 2 }) ? 'h2' :
            editor.isActive('heading', { level: 3 }) ? 'h3' : 'p'
          }
          onChange={e => {
            const v = e.target.value
            if (v === 'p') editor.chain().focus().setParagraph().run()
            else editor.chain().focus().toggleHeading({ level: Number(v[1]) as 1 | 2 | 3 }).run()
          }}
          className="text-xs border border-gray-200 rounded px-1.5 py-1 bg-white focus:outline-none max-w-[88px]"
        >
          <option value="p">معمولی</option>
          <option value="h1">عنوان ۱</option>
          <option value="h2">عنوان ۲</option>
          <option value="h3">عنوان ۳</option>
        </select>

        {/* Font family */}
        <select
          title="فونت"
          value={currentFont}
          onChange={e => editor.chain().focus().setFontFamily(e.target.value).run()}
          className="text-xs border border-gray-200 rounded px-1.5 py-1 bg-white focus:outline-none max-w-[108px]"
        >
          {FONTS.map(f => (
            <option key={f.value} value={f.value}>{f.label}</option>
          ))}
        </select>

        {/* Font size */}
        <select
          title="اندازه قلم"
          value={currentFontSize}
          onChange={e => (editor as any).chain().focus().setFontSize(e.target.value).run()}
          className="text-xs border border-gray-200 rounded px-1.5 py-1 bg-white focus:outline-none w-[66px]"
        >
          {SIZES.map(s => (
            <option key={s} value={s}>{s}</option>
          ))}
        </select>

        <Sep />

        {/* Bold / Italic / Underline / Strike */}
        <ToolBtn onClick={() => editor.chain().focus().toggleBold().run()} active={editor.isActive('bold')} title="بولد (Ctrl+B)">
          <BoldIcon size={14} />
        </ToolBtn>
        <ToolBtn onClick={() => editor.chain().focus().toggleItalic().run()} active={editor.isActive('italic')} title="مورب (Ctrl+I)">
          <ItalicIcon size={14} />
        </ToolBtn>
        <ToolBtn onClick={() => editor.chain().focus().toggleUnderline().run()} active={editor.isActive('underline')} title="زیرخط (Ctrl+U)">
          <UnderlineIcon size={14} />
        </ToolBtn>
        <ToolBtn onClick={() => editor.chain().focus().toggleStrike().run()} active={editor.isActive('strike')} title="خط‌خورده">
          <Strikethrough size={14} />
        </ToolBtn>

        <Sep />

        {/* Text color */}
        <label title="رنگ متن" className="cursor-pointer p-1.5 hover:bg-gray-200 rounded flex items-center transition-colors">
          <span className="flex flex-col items-center leading-none">
            <Baseline size={14} className="text-gray-600" />
            <span
              className="h-0.5 w-3.5 rounded-sm mt-0.5"
              style={{ background: editor.getAttributes('textStyle').color || '#000' }}
            />
          </span>
          <input
            type="color"
            className="absolute opacity-0 w-0 h-0"
            onInput={e => editor.chain().focus().setColor((e.target as HTMLInputElement).value).run()}
          />
        </label>

        {/* Highlight color */}
        <label title="هایلایت" className="cursor-pointer p-1.5 hover:bg-gray-200 rounded flex items-center transition-colors">
          <span className="flex flex-col items-center leading-none">
            <Highlighter size={14} className="text-gray-600" />
            <span
              className="h-0.5 w-3.5 rounded-sm mt-0.5"
              style={{
                background: typeof editor.getAttributes('highlight').color === 'string'
                  ? editor.getAttributes('highlight').color as string
                  : '#fef08a',
              }}
            />
          </span>
          <input
            type="color"
            className="absolute opacity-0 w-0 h-0"
            defaultValue="#fef08a"
            onInput={e =>
              editor.chain().focus().toggleHighlight({ color: (e.target as HTMLInputElement).value }).run()
            }
          />
        </label>

        <Sep />

        {/* Text alignment */}
        <ToolBtn onClick={() => editor.chain().focus().setTextAlign('right').run()} active={editor.isActive({ textAlign: 'right' })} title="راست‌چین">
          <AlignRight size={14} />
        </ToolBtn>
        <ToolBtn onClick={() => editor.chain().focus().setTextAlign('center').run()} active={editor.isActive({ textAlign: 'center' })} title="وسط‌چین">
          <AlignCenter size={14} />
        </ToolBtn>
        <ToolBtn onClick={() => editor.chain().focus().setTextAlign('left').run()} active={editor.isActive({ textAlign: 'left' })} title="چپ‌چین">
          <AlignLeft size={14} />
        </ToolBtn>
        <ToolBtn onClick={() => editor.chain().focus().setTextAlign('justify').run()} active={editor.isActive({ textAlign: 'justify' })} title="بلوکی">
          <AlignJustify size={14} />
        </ToolBtn>

        <Sep />

        {/* Lists */}
        <ToolBtn onClick={() => editor.chain().focus().toggleBulletList().run()} active={editor.isActive('bulletList')} title="لیست نقطه‌ای">
          <List size={14} />
        </ToolBtn>
        <ToolBtn onClick={() => editor.chain().focus().toggleOrderedList().run()} active={editor.isActive('orderedList')} title="لیست شماره‌ای">
          <ListOrdered size={14} />
        </ToolBtn>

        <Sep />

        {/* Table */}
        {!inTable ? (
          <ToolBtn onClick={() => editor.chain().focus().insertTable({ rows: 3, cols: 3, withHeaderRow: true }).run()} title="درج جدول">
            <TableIcon size={14} />
          </ToolBtn>
        ) : (
          <>
            <ToolBtn onClick={() => editor.chain().focus().addRowAfter().run()} title="ردیف بعد">
              <span className="text-[11px] font-bold leading-none">ر+</span>
            </ToolBtn>
            <ToolBtn onClick={() => editor.chain().focus().addRowBefore().run()} title="ردیف قبل">
              <span className="text-[11px] font-bold leading-none">ر↑</span>
            </ToolBtn>
            <ToolBtn onClick={() => editor.chain().focus().deleteRow().run()} title="حذف ردیف">
              <span className="text-[11px] font-bold leading-none">ر-</span>
            </ToolBtn>
            <ToolBtn onClick={() => editor.chain().focus().addColumnAfter().run()} title="ستون بعد">
              <span className="text-[11px] font-bold leading-none">س+</span>
            </ToolBtn>
            <ToolBtn onClick={() => editor.chain().focus().deleteColumn().run()} title="حذف ستون">
              <span className="text-[11px] font-bold leading-none">س-</span>
            </ToolBtn>
            <ToolBtn onClick={() => editor.chain().focus().deleteTable().run()} title="حذف جدول" danger>
              <Trash2 size={13} />
            </ToolBtn>
          </>
        )}

        <Sep />

        {/* Link */}
        <ToolBtn onClick={promptLink} active={editor.isActive('link')} title="لینک">
          <Link2 size={14} />
        </ToolBtn>

        {/* Clear formatting */}
        <ToolBtn onClick={() => editor.chain().focus().clearNodes().unsetAllMarks().run()} title="حذف قالب‌بندی">
          <Eraser size={14} />
        </ToolBtn>
      </div>

      {/* Editor area */}
      <EditorContent editor={editor} />
    </div>
  )
}
