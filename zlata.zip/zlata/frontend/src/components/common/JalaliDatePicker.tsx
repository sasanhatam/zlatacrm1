import { useState, useRef, useEffect } from 'react'
import { ChevronRight, ChevronLeft, Calendar, X } from 'lucide-react'
import clsx from 'clsx'

// ─── Jalali conversion (pure JS, no lib) ──────────────────────────────────────

function toJalali(gy: number, gm: number, gd: number): [number, number, number] {
  const g_d_no = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
  const j_d_no = [31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29]
  if (gy > 1600) { gy -= 1600 } else { gy -= 1 }
  let g_day_no = 365 * gy + Math.floor((gy + 3) / 4) - Math.floor((gy + 99) / 100) + Math.floor((gy + 399) / 400)
  for (let i = 0; i < gm - 1; i++) g_day_no += g_d_no[i]
  if (gm > 2 && ((gy + 1) % 4 === 0 && ((gy + 1) % 100 !== 0 || (gy + 1) % 400 === 0))) g_day_no++
  g_day_no += gd - 1
  let j_day_no = g_day_no - 79
  const j_np = Math.floor(j_day_no / 12053); j_day_no %= 12053
  let jy = 979 + 33 * j_np + 4 * Math.floor(j_day_no / 1461); j_day_no %= 1461
  if (j_day_no >= 366) { jy += Math.floor((j_day_no - 1) / 365); j_day_no = (j_day_no - 1) % 365 }
  let jm = 0, jd = 0, i = 0
  for (; i < 11 && j_day_no >= j_d_no[i]; i++) j_day_no -= j_d_no[i]
  jm = i + 1; jd = j_day_no + 1
  return [jy, jm, jd]
}

function fromJalali(jy: number, jm: number, jd: number): Date {
  const j_d_no = [31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29]
  let j_day_no = 365 * (jy - 979) + Math.floor((jy - 979) / 4) - Math.floor((jy - 979) / 100) + Math.floor((jy - 979) / 400)
  for (let i = 0; i < jm - 1; i++) j_day_no += j_d_no[i]
  j_day_no += jd - 1
  let g_day_no = j_day_no + 79
  let gy = 1600 + 400 * Math.floor(g_day_no / 146097); g_day_no %= 146097
  let leap = true
  if (g_day_no >= 36525) {
    g_day_no--
    gy += 100 * Math.floor(g_day_no / 36524); g_day_no %= 36524
    if (g_day_no >= 365) g_day_no++
    else leap = false
  }
  gy += 4 * Math.floor(g_day_no / 1461); g_day_no %= 1461
  if (g_day_no >= 366) {
    leap = false
    g_day_no--
    gy += Math.floor(g_day_no / 365); g_day_no %= 365
  }
  const g_d_no = [31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
  let gm = 0
  for (gm = 0; gm < 12; gm++) {
    if (g_day_no < g_d_no[gm]) break
    g_day_no -= g_d_no[gm]
  }
  return new Date(gy, gm, g_day_no + 1)
}

// ─── Persian digits ────────────────────────────────────────────────────────────

function toPersian(n: number | string): string {
  return String(n).replace(/[0-9]/g, d => '۰۱۲۳۴۵۶۷۸۹'[+d])
}

// ─── Constants ─────────────────────────────────────────────────────────────────

const MONTHS = [
  'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
  'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'
]

// Jalali week starts on Saturday
const WEEK_DAYS = ['ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج']

const MONTH_DAYS = [31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29]

function jalaliDaysInMonth(jy: number, jm: number): number {
  if (jm <= 6) return 31
  if (jm <= 11) return 30
  // Esfand - leap year check (simplified: every 4 years)
  const leapYears = [1, 5, 9, 13, 17, 22, 26, 30]
  const cycle = jy % 33
  return leapYears.includes(cycle) ? 30 : 29
}

// Day of week for first day of a Jalali month (0=Saturday, 6=Friday)
function jalaliFirstDayOfWeek(jy: number, jm: number): number {
  const g = fromJalali(jy, jm, 1)
  // JS getDay(): 0=Sun, 1=Mon, ..., 6=Sat
  // We want: 0=Sat, 1=Sun, ..., 6=Fri
  const jsDay = g.getDay()
  return (jsDay + 1) % 7
}

function todayJalali(): [number, number, number] {
  const now = new Date()
  return toJalali(now.getFullYear(), now.getMonth() + 1, now.getDate())
}

// ─── Parse display value "۱۴۰۳/۰۳/۲۵" or "1403/03/25" ────────────────────────

function parseJalaliStr(val: string): [number, number, number] | null {
  if (!val) return null
  // Convert Persian digits to Latin
  const latinized = val.replace(/[۰-۹]/g, d => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)))
  const parts = latinized.split('/')
  if (parts.length !== 3) return null
  const [y, m, d] = parts.map(Number)
  if (!y || !m || !d) return null
  return [y, m, d]
}

function formatJalaliDisplay(jy: number, jm: number, jd: number): string {
  return `${toPersian(jy)}/${toPersian(String(jm).padStart(2, '0'))}/${toPersian(String(jd).padStart(2, '0'))}`
}

// ─── Component ─────────────────────────────────────────────────────────────────

interface JalaliDatePickerProps {
  value: string
  onChange: (val: string) => void
  placeholder?: string
  className?: string
  disabled?: boolean
}

export function JalaliDatePicker({ value, onChange, placeholder = 'انتخاب تاریخ', className, disabled }: JalaliDatePickerProps) {
  const [open, setOpen] = useState(false)
  const ref = useRef<HTMLDivElement>(null)

  const parsed = parseJalaliStr(value)
  const [todayJY, todayJM] = todayJalali()
  const [viewYear, setViewYear] = useState<number>(parsed?.[0] ?? todayJY)
  const [viewMonth, setViewMonth] = useState<number>(parsed?.[1] ?? todayJM)

  // Close on outside click
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false)
    }
    document.addEventListener('mousedown', handler)
    return () => document.removeEventListener('mousedown', handler)
  }, [])

  // Update view when value changes externally
  useEffect(() => {
    if (parsed) { setViewYear(parsed[0]); setViewMonth(parsed[1]) }
  }, [value])

  const prevMonth = () => {
    if (viewMonth === 1) { setViewMonth(12); setViewYear(y => y - 1) }
    else setViewMonth(m => m - 1)
  }

  const nextMonth = () => {
    if (viewMonth === 12) { setViewMonth(1); setViewYear(y => y + 1) }
    else setViewMonth(m => m + 1)
  }

  const selectDay = (d: number) => {
    const display = formatJalaliDisplay(viewYear, viewMonth, d)
    onChange(display)
    setOpen(false)
  }

  const clear = (e: React.MouseEvent) => {
    e.stopPropagation()
    onChange('')
  }

  const daysInMonth = jalaliDaysInMonth(viewYear, viewMonth)
  const firstDay = jalaliFirstDayOfWeek(viewYear, viewMonth)
  const [todayY, todayM, todayD] = todayJalali()

  // Build grid cells
  const cells: (number | null)[] = []
  for (let i = 0; i < firstDay; i++) cells.push(null)
  for (let d = 1; d <= daysInMonth; d++) cells.push(d)

  return (
    <div ref={ref} className={clsx('relative', className)} dir="rtl">
      {/* Trigger button */}
      <button
        type="button"
        disabled={disabled}
        onClick={() => !disabled && setOpen(o => !o)}
        className={clsx(
          'w-full flex items-center gap-2 border border-gray-300 rounded-lg px-3 py-2 text-sm text-right',
          'focus:outline-none focus:ring-2 focus:ring-primary-300 bg-white transition-colors',
          'hover:border-primary-400',
          disabled && 'opacity-50 cursor-not-allowed',
          open && 'ring-2 ring-primary-300 border-primary-400'
        )}
      >
        <Calendar size={15} className="text-gray-400 flex-shrink-0" />
        <span className={clsx('flex-1 text-right', value ? 'text-gray-900' : 'text-gray-400')}>
          {value || placeholder}
        </span>
        {value && !disabled && (
          <button
            type="button"
            onClick={clear}
            className="text-gray-300 hover:text-gray-500 flex-shrink-0 transition-colors"
          >
            <X size={13} />
          </button>
        )}
      </button>

      {/* Popover */}
      {open && (
        <div className="absolute top-full mt-1 right-0 z-50 bg-white border border-gray-200 rounded-xl shadow-xl p-3 w-72 select-none">
          {/* Month / Year header */}
          <div className="flex items-center justify-between mb-3">
            <button
              type="button"
              onClick={nextMonth}
              className="p-1.5 hover:bg-gray-100 rounded-lg transition-colors text-gray-600"
            >
              <ChevronRight size={16} />
            </button>
            <div className="text-sm font-semibold text-gray-800">
              {MONTHS[viewMonth - 1]} {toPersian(viewYear)}
            </div>
            <button
              type="button"
              onClick={prevMonth}
              className="p-1.5 hover:bg-gray-100 rounded-lg transition-colors text-gray-600"
            >
              <ChevronLeft size={16} />
            </button>
          </div>

          {/* Weekday headers */}
          <div className="grid grid-cols-7 mb-1">
            {WEEK_DAYS.map(w => (
              <div key={w} className="text-center text-xs text-gray-400 font-medium py-1">{w}</div>
            ))}
          </div>

          {/* Day grid */}
          <div className="grid grid-cols-7 gap-0.5">
            {cells.map((day, idx) => {
              if (day === null) return <div key={`empty-${idx}`} />

              const isToday = viewYear === todayY && viewMonth === todayM && day === todayD
              const isSelected = parsed && parsed[0] === viewYear && parsed[1] === viewMonth && parsed[2] === day

              return (
                <button
                  key={day}
                  type="button"
                  onClick={() => selectDay(day)}
                  className={clsx(
                    'text-center text-xs rounded-lg py-1.5 transition-colors font-medium',
                    isSelected
                      ? 'bg-primary-600 text-white'
                      : isToday
                        ? 'bg-primary-100 text-primary-700 font-bold'
                        : 'text-gray-700 hover:bg-gray-100'
                  )}
                >
                  {toPersian(day)}
                </button>
              )
            })}
          </div>

          {/* Today shortcut */}
          <div className="mt-3 pt-2 border-t border-gray-100 flex justify-center">
            <button
              type="button"
              onClick={() => {
                setViewYear(todayY)
                setViewMonth(todayM)
                selectDay(todayD)
              }}
              className="text-xs text-primary-600 hover:text-primary-700 font-medium"
            >
              امروز
            </button>
          </div>
        </div>
      )}
    </div>
  )
}

export default JalaliDatePicker
