import clsx from 'clsx'

interface AvatarProps {
  name: string
  url?: string
  size?: 'xs' | 'sm' | 'md' | 'lg'
  className?: string
}

const sizes = { xs: 'w-6 h-6 text-xs', sm: 'w-8 h-8 text-sm', md: 'w-10 h-10 text-sm', lg: 'w-14 h-14 text-lg' }

const colors = [
  'bg-blue-100 text-blue-700', 'bg-green-100 text-green-700',
  'bg-purple-100 text-purple-700', 'bg-orange-100 text-orange-700',
  'bg-pink-100 text-pink-700', 'bg-teal-100 text-teal-700',
]

function getColor(name: string) {
  let hash = 0
  for (let i = 0; i < name.length; i++) hash = name.charCodeAt(i) + ((hash << 5) - hash)
  return colors[Math.abs(hash) % colors.length]
}

function initials(name: string) {
  return name.split(' ').slice(0, 2).map(p => p[0]).join('').toUpperCase()
}

export function Avatar({ name, url, size = 'md', className }: AvatarProps) {
  if (url) {
    return <img src={url} alt={name} className={clsx('rounded-full object-cover', sizes[size], className)} />
  }
  return (
    <div className={clsx('rounded-full flex items-center justify-center font-semibold flex-shrink-0', sizes[size], getColor(name), className)}>
      {initials(name)}
    </div>
  )
}
