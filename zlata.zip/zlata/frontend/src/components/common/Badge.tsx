import clsx from 'clsx'
import { TaskPriority, TaskStatus, PRIORITY_LABELS, STATUS_LABELS } from '@/types/task'

interface PriorityBadgeProps { priority: TaskPriority }
interface StatusBadgeProps { status: TaskStatus }

const PRIORITY_STYLES: Record<TaskPriority, string> = {
  low:    'bg-green-100 text-green-700',
  medium: 'bg-yellow-100 text-yellow-700',
  high:   'bg-orange-100 text-orange-700',
  urgent: 'bg-red-100 text-red-700',
}

const STATUS_STYLES: Record<TaskStatus, string> = {
  todo:        'bg-gray-100 text-gray-700',
  in_progress: 'bg-blue-100 text-blue-700',
  in_review:   'bg-purple-100 text-purple-700',
  done:        'bg-green-100 text-green-700',
  blocked:     'bg-red-100 text-red-700',
}

export function PriorityBadge({ priority }: PriorityBadgeProps) {
  return (
    <span className={clsx('text-xs font-medium px-2 py-0.5 rounded-full', PRIORITY_STYLES[priority])}>
      {PRIORITY_LABELS[priority]}
    </span>
  )
}

export function StatusBadge({ status }: StatusBadgeProps) {
  return (
    <span className={clsx('text-xs font-medium px-2 py-0.5 rounded-full', STATUS_STYLES[status])}>
      {STATUS_LABELS[status]}
    </span>
  )
}
