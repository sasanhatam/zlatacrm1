import { Outlet, useNavigate } from 'react-router-dom'
import { Sidebar } from './Sidebar'
import { Header } from './Header'
import { useAuthStore } from '@/store/authStore'
import { useEffect, useState } from 'react'
import { useNotificationStore } from '@/store/notificationStore'
import { useWebSocket } from '@/hooks/useWebSocket'
import { usePushNotification } from '@/hooks/usePushNotification'
import toast from 'react-hot-toast'

export function AppLayout() {
  const { user, isAuthenticated, loadMe } = useAuthStore()
  const { fetchUnreadCount, addNotification } = useNotificationStore()
  const navigate = useNavigate()
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false)

  useEffect(() => {
    if (!isAuthenticated) { navigate('/login'); return }
    loadMe()
    fetchUnreadCount()
  }, [isAuthenticated])

  useWebSocket('/api/notifications/ws', {
    onMessage: (data: any) => {
      if (data.type === 'notification') {
        addNotification(data.data)
        toast(data.data.title, { icon: '🔔' })
      }
      if (data.type === 'announcement') {
        toast.success(`📢 ${data.data.title}`, { duration: 6000 })
      }
    },
  })

  usePushNotification(user?.email_notifications_enabled ?? false)

  return (
    <div className="flex h-screen bg-gray-50 overflow-hidden" dir="rtl">
      {/* Mobile sidebar overlay backdrop */}
      {mobileSidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-30 md:hidden"
          onClick={() => setMobileSidebarOpen(false)}
        />
      )}

      {/* Sidebar — fixed drawer on mobile, static on desktop */}
      <div className={[
        'fixed inset-y-0 right-0 z-40 md:static md:z-auto md:flex',
        'transition-transform duration-300',
        mobileSidebarOpen ? 'translate-x-0' : 'translate-x-full md:translate-x-0',
      ].join(' ')}>
        <Sidebar onClose={() => setMobileSidebarOpen(false)} />
      </div>

      <div className="flex flex-col flex-1 overflow-hidden min-w-0">
        <Header onMenuClick={() => setMobileSidebarOpen(true)} />
        <main className="flex-1 overflow-y-auto p-3 md:p-6">
          <Outlet />
        </main>
      </div>
    </div>
  )
}
