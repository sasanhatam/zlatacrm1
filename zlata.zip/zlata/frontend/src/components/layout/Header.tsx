import { Bell, Search, User as UserIcon, CheckSquare, FileText, Users as UsersIcon, Menu } from 'lucide-react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuthStore } from '@/store/authStore'
import { useNotificationStore } from '@/store/notificationStore'
import { useState, useEffect, useRef } from 'react'
import { kartablApi, SearchResult } from '@/api/kartabl'

function useDebounce<T>(value: T, delay: number): T {
  const [debounced, setDebounced] = useState(value)
  useEffect(() => {
    const t = setTimeout(() => setDebounced(value), delay)
    return () => clearTimeout(t)
  }, [value, delay])
  return debounced
}

export function Header({ onMenuClick }: { onMenuClick?: () => void }) {
  const { user } = useAuthStore()
  const { unreadCount } = useNotificationStore()
  const [searchQuery, setSearchQuery] = useState('')
  const [searchResults, setSearchResults] = useState<SearchResult | null>(null)
  const [showDropdown, setShowDropdown] = useState(false)
  const [searching, setSearching] = useState(false)
  const navigate = useNavigate()
  const inputRef = useRef<HTMLInputElement>(null)
  const dropdownRef = useRef<HTMLDivElement>(null)
  const debouncedQuery = useDebounce(searchQuery, 300)

  // Fetch results when query changes
  useEffect(() => {
    if (!debouncedQuery.trim() || debouncedQuery.trim().length < 2) {
      setSearchResults(null)
      setShowDropdown(false)
      return
    }
    setSearching(true)
    kartablApi.search(debouncedQuery.trim())
      .then(r => {
        setSearchResults(r.data)
        setShowDropdown(true)
      })
      .catch(() => setSearchResults(null))
      .finally(() => setSearching(false))
  }, [debouncedQuery])

  // Close on outside click
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (
        dropdownRef.current && !dropdownRef.current.contains(e.target as Node) &&
        inputRef.current && !inputRef.current.contains(e.target as Node)
      ) {
        setShowDropdown(false)
      }
    }
    document.addEventListener('mousedown', handler)
    return () => document.removeEventListener('mousedown', handler)
  }, [])

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Escape') {
      setShowDropdown(false)
      setSearchQuery('')
    }
  }

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      navigate(`/tasks?search=${encodeURIComponent(searchQuery)}`)
      setShowDropdown(false)
    }
  }

  const hasResults = searchResults && (
    searchResults.tasks.length > 0 ||
    searchResults.letters.length > 0 ||
    searchResults.users.length > 0
  )

  return (
    <header className="bg-white border-b border-gray-200 px-3 md:px-6 py-3 flex items-center gap-3 md:gap-4" dir="rtl">
      {/* Mobile hamburger */}
      <button
        onClick={onMenuClick}
        className="md:hidden p-2 rounded-lg hover:bg-gray-100 text-gray-600"
        aria-label="منو"
      >
        <Menu size={20} />
      </button>

      {/* Search */}
      <div className="flex-1 max-w-md relative">
        <form onSubmit={handleSearch}>
          <div className="relative">
            <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" />
            {searching && (
              <div className="absolute left-3 top-1/2 -translate-y-1/2">
                <div className="w-3 h-3 border-2 border-primary-400 border-t-transparent rounded-full animate-spin" />
              </div>
            )}
            <input
              ref={inputRef}
              type="text"
              placeholder="جستجوی سریع..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onFocus={() => { if (searchResults && hasResults) setShowDropdown(true) }}
              onKeyDown={handleKeyDown}
              className="w-full pr-9 pl-4 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 bg-gray-50"
            />
          </div>
        </form>

        {/* Search dropdown */}
        {showDropdown && (
          <div
            ref={dropdownRef}
            className="absolute top-full mt-1 right-0 w-full bg-white rounded-xl shadow-lg border border-gray-200 z-50 overflow-hidden max-h-80 overflow-y-auto"
          >
            {!hasResults ? (
              <div className="px-4 py-6 text-center text-sm text-gray-400">نتیجه‌ای یافت نشد</div>
            ) : (
              <>
                {searchResults && searchResults.tasks.length > 0 && (
                  <div>
                    <div className="px-3 py-2 text-xs font-semibold text-gray-400 uppercase bg-gray-50 border-b border-gray-100 flex items-center gap-1.5">
                      <CheckSquare size={12} />
                      تسک‌ها
                    </div>
                    {searchResults.tasks.map(t => (
                      <button
                        key={t.id}
                        onClick={() => { navigate(`/tasks/${t.id}`); setShowDropdown(false); setSearchQuery('') }}
                        className="w-full text-right px-4 py-2.5 hover:bg-gray-50 flex items-center gap-3 transition-colors"
                      >
                        <CheckSquare size={14} className="text-blue-500 flex-shrink-0" />
                        <span className="text-sm text-gray-700 truncate">{t.title}</span>
                      </button>
                    ))}
                  </div>
                )}
                {searchResults && searchResults.letters.length > 0 && (
                  <div>
                    <div className="px-3 py-2 text-xs font-semibold text-gray-400 uppercase bg-gray-50 border-b border-gray-100 flex items-center gap-1.5">
                      <FileText size={12} />
                      نامه‌ها
                    </div>
                    {searchResults.letters.map(l => (
                      <button
                        key={l.id}
                        onClick={() => { navigate(`/letters?id=${l.id}`); setShowDropdown(false); setSearchQuery('') }}
                        className="w-full text-right px-4 py-2.5 hover:bg-gray-50 flex items-center gap-3 transition-colors"
                      >
                        <FileText size={14} className="text-green-500 flex-shrink-0" />
                        <div className="min-w-0">
                          <p className="text-sm text-gray-700 truncate">{l.subject}</p>
                          {l.letter_number && (
                            <p className="text-xs text-gray-400" dir="ltr">{l.letter_number}</p>
                          )}
                        </div>
                      </button>
                    ))}
                  </div>
                )}
                {searchResults && searchResults.users.length > 0 && (
                  <div>
                    <div className="px-3 py-2 text-xs font-semibold text-gray-400 uppercase bg-gray-50 border-b border-gray-100 flex items-center gap-1.5">
                      <UsersIcon size={12} />
                      کاربران
                    </div>
                    {searchResults.users.map(u => (
                      <button
                        key={u.id}
                        onClick={() => { navigate('/admin/users'); setShowDropdown(false); setSearchQuery('') }}
                        className="w-full text-right px-4 py-2.5 hover:bg-gray-50 flex items-center gap-3 transition-colors"
                      >
                        <UsersIcon size={14} className="text-purple-500 flex-shrink-0" />
                        <div>
                          <p className="text-sm text-gray-700">{u.full_name}</p>
                          <p className="text-xs text-gray-400">{u.email}</p>
                        </div>
                      </button>
                    ))}
                  </div>
                )}
              </>
            )}
          </div>
        )}
      </div>

      <div className="flex items-center gap-3 mr-auto">
        {/* Notification Bell */}
        <Link to="/notifications" className="relative p-2 rounded-lg hover:bg-gray-100 transition-colors">
          <Bell size={20} className="text-gray-600" />
          {unreadCount > 0 && (
            <span className="absolute top-1 right-1 w-4 h-4 bg-red-500 text-white text-xs rounded-full flex items-center justify-center font-bold">
              {unreadCount > 9 ? '9+' : unreadCount}
            </span>
          )}
        </Link>

        {/* Profile */}
        <Link to="/profile" className="flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-gray-100 transition-colors">
          <div className="w-7 h-7 bg-primary-100 rounded-full flex items-center justify-center">
            <UserIcon size={14} className="text-primary-600" />
          </div>
          <span className="text-sm font-medium text-gray-700 hidden sm:block">{user?.full_name}</span>
        </Link>
      </div>
    </header>
  )
}
