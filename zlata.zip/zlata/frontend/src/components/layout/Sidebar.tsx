import { NavLink } from 'react-router-dom'
import {
  LayoutDashboard, CheckSquare, MessageSquare, Bell,
  FileText, Phone, Users, Settings, LogOut, ChevronLeft,
  CalendarDays, UmbrellaOff, Briefcase, Building2,
  ChevronDown, Search, Activity, Clock, ClipboardList,
} from 'lucide-react'
import { useAuthStore } from '@/store/authStore'
import { useCountsStore } from '@/store/countsStore'
import { companiesApi } from '@/api/companies'
import { Company } from '@/types/common'
import { useState, useEffect } from 'react'
import clsx from 'clsx'

function Badge({ count }: { count: number }) {
  if (count <= 0) return null
  return (
    <span className="ml-auto bg-red-500 text-white text-xs font-bold px-1.5 py-0.5 rounded-full min-w-[18px] text-center leading-none">
      {count > 99 ? '99+' : count}
    </span>
  )
}

export function Sidebar({ onClose }: { onClose?: () => void }) {
  const { user, logout } = useAuthStore()
  const { counts, fetch: fetchCounts } = useCountsStore()
  const [collapsed, setCollapsed] = useState(false)
  const [companies, setCompanies] = useState<Company[]>([])
  const [activeCompanyId, setActiveCompanyId] = useState<string>(() =>
    localStorage.getItem('zlata_active_company') || ''
  )
  const [showCompanyDropdown, setShowCompanyDropdown] = useState(false)
  const isAdmin = user?.role === 'super_admin' || user?.role === 'manager'
  const isSuperAdmin = user?.role === 'super_admin'

  // Fetch counts on mount and every 60s
  useEffect(() => {
    fetchCounts()
    const interval = setInterval(fetchCounts, 60000)
    return () => clearInterval(interval)
  }, [fetchCounts])

  // Load companies user belongs to
  useEffect(() => {
    if (user && (user.organization_ids?.length ?? 0) > 0) {
      companiesApi.list()
        .then(r => {
          const userCompanies = r.data.filter(c => user.organization_ids?.includes(c.id))
          setCompanies(userCompanies)
          // Set default active company if not set
          if (!activeCompanyId && userCompanies.length > 0) {
            const firstId = userCompanies[0].id
            setActiveCompanyId(firstId)
            localStorage.setItem('zlata_active_company', firstId)
          }
        })
        .catch(() => {})
    }
  }, [user])

  const handleCompanySwitch = (companyId: string) => {
    setActiveCompanyId(companyId)
    localStorage.setItem('zlata_active_company', companyId)
    setShowCompanyDropdown(false)
  }

  const activeCompany = companies.find(c => c.id === activeCompanyId)

  const kartablPending = counts?.kartabl_pending ?? 0
  const lettersBadge = (counts?.letters_inbox ?? 0) + (counts?.letters_referrals ?? 0)
  const tasksOverdue = counts?.tasks_overdue ?? 0

  const navItems = [
    { to: '/', icon: LayoutDashboard, label: 'داشبورد' },
    { to: '/kartabl', icon: Briefcase, label: 'کارتابل', badge: kartablPending },
    { to: '/tasks', icon: CheckSquare, label: 'تسک‌ها', badge: tasksOverdue },
    { to: '/chat', icon: MessageSquare, label: 'چت' },
    { to: '/notifications', icon: Bell, label: 'اعلانات' },
    { to: '/letters', icon: FileText, label: 'نامه‌نگاری', badge: lettersBadge },
    { to: '/meetings', icon: CalendarDays, label: 'جلسات' },
    { to: '/leaves', icon: UmbrellaOff, label: 'مرخصی' },
    { to: '/phonebook', icon: Phone, label: 'دفتر تلفن' },
    { to: '/seo', icon: Search, label: 'برنامه‌ریزی SEO' },
    { to: '/attendance', icon: Clock, label: 'حضور و غیاب' },
  ]

  const adminItems = [
    { to: '/admin/users', icon: Users, label: 'کاربران' },
    { to: '/admin/companies', icon: Building2, label: 'شرکت‌ها', superAdminOnly: true },
    { to: '/admin/activity-logs', icon: Activity, label: 'لاگ فعالیت‌ها' },
    { to: '/admin/attendance', icon: ClipboardList, label: 'گزارش حضور' },
    { to: '/admin/settings', icon: Settings, label: 'تنظیمات' },
  ]

  return (
    <div className={clsx(
      'bg-primary-600 text-white flex flex-col transition-all duration-300 relative',
      collapsed ? 'w-16' : 'w-64'
    )}>
      {/* Logo + Company */}
      <div className="border-b border-primary-700">
        <div className="flex items-center gap-3 p-4">
          <div className="w-9 h-9 bg-white rounded-lg flex items-center justify-center flex-shrink-0">
            <span className="text-primary-600 font-bold text-sm">Z</span>
          </div>
          {!collapsed && <span className="font-bold text-lg">Zlata</span>}
        </div>

        {/* Company switcher */}
        {!collapsed && companies.length > 0 && (
          <div className="px-3 pb-3">
            {companies.length === 1 ? (
              <div className="flex items-center gap-2 px-2 py-1.5 bg-primary-700 rounded-lg">
                <Building2 size={13} className="text-primary-300 flex-shrink-0" />
                <span className="text-xs text-primary-200 truncate">{activeCompany?.name || companies[0].name}</span>
              </div>
            ) : (
              <div className="relative">
                <button
                  onClick={() => setShowCompanyDropdown(!showCompanyDropdown)}
                  className="w-full flex items-center gap-2 px-2 py-1.5 bg-primary-700 rounded-lg hover:bg-primary-800 transition-colors"
                >
                  <Building2 size={13} className="text-primary-300 flex-shrink-0" />
                  <span className="text-xs text-primary-200 truncate flex-1 text-right">
                    {activeCompany?.name || 'انتخاب شرکت'}
                  </span>
                  <ChevronDown size={11} className={clsx('text-primary-400 transition-transform', showCompanyDropdown && 'rotate-180')} />
                </button>
                {showCompanyDropdown && (
                  <div className="absolute top-full mt-1 right-0 w-full bg-white rounded-lg shadow-lg border border-gray-200 z-50 overflow-hidden">
                    {companies.map(c => (
                      <button
                        key={c.id}
                        onClick={() => handleCompanySwitch(c.id)}
                        className={clsx(
                          'w-full text-right px-3 py-2 text-sm transition-colors',
                          c.id === activeCompanyId
                            ? 'bg-primary-50 text-primary-700 font-medium'
                            : 'text-gray-700 hover:bg-gray-50'
                        )}
                      >
                        {c.name}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Toggle */}
      <button
        onClick={() => setCollapsed(!collapsed)}
        className="absolute -left-3 top-6 w-6 h-6 bg-primary-600 border border-primary-500 rounded-full flex items-center justify-center hover:bg-primary-700 z-10"
      >
        <ChevronLeft size={12} className={clsx('transition-transform', collapsed && 'rotate-180')} />
      </button>

      {/* Nav */}
      <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
        {navItems.map(({ to, icon: Icon, label, badge }) => (
          <NavLink
            key={to}
            to={to}
            end={to === '/'}
            onClick={onClose}
            className={({ isActive }) => clsx(
              'flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors',
              isActive
                ? 'bg-white text-primary-600'
                : 'text-primary-100 hover:bg-primary-700 hover:text-white'
            )}
          >
            <Icon size={18} className="flex-shrink-0" />
            {!collapsed && (
              <>
                <span className="flex-1">{label}</span>
                {badge !== undefined && badge > 0 && <Badge count={badge} />}
              </>
            )}
          </NavLink>
        ))}

        {isAdmin && (
          <>
            <div className={clsx('pt-3 pb-1', !collapsed && 'px-3')}>
              {!collapsed && <p className="text-xs text-primary-300 uppercase tracking-wide">مدیریت</p>}
            </div>
            {adminItems.map(({ to, icon: Icon, label, superAdminOnly }) => {
              if (superAdminOnly && !isSuperAdmin) return null
              return (
                <NavLink
                  key={to}
                  to={to}
                  onClick={onClose}
                  className={({ isActive }) => clsx(
                    'flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors',
                    isActive
                      ? 'bg-white text-primary-600'
                      : 'text-primary-100 hover:bg-primary-700 hover:text-white'
                  )}
                >
                  <Icon size={18} className="flex-shrink-0" />
                  {!collapsed && <span>{label}</span>}
                </NavLink>
              )
            })}
          </>
        )}
      </nav>

      {/* User + Logout */}
      <div className="p-3 border-t border-primary-700">
        {!collapsed && (
          <div className="px-3 py-2 mb-1">
            <p className="text-sm font-medium text-white truncate">{user?.full_name}</p>
            <p className="text-xs text-primary-300 truncate">{user?.position || user?.role}</p>
          </div>
        )}
        <button
          onClick={() => logout()}
          className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-primary-200 hover:bg-primary-700 hover:text-white w-full transition-colors"
        >
          <LogOut size={18} className="flex-shrink-0" />
          {!collapsed && <span>خروج</span>}
        </button>
      </div>
    </div>
  )
}
