export type RoomType = 'direct' | 'group'
export type MessageType = 'text' | 'file' | 'image' | 'system'

export interface ChatRoom {
  id: string
  name?: string
  type: RoomType
  member_ids: string[]
  admin_ids: string[]
  last_message_at?: string
  last_message_preview?: string
  created_at: string
}

export interface Message {
  id: string
  room_id: string
  sender_id: string
  type: MessageType
  content?: string
  file_id?: string
  mentioned_user_ids: string[]
  read_by: Record<string, string>
  is_deleted: boolean
  created_at: string
}

export interface Notification {
  id: string
  type: string
  priority: 'normal' | 'important' | 'urgent'
  title: string
  body: string
  link?: string
  is_read: boolean
  metadata: Record<string, unknown>
  created_at: string
}

export interface Announcement {
  id: string
  title: string
  body: string
  priority: 'normal' | 'important' | 'urgent'
  author_id: string
  is_active: boolean
  expires_at?: string
  created_at: string
}
