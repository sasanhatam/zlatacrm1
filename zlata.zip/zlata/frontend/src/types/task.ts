export type TaskStatus = 'todo' | 'in_progress' | 'in_review' | 'done' | 'blocked'
export type TaskPriority = 'low' | 'medium' | 'high' | 'urgent'

export interface ChecklistItem {
  text: string
  is_done: boolean
}

export interface Task {
  id: string
  title: string
  description?: string
  team_id: string
  assignee_id?: string
  created_by: string
  priority: TaskPriority
  status: TaskStatus
  tags: string[]
  start_date?: string
  due_date?: string
  completed_at?: string
  delay_hours?: number
  checklist: ChecklistItem[]
  file_ids: string[]
  watcher_ids: string[]
  last_activity_at: string
  created_at: string
  updated_at: string
}

export interface SubTask {
  id: string
  title: string
  description?: string
  assignee_id?: string
  status: TaskStatus
  due_date?: string
  is_done: boolean
}

export interface TaskComment {
  id: string
  task_id: string
  author_id: string
  content: string
  mentioned_user_ids: string[]
  file_ids: string[]
  created_at: string
  updated_at: string
}

export interface AuditLog {
  id: string
  user_id: string
  action: string
  field?: string
  old_value?: string
  new_value?: string
  description?: string
  created_at: string
}

export const PRIORITY_LABELS: Record<TaskPriority, string> = {
  low: 'کم',
  medium: 'متوسط',
  high: 'زیاد',
  urgent: 'فوری',
}

export const STATUS_LABELS: Record<TaskStatus, string> = {
  todo: 'در انتظار',
  in_progress: 'در حال انجام',
  in_review: 'در بررسی',
  done: 'انجام شده',
  blocked: 'مسدود',
}

export const STATUS_COLORS: Record<TaskStatus, string> = {
  todo: 'bg-gray-100 text-gray-700',
  in_progress: 'bg-blue-100 text-blue-700',
  in_review: 'bg-purple-100 text-purple-700',
  done: 'bg-green-100 text-green-700',
  blocked: 'bg-red-100 text-red-700',
}
