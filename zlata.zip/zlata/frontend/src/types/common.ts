export type UserRole = 'super_admin' | 'manager' | 'team_lead' | 'member'

export interface User {
  id: string
  email: string
  full_name: string
  role: UserRole
  position?: string
  team_ids: string[]
  organization_ids: string[]
  avatar_url?: string
  extension_number?: string
  mobile?: string
  notification_email?: string
  email_notifications_enabled: boolean
  notification_preferences: Record<string, boolean>
  is_active: boolean
  last_login?: string
  created_at: string
}

export interface Company {
  id: string
  name: string
  official_name?: string
  address?: string
  phone?: string
  website?: string
  letterhead_header_data?: string | null
  letterhead_footer_data?: string | null
  created_at: string
}

export interface Team {
  id: string
  name: string
  description?: string
  manager_id?: string
  lead_id?: string
  member_ids: string[]
  is_active: boolean
  created_at: string
}

export interface PaginatedResponse<T> {
  items: T[]
  page: number
  page_size: number
}

export interface ApiError {
  detail: string
}
