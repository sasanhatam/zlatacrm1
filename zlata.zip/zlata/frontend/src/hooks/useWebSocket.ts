import { useEffect, useRef, useCallback } from 'react'
import { apiUrl } from '@/config'

interface UseWebSocketOptions {
  onMessage?: (data: unknown) => void
  onOpen?: () => void
  onClose?: () => void
}

export function useWebSocket(path: string | null, options: UseWebSocketOptions = {}) {
  const ws = useRef<WebSocket | null>(null)
  const reconnectTimer = useRef<ReturnType<typeof setTimeout>>()

  const connect = useCallback(() => {
    if (!path) return
    const token = localStorage.getItem('access_token')
    if (!token) return

    // اگر VITE_API_BASE_URL ست شده باشد (دیپلوی جدا مثل Netlify) آدرس کامل
    // ws(s)://backend-domain ساخته می‌شود، در غیر این صورت نسبی به همان دامنه فعلی.
    const resolved = apiUrl(path)
    const wsUrl = /^https?:\/\//.test(resolved)
      ? resolved.replace(/^http/, 'ws')
      : `${window.location.protocol === 'https:' ? 'wss' : 'ws'}://${window.location.host}${resolved}`
    const fullUrl = `${wsUrl}?token=${token}`

    ws.current = new WebSocket(fullUrl)

    ws.current.onopen = () => options.onOpen?.()

    ws.current.onmessage = (e) => {
      try {
        const data = JSON.parse(e.data)
        options.onMessage?.(data)
      } catch { /* ignore malformed */ }
    }

    ws.current.onclose = () => {
      options.onClose?.()
      // Reconnect after 3s
      reconnectTimer.current = setTimeout(connect, 3000)
    }

    ws.current.onerror = () => ws.current?.close()
  }, [path])

  useEffect(() => {
    connect()
    return () => {
      clearTimeout(reconnectTimer.current)
      ws.current?.close()
    }
  }, [connect])

  const send = useCallback((data: object) => {
    if (ws.current?.readyState === WebSocket.OPEN) {
      ws.current.send(JSON.stringify(data))
    }
  }, [])

  return { send }
}
