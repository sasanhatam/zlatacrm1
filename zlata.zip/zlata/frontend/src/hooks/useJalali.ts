import dayjs from 'dayjs'

// Persian month names
const MONTHS = ['فروردین','اردیبهشت','خرداد','تیر','مرداد','شهریور','مهر','آبان','آذر','دی','بهمن','اسفند']
const WEEK_DAYS = ['شنبه','یکشنبه','دوشنبه','سه‌شنبه','چهارشنبه','پنجشنبه','جمعه']

function toJalali(gy: number, gm: number, gd: number): [number, number, number] {
  const g_d_no = [31,28,31,30,31,30,31,31,30,31,30,31]
  const j_d_no = [31,31,31,31,31,31,30,30,30,30,30,29]
  if (gy > 1600) { gy -= 1600 } else { gy -= 1 }
  let g_day_no = 365*gy + Math.floor((gy+3)/4) - Math.floor((gy+99)/100) + Math.floor((gy+399)/400)
  for (let i=0; i<gm-1; i++) g_day_no += g_d_no[i]
  if (gm > 2 && ((gy+1) % 4 === 0 && ((gy+1) % 100 !== 0 || (gy+1) % 400 === 0))) g_day_no++
  g_day_no += gd - 1
  let j_day_no = g_day_no - 79
  let j_np = Math.floor(j_day_no / 12053); j_day_no %= 12053
  let jy = 979 + 33*j_np + 4*Math.floor(j_day_no/1461); j_day_no %= 1461
  if (j_day_no >= 366) { jy += Math.floor((j_day_no-1)/365); j_day_no = (j_day_no-1)%365 }
  let jm = 0, jd = 0, i = 0
  for (; i < 11 && j_day_no >= j_d_no[i]; i++) j_day_no -= j_d_no[i]
  jm = i + 1; jd = j_day_no + 1
  return [jy, jm, jd]
}

export function useJalali() {
  const format = (dateStr: string | undefined | null, showTime = false): string => {
    if (!dateStr) return '—'
    const d = new Date(dateStr)
    if (isNaN(d.getTime())) return '—'
    const [jy, jm, jd] = toJalali(d.getFullYear(), d.getMonth() + 1, d.getDate())
    const date = `${jy}/${String(jm).padStart(2,'0')}/${String(jd).padStart(2,'0')}`
    if (!showTime) return date
    const hours = String(d.getHours()).padStart(2,'0')
    const mins = String(d.getMinutes()).padStart(2,'0')
    return `${date} ${hours}:${mins}`
  }

  const fromNow = (dateStr: string | undefined | null): string => {
    if (!dateStr) return ''
    const diff = Date.now() - new Date(dateStr).getTime()
    const mins = Math.floor(diff / 60000)
    if (mins < 1) return 'لحظاتی پیش'
    if (mins < 60) return `${mins} دقیقه پیش`
    const hours = Math.floor(mins / 60)
    if (hours < 24) return `${hours} ساعت پیش`
    const days = Math.floor(hours / 24)
    if (days < 30) return `${days} روز پیش`
    return format(dateStr)
  }

  return { format, fromNow }
}
