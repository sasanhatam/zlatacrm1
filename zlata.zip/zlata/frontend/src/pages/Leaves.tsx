import { useState, useEffect } from 'react'
import {
  UmbrellaOff, Plus, CheckCircle, XCircle, Clock, RefreshCw,
  Calendar, AlertCircle,
} from 'lucide-react'
import { leavesApi, LeaveRequest, LeaveStatus, LeaveType, LeaveBalance } from '@/api/leaves'
import { useAuthStore } from '@/store/authStore'
import toast from 'react-hot-toast'
import clsx from 'clsx'
import { JalaliDatePicker } from '@/components/common/JalaliDatePicker'

// Convert "۱۴۰۳/۰۳/۲۵" to ISO date string
function jalaliToISO(jalaliStr: string): string | undefined {
  if (!jalaliStr) return undefined
  const latinized = jalaliStr.replace(/[۰-۹]/g, d => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)))
  const parts = latinized.split('/')
  if (parts.length !== 3) return undefined
  const [jy, jm, jd] = parts.map(Number)
  if (!jy || !jm || !jd) return undefined
  const j_d_no_arr = [31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29]
  let j_day_no = 365 * (jy - 979) + Math.floor((jy - 979) / 4) - Math.floor((jy - 979) / 100) + Math.floor((jy - 979) / 400)
  for (let i = 0; i < jm - 1; i++) j_day_no += j_d_no_arr[i]
  j_day_no += jd - 1
  let g_day_no = j_day_no + 79
  let gy = 1600 + 400 * Math.floor(g_day_no / 146097); g_day_no %= 146097
  let leap = true
  if (g_day_no >= 36525) {
    g_day_no--; gy += 100 * Math.floor(g_day_no / 36524); g_day_no %= 36524
    if (g_day_no >= 365) g_day_no++; else leap = false
  }
  gy += 4 * Math.floor(g_day_no / 1461); g_day_no %= 1461
  if (g_day_no >= 366) { leap = false; g_day_no--; gy += Math.floor(g_day_no / 365); g_day_no %= 365 }
  const g_d_no_arr = [31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
  let gm = 0
  for (gm = 0; gm < 12; gm++) { if (g_day_no < g_d_no_arr[gm]) break; g_day_no -= g_d_no_arr[gm] }
  return new Date(gy, gm, g_day_no + 1, 0, 0, 0).toISOString()
}

const STATUS_LABELS: Record<LeaveStatus, string> = {
  pending: 'در انتظار', approved: 'تأیید شده',
  rejected: 'رد شده', cancelled: 'لغو شده',
}
const STATUS_COLORS: Record<LeaveStatus, string> = {
  pending: 'bg-yellow-100 text-yellow-700',
  approved: 'bg-green-100 text-green-700',
  rejected: 'bg-red-100 text-red-700',
  cancelled: 'bg-gray-100 text-gray-600',
}
const TYPE_LABELS: Record<LeaveType, string> = {
  annual: 'مرخصی سالیانه', sick: 'استعلاجی',
  maternity: 'زایمان', emergency: 'اضطراری',
  unpaid: 'بدون حقوق', hourly: 'ساعتی',
}

function LeaveCard({ leave, onReview, isManager }: {
  leave: LeaveRequest
  onReview?: (id: string, approved: boolean) => void
  isManager?: boolean
}) {
  return (
    <div className="bg-white rounded-xl border border-gray-100 p-4">
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-1">
            {leave.user_name && <span className="font-medium text-gray-900">{leave.user_name}</span>}
            <span className="text-sm text-gray-500">{TYPE_LABELS[leave.leave_type]}</span>
            <span className={clsx('text-xs px-2 py-0.5 rounded-full font-medium', STATUS_COLORS[leave.status])}>
              {STATUS_LABELS[leave.status]}
            </span>
          </div>
          <div className="flex items-center gap-3 text-sm text-gray-500">
            <span className="flex items-center gap-1">
              <Calendar size={13} />
              {new Date(leave.start_date).toLocaleDateString('fa-IR')}
              {leave.start_date !== leave.end_date && ` - ${new Date(leave.end_date).toLocaleDateString('fa-IR')}`}
            </span>
            <span>{leave.days_count} روز</span>
          </div>
          {leave.reason && <p className="text-sm text-gray-600 mt-1">دلیل: {leave.reason}</p>}
          {leave.manager_note && (
            <p className="text-sm text-gray-500 mt-1 bg-gray-50 rounded px-2 py-1">
              یادداشت مدیر: {leave.manager_note}
            </p>
          )}
        </div>

        {isManager && leave.status === 'pending' && onReview && (
          <div className="flex gap-1.5 shrink-0">
            <button
              onClick={() => onReview(leave.id, true)}
              className="flex items-center gap-1 bg-green-100 text-green-700 px-3 py-1.5 rounded-lg text-xs hover:bg-green-200 font-medium"
            >
              <CheckCircle size={13} /> تأیید
            </button>
            <button
              onClick={() => onReview(leave.id, false)}
              className="flex items-center gap-1 bg-red-100 text-red-700 px-3 py-1.5 rounded-lg text-xs hover:bg-red-200 font-medium"
            >
              <XCircle size={13} /> رد
            </button>
          </div>
        )}
      </div>
    </div>
  )
}

function NewLeaveModal({ onClose, onSaved }: { onClose: () => void; onSaved: () => void }) {
  const [form, setForm] = useState({
    leave_type: 'annual' as LeaveType,
    start_date: '',
    end_date: '',
    days_count: 1,
    reason: '',
  })
  const [saving, setSaving] = useState(false)

  const save = async () => {
    if (!form.start_date || !form.end_date) {
      return toast.error('تاریخ شروع و پایان الزامی است')
    }
    const startISO = jalaliToISO(form.start_date)
    const endISO = jalaliToISO(form.end_date)
    if (!startISO || !endISO) {
      return toast.error('فرمت تاریخ نامعتبر است')
    }
    setSaving(true)
    try {
      await leavesApi.request({
        ...form,
        start_date: startISO,
        end_date: endISO,
      })
      toast.success('درخواست مرخصی ثبت شد')
      onSaved()
    } catch (e: any) {
      toast.error(e.response?.data?.detail || 'خطا')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4" dir="rtl">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md">
        <div className="flex items-center justify-between px-6 py-4 border-b">
          <h2 className="text-lg font-bold text-gray-900">درخواست مرخصی</h2>
          <button onClick={onClose} className="p-1.5 hover:bg-gray-100 rounded-lg">
            <XCircle size={18} className="text-gray-400" />
          </button>
        </div>

        <div className="p-6 space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">نوع مرخصی</label>
            <select value={form.leave_type}
              onChange={e => setForm(f => ({ ...f, leave_type: e.target.value as LeaveType }))}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary-300">
              {Object.entries(TYPE_LABELS).map(([k, v]) => (
                <option key={k} value={k}>{v}</option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">از تاریخ *</label>
              <JalaliDatePicker
                value={form.start_date}
                onChange={v => setForm(f => ({ ...f, start_date: v }))}
                placeholder="تاریخ شروع"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">تا تاریخ *</label>
              <JalaliDatePicker
                value={form.end_date}
                onChange={v => setForm(f => ({ ...f, end_date: v }))}
                placeholder="تاریخ پایان"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">تعداد روز</label>
            <input type="number" min="0.5" step="0.5" value={form.days_count}
              onChange={e => setForm(f => ({ ...f, days_count: parseFloat(e.target.value) }))}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary-300" />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">دلیل (اختیاری)</label>
            <textarea value={form.reason} onChange={e => setForm(f => ({ ...f, reason: e.target.value }))}
              rows={2}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-primary-300"
              placeholder="دلیل درخواست مرخصی" />
          </div>
        </div>

        <div className="flex items-center justify-end gap-3 px-6 py-4 border-t bg-gray-50 rounded-b-2xl">
          <button onClick={onClose} className="text-sm text-gray-500 hover:text-gray-700">انصراف</button>
          <button onClick={save} disabled={saving}
            className="flex items-center gap-2 bg-primary-600 text-white px-5 py-2 rounded-lg text-sm hover:bg-primary-700 disabled:opacity-50">
            {saving ? <RefreshCw size={14} className="animate-spin" /> : <Plus size={14} />}
            ثبت درخواست
          </button>
        </div>
      </div>
    </div>
  )
}

function RejectLeaveModal({ leaveId, onClose, onDone }: {
  leaveId: string
  onClose: () => void
  onDone: () => void
}) {
  const [note, setNote] = useState('')
  const [saving, setSaving] = useState(false)

  const submit = async () => {
    setSaving(true)
    try {
      await leavesApi.review(leaveId, false, note || undefined)
      toast.success('مرخصی رد شد')
      onDone()
    } catch (e: any) {
      toast.error(e.response?.data?.detail || 'خطا')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4" dir="rtl">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm">
        <div className="flex items-center justify-between px-5 py-4 border-b">
          <h2 className="text-base font-bold text-gray-900">رد درخواست مرخصی</h2>
          <button onClick={onClose} className="p-1.5 hover:bg-gray-100 rounded-lg">
            <XCircle size={18} className="text-gray-400" />
          </button>
        </div>
        <div className="p-5 space-y-3">
          <p className="text-sm text-gray-600">دلیل رد درخواست را وارد کنید (اختیاری):</p>
          <textarea
            value={note}
            onChange={e => setNote(e.target.value)}
            rows={3}
            autoFocus
            className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-red-300"
            placeholder="توضیحات برای کارمند..."
          />
        </div>
        <div className="flex items-center justify-end gap-3 px-5 py-4 border-t bg-gray-50 rounded-b-2xl">
          <button onClick={onClose} className="text-sm text-gray-500 hover:text-gray-700">انصراف</button>
          <button onClick={submit} disabled={saving}
            className="flex items-center gap-2 bg-red-600 text-white px-4 py-2 rounded-lg text-sm hover:bg-red-700 disabled:opacity-50">
            {saving ? <RefreshCw size={13} className="animate-spin" /> : <XCircle size={13} />}
            رد درخواست
          </button>
        </div>
      </div>
    </div>
  )
}

export default function Leaves() {
  const { user } = useAuthStore()
  const isManager = user?.role === 'super_admin' || user?.role === 'manager' || user?.role === 'team_lead'

  const [leaves, setLeaves] = useState<LeaveRequest[]>([])
  const [teamLeaves, setTeamLeaves] = useState<LeaveRequest[]>([])
  const [balance, setBalance] = useState<LeaveBalance | null>(null)
  const [loading, setLoading] = useState(true)
  const [showNew, setShowNew] = useState(false)
  const [rejectingId, setRejectingId] = useState<string | null>(null)
  const [tab, setTab] = useState<'mine' | 'team'>('mine')

  const load = async () => {
    setLoading(true)
    try {
      const [leavesRes, balanceRes] = await Promise.all([
        leavesApi.list(),
        leavesApi.balance(),
      ])
      setLeaves(leavesRes.data)
      setBalance(balanceRes.data)
      if (isManager) {
        const teamRes = await leavesApi.teamLeaves()
        setTeamLeaves(teamRes.data)
      }
    } catch {
      toast.error('خطا در دریافت اطلاعات')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { load() }, [])

  const handleReview = async (id: string, approved: boolean) => {
    if (!approved) {
      setRejectingId(id)
      return
    }
    try {
      await leavesApi.review(id, true)
      toast.success('مرخصی تأیید شد')
      load()
    } catch (e: any) {
      toast.error(e.response?.data?.detail || 'خطا')
    }
  }

  return (
    <div className="p-6 max-w-4xl mx-auto" dir="rtl">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <UmbrellaOff size={24} className="text-primary-600" />
          <h1 className="text-2xl font-bold text-gray-900">مدیریت مرخصی</h1>
        </div>
        <button onClick={() => setShowNew(true)}
          className="flex items-center gap-2 bg-primary-600 text-white px-4 py-2 rounded-lg text-sm hover:bg-primary-700">
          <Plus size={15} />
          درخواست مرخصی
        </button>
      </div>

      {/* Balance card */}
      {balance && (
        <div className="grid grid-cols-3 gap-4 mb-6">
          <div className="bg-white rounded-xl border border-gray-100 p-4 text-center">
            <p className="text-3xl font-bold text-primary-600">{balance.annual_total}</p>
            <p className="text-sm text-gray-500 mt-1">کل مرخصی سالیانه</p>
          </div>
          <div className="bg-white rounded-xl border border-gray-100 p-4 text-center">
            <p className="text-3xl font-bold text-orange-500">{balance.annual_used}</p>
            <p className="text-sm text-gray-500 mt-1">استفاده شده</p>
          </div>
          <div className="bg-white rounded-xl border border-gray-100 p-4 text-center">
            <p className="text-3xl font-bold text-green-600">{balance.remaining}</p>
            <p className="text-sm text-gray-500 mt-1">باقی‌مانده</p>
          </div>
        </div>
      )}

      {/* Tabs */}
      {isManager && (
        <div className="flex gap-2 mb-4">
          {[{ key: 'mine', label: 'درخواست‌های من' }, { key: 'team', label: 'مرخصی تیم' }].map(t => (
            <button key={t.key} onClick={() => setTab(t.key as any)}
              className={clsx(
                'px-3 py-1.5 rounded-lg text-sm font-medium transition-colors',
                tab === t.key ? 'bg-primary-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              )}>
              {t.label}
            </button>
          ))}
        </div>
      )}

      {loading ? (
        <div className="flex justify-center py-16">
          <RefreshCw size={28} className="animate-spin text-primary-400" />
        </div>
      ) : (
        <div className="space-y-3">
          {(tab === 'mine' ? leaves : teamLeaves).length === 0 ? (
            <div className="text-center py-16 text-gray-400">
              <UmbrellaOff size={48} className="mx-auto mb-3 opacity-20" />
              <p>درخواست مرخصی‌ای یافت نشد</p>
            </div>
          ) : (
            (tab === 'mine' ? leaves : teamLeaves).map(leave => (
              <LeaveCard
                key={leave.id}
                leave={leave}
                isManager={tab === 'team' && isManager}
                onReview={handleReview}
              />
            ))
          )}
        </div>
      )}

      {showNew && (
        <NewLeaveModal
          onClose={() => setShowNew(false)}
          onSaved={() => { setShowNew(false); load() }}
        />
      )}

      {rejectingId && (
        <RejectLeaveModal
          leaveId={rejectingId}
          onClose={() => setRejectingId(null)}
          onDone={() => { setRejectingId(null); load() }}
        />
      )}
    </div>
  )
}
