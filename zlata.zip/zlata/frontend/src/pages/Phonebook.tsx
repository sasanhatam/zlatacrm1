import { useState, useEffect } from 'react'
import { usersApi } from '@/api/users'
import { useAuthStore } from '@/store/authStore'
import { Team } from '@/types/common'
import { Avatar } from '@/components/common/Avatar'
import {
  Phone, Mail, Hash, Search, Users, X, Edit2, Save, ChevronLeft,
} from 'lucide-react'
import toast from 'react-hot-toast'
import api from '@/api/client'

interface PhonebookEntry {
  id: string
  full_name: string
  email: string
  position?: string
  teams: { id: string; name: string }[]
  extension_number?: string
  mobile?: string
  role: string
}

const ROLE_LABELS: Record<string, string> = {
  super_admin: 'مدیر کل',
  manager: 'مدیر',
  team_lead: 'سرتیم',
  member: 'کارمند',
}

function DetailModal({ entry, canEdit, isSelf, onClose, onSaved }: {
  entry: PhonebookEntry
  canEdit: boolean
  isSelf: boolean
  onClose: () => void
  onSaved: (updated: PhonebookEntry) => void
}) {
  const [editing, setEditing] = useState(false)
  const [form, setForm] = useState({
    full_name: entry.full_name,
    position: entry.position || '',
    mobile: entry.mobile || '',
    extension_number: entry.extension_number || '',
  })
  const [saving, setSaving] = useState(false)

  const save = async () => {
    setSaving(true)
    try {
      // self-edit uses /me/profile, admin editing others uses /users/{id}
      if (isSelf) {
        await api.put('/users/me/profile', form)
      } else {
        await api.put(`/users/${entry.id}`, form)
      }
      toast.success('اطلاعات ذخیره شد')
      onSaved({ ...entry, ...form })
      setEditing(false)
    } catch {
      toast.error('خطا در ذخیره')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4" dir="rtl">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md">
        <div className="flex items-center justify-between px-6 py-4 border-b">
          <div className="flex items-center gap-3">
            <Avatar name={entry.full_name} size="md" />
            <div>
              {editing
                ? <input value={form.full_name} onChange={e => setForm(f => ({ ...f, full_name: e.target.value }))}
                    className="font-bold text-gray-900 border-b border-primary-300 focus:outline-none bg-transparent" />
                : <h2 className="font-bold text-gray-900">{entry.full_name}</h2>
              }
              <p className="text-xs text-gray-400">{ROLE_LABELS[entry.role] || entry.role}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {canEdit && !editing && (
              <button onClick={() => setEditing(true)}
                className="p-1.5 hover:bg-gray-100 rounded-lg text-gray-400 hover:text-primary-600">
                <Edit2 size={15} />
              </button>
            )}
            <button onClick={onClose} className="p-1.5 hover:bg-gray-100 rounded-lg">
              <X size={18} className="text-gray-400" />
            </button>
          </div>
        </div>

        <div className="p-6 space-y-4">
          {/* Teams */}
          {entry.teams.length > 0 && (
            <div className="flex flex-wrap gap-1.5">
              {entry.teams.map(t => (
                <span key={t.id} className="text-xs bg-primary-50 text-primary-700 px-2.5 py-1 rounded-full font-medium">
                  {t.name}
                </span>
              ))}
            </div>
          )}

          {/* Fields */}
          <div className="space-y-3">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-gray-100 rounded-lg flex items-center justify-center flex-shrink-0">
                <Users size={14} className="text-gray-500" />
              </div>
              <div className="flex-1">
                <p className="text-xs text-gray-400 mb-0.5">سمت</p>
                {editing
                  ? <input value={form.position} onChange={e => setForm(f => ({ ...f, position: e.target.value }))}
                      placeholder="سمت شغلی"
                      className="w-full text-sm border border-gray-200 rounded-lg px-2 py-1 focus:outline-none focus:ring-2 focus:ring-primary-300" />
                  : <p className="text-sm text-gray-800">{entry.position || '—'}</p>
                }
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-blue-50 rounded-lg flex items-center justify-center flex-shrink-0">
                <Hash size={14} className="text-blue-500" />
              </div>
              <div className="flex-1">
                <p className="text-xs text-gray-400 mb-0.5">داخلی</p>
                {editing
                  ? <input value={form.extension_number} onChange={e => setForm(f => ({ ...f, extension_number: e.target.value }))}
                      placeholder="شماره داخلی"
                      className="w-full text-sm border border-gray-200 rounded-lg px-2 py-1 focus:outline-none focus:ring-2 focus:ring-primary-300"
                      dir="ltr" />
                  : <p className="text-sm text-gray-800 font-mono">{entry.extension_number || '—'}</p>
                }
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-green-50 rounded-lg flex items-center justify-center flex-shrink-0">
                <Phone size={14} className="text-green-500" />
              </div>
              <div className="flex-1">
                <p className="text-xs text-gray-400 mb-0.5">موبایل</p>
                {editing
                  ? <input value={form.mobile} onChange={e => setForm(f => ({ ...f, mobile: e.target.value }))}
                      placeholder="شماره موبایل"
                      className="w-full text-sm border border-gray-200 rounded-lg px-2 py-1 focus:outline-none focus:ring-2 focus:ring-primary-300"
                      dir="ltr" />
                  : entry.mobile
                    ? <a href={`tel:${entry.mobile}`} className="text-sm text-primary-600 hover:underline font-mono" dir="ltr">{entry.mobile}</a>
                    : <p className="text-sm text-gray-800">—</p>
                }
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-orange-50 rounded-lg flex items-center justify-center flex-shrink-0">
                <Mail size={14} className="text-orange-500" />
              </div>
              <div className="flex-1">
                <p className="text-xs text-gray-400 mb-0.5">ایمیل</p>
                <a href={`mailto:${entry.email}`} className="text-sm text-primary-600 hover:underline" dir="ltr">{entry.email}</a>
              </div>
            </div>
          </div>
        </div>

        {editing && (
          <div className="flex items-center gap-3 px-6 py-4 border-t bg-gray-50 rounded-b-2xl">
            <button onClick={() => setEditing(false)} className="flex-1 py-2 text-sm text-gray-500 hover:text-gray-700 border border-gray-200 rounded-lg">
              انصراف
            </button>
            <button onClick={save} disabled={saving}
              className="flex-1 flex items-center justify-center gap-2 bg-primary-600 text-white py-2 rounded-lg text-sm hover:bg-primary-700 disabled:opacity-50">
              <Save size={14} />
              {saving ? 'در حال ذخیره...' : 'ذخیره'}
            </button>
          </div>
        )}
      </div>
    </div>
  )
}

export default function Phonebook() {
  const { user: currentUser } = useAuthStore()
  const [entries, setEntries] = useState<PhonebookEntry[]>([])
  const [teams, setTeams] = useState<Team[]>([])
  const [search, setSearch] = useState('')
  const [teamFilter, setTeamFilter] = useState('')
  const [loading, setLoading] = useState(true)
  const [selected, setSelected] = useState<PhonebookEntry | null>(null)

  const canEdit = currentUser?.role === 'super_admin' || currentUser?.role === 'manager'

  useEffect(() => {
    Promise.all([
      usersApi.phonebook({ team_id: teamFilter || undefined, search: search || undefined }),
      usersApi.listTeams(),
    ]).then(([pbRes, teamRes]) => {
      setEntries(pbRes.data)
      setTeams(teamRes.data)
    }).finally(() => setLoading(false))
  }, [search, teamFilter])

  if (loading) return (
    <div className="flex items-center justify-center h-64">
      <div className="w-8 h-8 border-4 border-primary-500 border-t-transparent rounded-full animate-spin" />
    </div>
  )

  return (
    <div dir="rtl">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-gray-900">دفتر تلفن سازمانی</h1>
        <span className="text-sm text-gray-500">{entries.length} نفر</span>
      </div>

      <div className="flex gap-3 mb-6">
        <div className="relative flex-1 max-w-md">
          <Search size={15} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="جستجو بر اساس نام، سمت یا شماره..."
            className="input-field pr-9"
          />
        </div>
        <select value={teamFilter} onChange={e => setTeamFilter(e.target.value)} className="input-field w-auto">
          <option value="">همه تیم‌ها</option>
          {teams.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
        </select>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {entries.map(entry => (
          <button
            key={entry.id}
            onClick={() => setSelected(entry)}
            className="card p-5 hover:shadow-md hover:border-primary-200 transition-all text-right w-full group"
          >
            <div className="flex items-start gap-4">
              <Avatar name={entry.full_name} size="md" />
              <div className="flex-1 min-w-0">
                <h3 className="font-semibold text-gray-900 truncate group-hover:text-primary-600 transition-colors">
                  {entry.full_name}
                </h3>
                {entry.position && <p className="text-sm text-gray-500 truncate">{entry.position}</p>}
                <div className="flex flex-wrap gap-1 mt-1.5">
                  {entry.teams.map(t => (
                    <span key={t.id} className="text-xs bg-primary-50 text-primary-700 px-2 py-0.5 rounded-full">{t.name}</span>
                  ))}
                </div>
              </div>
              <ChevronLeft size={15} className="text-gray-300 group-hover:text-primary-400 transition-colors mt-1 flex-shrink-0" />
            </div>

            <div className="mt-4 space-y-2 text-sm">
              {entry.extension_number && (
                <div className="flex items-center gap-2 text-gray-600">
                  <Hash size={14} className="text-gray-400 flex-shrink-0" />
                  <span>داخلی: {entry.extension_number}</span>
                </div>
              )}
              {entry.mobile && (
                <div className="flex items-center gap-2 text-gray-600">
                  <Phone size={14} className="text-gray-400 flex-shrink-0" />
                  <span dir="ltr">{entry.mobile}</span>
                </div>
              )}
              <div className="flex items-center gap-2 text-gray-600">
                <Mail size={14} className="text-gray-400 flex-shrink-0" />
                <span className="truncate text-xs" dir="ltr">{entry.email}</span>
              </div>
            </div>
          </button>
        ))}
        {entries.length === 0 && (
          <div className="col-span-full text-center py-12 text-gray-400">
            <Users size={40} className="mx-auto mb-3 text-gray-200" />
            <p>کاربری یافت نشد</p>
          </div>
        )}
      </div>

      {selected && (
        <DetailModal
          entry={selected}
          canEdit={canEdit || selected.id === currentUser?.id}
          isSelf={selected.id === currentUser?.id}
          onClose={() => setSelected(null)}
          onSaved={updated => {
            setEntries(prev => prev.map(e => e.id === updated.id ? updated : e))
            setSelected(updated)
          }}
        />
      )}
    </div>
  )
}
