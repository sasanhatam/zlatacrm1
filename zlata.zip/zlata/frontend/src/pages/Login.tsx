import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuthStore } from '@/store/authStore'
import { authApi } from '@/api/auth'
import { Eye, EyeOff, Lock, Phone, X, UserPlus } from 'lucide-react'
import toast from 'react-hot-toast'

const REMEMBER_KEY = 'zlata_remembered'

function toLatinDigits(str: string): string {
  return str
    .replace(/[۰-۹]/g, d => String(d.charCodeAt(0) - 0x06F0))
    .replace(/[٠-٩]/g, d => String(d.charCodeAt(0) - 0x0660))
}

function RegisterModal({ onClose }: { onClose: () => void }) {
  const [form, setForm] = useState({ full_name: '', mobile: '', password: '', confirm: '' })
  const [loading, setLoading] = useState(false)
  const [showPass, setShowPass] = useState(false)
  const [companies, setCompanies] = useState<{ id: string; name: string }[]>([])
  const [selectedOrgs, setSelectedOrgs] = useState<string[]>([])

  const f = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = k === 'mobile' ? toLatinDigits(e.target.value) : e.target.value
    setForm(prev => ({ ...prev, [k]: val }))
  }

  const toggleOrg = (id: string) =>
    setSelectedOrgs(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (form.password !== form.confirm) { toast.error('رمزهای عبور یکسان نیستند'); return }
    if (form.password.length < 8) { toast.error('رمز عبور باید حداقل ۸ کاراکتر باشد'); return }
    if (selectedOrgs.length === 0) { toast.error('حداقل یک شرکت را انتخاب کنید'); return }
    setLoading(true)
    try {
      await authApi.registerRequest(form.full_name, form.mobile, form.password, selectedOrgs)
      toast.success('درخواست شما ثبت شد — پس از تایید مدیر می‌توانید وارد شوید')
      onClose()
    } catch (err: any) {
      toast.error(err?.response?.data?.detail || 'خطا در ارسال درخواست')
    } finally {
      setLoading(false)
    }
  }

  // Load companies on mount (public endpoint, no auth needed)
  const loadCompanies = () => {
    authApi.listCompaniesPublic().then(r => setCompanies(r.data)).catch(() => {})
  }
  if (companies.length === 0) loadCompanies()

  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4" dir="rtl">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md">
        <div className="flex items-center justify-between px-6 py-4 border-b">
          <h2 className="font-bold text-gray-900 flex items-center gap-2">
            <UserPlus size={18} className="text-primary-600" />
            درخواست افتتاح حساب
          </h2>
          <button onClick={onClose} className="p-1.5 hover:bg-gray-100 rounded-lg">
            <X size={18} className="text-gray-400" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">نام و نام خانوادگی</label>
            <input value={form.full_name} onChange={f('full_name')} required
              placeholder="علی احمدی" className="input-field w-full" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">شماره موبایل</label>
            <input value={form.mobile} onChange={f('mobile')} required
              placeholder="09xxxxxxxxx" className="input-field w-full" dir="ltr" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">رمز عبور</label>
            <div className="relative">
              <input type={showPass ? 'text' : 'password'} value={form.password} onChange={f('password')} required
                placeholder="حداقل ۸ کاراکتر" className="input-field w-full pl-9" dir="ltr" />
              <button type="button" onClick={() => setShowPass(v => !v)}
                className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                {showPass ? <EyeOff size={15} /> : <Eye size={15} />}
              </button>
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">تکرار رمز عبور</label>
            <input type="password" value={form.confirm} onChange={f('confirm')} required
              placeholder="تکرار رمز عبور" className="input-field w-full" dir="ltr" />
          </div>

          {companies.length > 0 && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">شرکت(ها) *</label>
              <div className="space-y-2">
                {companies.map(c => (
                  <label key={c.id} className="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" checked={selectedOrgs.includes(c.id)}
                      onChange={() => toggleOrg(c.id)}
                      className="w-4 h-4 text-primary-600 rounded focus:ring-primary-500" />
                    <span className="text-sm text-gray-700">{c.name}</span>
                  </label>
                ))}
              </div>
            </div>
          )}

          <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 text-sm text-amber-700">
            پس از ارسال درخواست، مدیر سیستم آن را بررسی می‌کند و در صورت تایید می‌توانید وارد شوید.
          </div>

          <div className="flex gap-3 pt-2">
            <button type="button" onClick={onClose}
              className="flex-1 py-2.5 text-sm text-gray-500 border border-gray-200 rounded-xl hover:bg-gray-50">
              انصراف
            </button>
            <button type="submit" disabled={loading}
              className="flex-1 btn-primary py-2.5 disabled:opacity-50">
              {loading ? 'در حال ارسال...' : 'ارسال درخواست'}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

export default function Login() {
  const [mobile, setMobile] = useState('')
  const [password, setPassword] = useState('')
  const [showPass, setShowPass] = useState(false)
  const [loading, setLoading] = useState(false)
  const [rememberMe, setRememberMe] = useState(false)
  const [showRegister, setShowRegister] = useState(false)
  const { login } = useAuthStore()
  const navigate = useNavigate()

  useEffect(() => {
    try {
      const saved = localStorage.getItem(REMEMBER_KEY)
      if (saved) {
        const { mobile: m, password: p } = JSON.parse(saved)
        setMobile(m || '')
        setPassword(p || '')
        setRememberMe(true)
      }
    } catch { /* ignore */ }
  }, [])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    try {
      if (rememberMe) {
        localStorage.setItem(REMEMBER_KEY, JSON.stringify({ mobile, password }))
      } else {
        localStorage.removeItem(REMEMBER_KEY)
      }
      await login(mobile, password)
      navigate('/')
    } catch (err: any) {
      const msg = err?.response?.data?.detail || 'شماره موبایل یا رمز عبور اشتباه است'
      toast.error(msg)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-600 to-primary-800 flex items-center justify-center p-4" dir="rtl">
      {showRegister && <RegisterModal onClose={() => setShowRegister(false)} />}

      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
            <span className="text-primary-600 font-bold text-2xl">Z</span>
          </div>
          <h1 className="text-2xl font-bold text-white">Zlata Management</h1>
          <p className="text-primary-200 mt-1 text-sm">سیستم مدیریت پروژه و سازمان</p>
        </div>

        <div className="bg-white rounded-2xl shadow-2xl p-8">
          <h2 className="text-xl font-bold text-gray-800 mb-6">ورود به سیستم</h2>

          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">شماره موبایل</label>
              <div className="relative">
                <Phone size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <input
                  type="tel"
                  value={mobile}
                  onChange={e => setMobile(toLatinDigits(e.target.value))}
                  required
                  placeholder="09xxxxxxxxx"
                  className="input-field pr-9"
                  dir="ltr"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">رمز عبور</label>
              <div className="relative">
                <Lock size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <input
                  type={showPass ? 'text' : 'password'}
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  required
                  placeholder="رمز عبور"
                  className="input-field pr-9 pl-9"
                  dir="ltr"
                />
                <button type="button" onClick={() => setShowPass(!showPass)}
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                  {showPass ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <input id="remember-me" type="checkbox" checked={rememberMe}
                onChange={e => { setRememberMe(e.target.checked); if (!e.target.checked) localStorage.removeItem(REMEMBER_KEY) }}
                className="w-4 h-4 text-primary-600 border-gray-300 rounded focus:ring-primary-500 cursor-pointer" />
              <label htmlFor="remember-me" className="text-sm text-gray-600 cursor-pointer select-none">مرا به خاطر بسپار</label>
            </div>

            <button type="submit" disabled={loading} className="btn-primary w-full py-3 text-base mt-2">
              {loading ? 'در حال ورود...' : 'ورود'}
            </button>
          </form>

          <div className="mt-5 pt-5 border-t border-gray-100 text-center">
            <button onClick={() => setShowRegister(true)}
              className="inline-flex items-center gap-2 text-sm text-primary-600 hover:text-primary-800 transition-colors">
              <UserPlus size={15} />
              درخواست افتتاح حساب کاربری
            </button>
          </div>

          <p className="text-center text-xs text-gray-400 mt-4">Zlata Management v1.0</p>
        </div>
      </div>
    </div>
  )
}
