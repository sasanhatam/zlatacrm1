import { useState, useEffect, useCallback } from 'react'
import { attendanceApi, TodayStatus, AttendanceRecord } from '@/api/attendance'
import { Clock, LogIn, LogOut, Calendar, AlertCircle } from 'lucide-react'
import toast from 'react-hot-toast'

function formatMinutes(min: number | null): string {
  if (!min) return '—'
  const h = Math.floor(min / 60)
  const m = min % 60
  if (h === 0) return `${m} دقیقه`
  return `${h} ساعت ${m > 0 ? `و ${m} دقیقه` : ''}`
}

function formatTime(iso: string | null): string {
  if (!iso) return '—'
  return new Date(iso).toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })
}

function LiveTimer({ clockIn }: { clockIn: string }) {
  const [elapsed, setElapsed] = useState(0)

  useEffect(() => {
    const start = new Date(clockIn).getTime()
    const tick = () => setElapsed(Math.floor((Date.now() - start) / 60000))
    tick()
    const id = setInterval(tick, 10000)
    return () => clearInterval(id)
  }, [clockIn])

  return <span className="font-mono text-primary-700 font-bold">{formatMinutes(elapsed)}</span>
}

export default function Attendance() {
  const [todayStatus, setTodayStatus] = useState<TodayStatus | null>(null)
  const [myRecords, setMyRecords] = useState<AttendanceRecord[]>([])
  const [loading, setLoading] = useState(true)
  const [actionLoading, setActionLoading] = useState(false)
  const [fromDate, setFromDate] = useState('')
  const [toDate, setToDate] = useState('')

  const loadToday = useCallback(async () => {
    try {
      const r = await attendanceApi.today()
      setTodayStatus(r.data)
    } catch {
      toast.error('خطا در بارگذاری وضعیت امروز')
    }
  }, [])

  const loadMyRecords = useCallback(async () => {
    try {
      const params: Record<string, string> = {}
      if (fromDate) params.from_date = fromDate
      if (toDate) params.to_date = toDate
      const r = await attendanceApi.myRecords(params)
      setMyRecords(r.data.items)
    } catch { /* ignore */ }
  }, [fromDate, toDate])

  useEffect(() => {
    Promise.all([loadToday(), loadMyRecords()]).finally(() => setLoading(false))
  }, [])

  useEffect(() => { loadMyRecords() }, [fromDate, toDate])

  const handleClockIn = async () => {
    setActionLoading(true)
    try {
      await attendanceApi.clockIn()
      toast.success('شروع به کار ثبت شد')
      await loadToday()
      await loadMyRecords()
    } catch (e: any) {
      toast.error(e?.response?.data?.detail || 'خطا در ثبت ورود')
    } finally {
      setActionLoading(false)
    }
  }

  const handleClockOut = async () => {
    setActionLoading(true)
    try {
      await attendanceApi.clockOut()
      toast.success('خروج از کار ثبت شد')
      await loadToday()
      await loadMyRecords()
    } catch (e: any) {
      toast.error(e?.response?.data?.detail || 'خطا در ثبت خروج')
    } finally {
      setActionLoading(false)
    }
  }

  if (loading) return (
    <div className="flex items-center justify-center h-64">
      <div className="w-8 h-8 border-4 border-primary-500 border-t-transparent rounded-full animate-spin" />
    </div>
  )

  const isClockedIn = todayStatus?.is_clocked_in ?? false
  const activeRecord = todayStatus?.active_record ?? null

  return (
    <div className="max-w-2xl mx-auto p-4 md:p-6 space-y-6" dir="rtl">
      <div className="flex items-center gap-3">
        <Clock size={22} className="text-primary-600" />
        <h1 className="text-xl font-bold text-gray-900">حضور و غیاب</h1>
      </div>

      {/* Today card */}
      <div className={[
        'card p-6 text-center border-2 transition-colors',
        isClockedIn ? 'border-green-400 bg-green-50' : 'border-gray-200',
      ].join(' ')}>
        <div className="text-sm text-gray-500 mb-1">{todayStatus?.records[0]?.jalali_date || 'امروز'}</div>

        {isClockedIn && activeRecord ? (
          <>
            <div className="text-green-600 font-bold text-lg mb-1">در حال کار</div>
            <div className="text-4xl font-bold text-gray-900 mb-1">
              <LiveTimer clockIn={activeRecord.clock_in!} />
            </div>
            <div className="text-sm text-gray-500 mb-6">
              شروع: {formatTime(activeRecord.clock_in)}
            </div>
            <button
              onClick={handleClockOut}
              disabled={actionLoading}
              className="inline-flex items-center gap-2 bg-red-500 hover:bg-red-600 text-white font-bold px-8 py-3 rounded-xl text-base transition-colors disabled:opacity-50 shadow-lg"
            >
              <LogOut size={20} />
              {actionLoading ? 'در حال ثبت...' : 'خروج از کار'}
            </button>
          </>
        ) : (
          <>
            <div className="text-gray-400 text-lg mb-1">
              {todayStatus && todayStatus.records.length > 0 ? 'پایان کار روز' : 'هنوز شروع نکرده‌اید'}
            </div>
            {todayStatus && todayStatus.total_minutes_today > 0 && (
              <div className="text-2xl font-bold text-gray-700 mb-1">
                مجموع امروز: {formatMinutes(todayStatus.total_minutes_today)}
              </div>
            )}
            <div className="mb-6" />
            <button
              onClick={handleClockIn}
              disabled={actionLoading}
              className="inline-flex items-center gap-2 bg-green-500 hover:bg-green-600 text-white font-bold px-8 py-3 rounded-xl text-base transition-colors disabled:opacity-50 shadow-lg"
            >
              <LogIn size={20} />
              {actionLoading ? 'در حال ثبت...' : 'شروع به کار'}
            </button>
          </>
        )}

        {/* Today's records list */}
        {todayStatus && todayStatus.records.length > 0 && (
          <div className="mt-6 text-right space-y-2">
            <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">رکوردهای امروز</p>
            {todayStatus.records.map(r => (
              <div key={r.id} className="flex items-center justify-between bg-white border border-gray-200 rounded-lg px-3 py-2 text-sm">
                <div className="flex items-center gap-3">
                  <span className="text-gray-600">ورود: <span className="font-mono text-gray-900">{formatTime(r.clock_in)}</span></span>
                  {r.clock_out && <span className="text-gray-600">خروج: <span className="font-mono text-gray-900">{formatTime(r.clock_out)}</span></span>}
                  {!r.clock_out && <span className="inline-block w-2 h-2 bg-green-500 rounded-full animate-pulse" />}
                </div>
                <span className="text-primary-600 font-medium">{formatMinutes(r.duration_minutes)}</span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* My records */}
      <div className="card p-6">
        <div className="flex items-center justify-between mb-4 flex-wrap gap-3">
          <h2 className="font-bold text-gray-800 flex items-center gap-2">
            <Calendar size={16} className="text-primary-600" />
            سابقه حضور
          </h2>
          <div className="flex gap-2 flex-wrap">
            <div>
              <label className="block text-xs text-gray-500 mb-1">از تاریخ</label>
              <input type="date" value={fromDate} onChange={e => setFromDate(e.target.value)}
                className="input-field text-sm" dir="ltr" />
            </div>
            <div>
              <label className="block text-xs text-gray-500 mb-1">تا تاریخ</label>
              <input type="date" value={toDate} onChange={e => setToDate(e.target.value)}
                className="input-field text-sm" dir="ltr" />
            </div>
          </div>
        </div>

        {myRecords.length === 0 ? (
          <div className="text-center py-10 text-gray-400">
            <AlertCircle size={32} className="mx-auto mb-2 opacity-30" />
            <p className="text-sm">رکوردی یافت نشد</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="text-right px-3 py-2.5 text-gray-600 font-medium">تاریخ</th>
                  <th className="text-right px-3 py-2.5 text-gray-600 font-medium">ورود</th>
                  <th className="text-right px-3 py-2.5 text-gray-600 font-medium">خروج</th>
                  <th className="text-right px-3 py-2.5 text-gray-600 font-medium">مدت کار</th>
                  <th className="text-right px-3 py-2.5 text-gray-600 font-medium">وضعیت</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {myRecords.map(r => (
                  <tr key={r.id} className="hover:bg-gray-50">
                    <td className="px-3 py-2.5 text-gray-800 font-mono text-xs">{r.jalali_date}</td>
                    <td className="px-3 py-2.5 text-gray-700 font-mono">{formatTime(r.clock_in)}</td>
                    <td className="px-3 py-2.5 text-gray-700 font-mono">{formatTime(r.clock_out)}</td>
                    <td className="px-3 py-2.5 text-primary-700 font-medium">{formatMinutes(r.duration_minutes)}</td>
                    <td className="px-3 py-2.5">
                      {r.is_active
                        ? <span className="inline-flex items-center gap-1 text-xs text-green-700 bg-green-100 px-2 py-0.5 rounded-full"><span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse" />فعال</span>
                        : <span className="text-xs text-gray-500">تمام شد</span>
                      }
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  )
}
