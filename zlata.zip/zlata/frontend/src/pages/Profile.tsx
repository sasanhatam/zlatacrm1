import { useState, useRef, useEffect } from 'react'
import { useAuthStore } from '@/store/authStore'
import { usersApi } from '@/api/users'
import { authApi } from '@/api/auth'
import api from '@/api/client'
import { Avatar } from '@/components/common/Avatar'
import { Save, Upload, Lock, PenLine, Trash2, Check, Stamp } from 'lucide-react'
import toast from 'react-hot-toast'

export default function Profile() {
  const { user, loadMe } = useAuthStore()
  const [form, setForm] = useState({
    full_name: user?.full_name || '',
    position: user?.position || '',
    mobile: user?.mobile || '',
    notification_email: user?.notification_email || '',
    email_notifications_enabled: user?.email_notifications_enabled ?? true,
    notification_preferences: user?.notification_preferences || {},
  })
  const [pwForm, setPwForm] = useState({ current_password: '', new_password: '', confirm: '' })
  const [saving, setSaving] = useState(false)
  const [changingPw, setChangingPw] = useState(false)

  // Signature state
  const [signatureData, setSignatureData] = useState<string | null>(null)
  const [sigMode, setSigMode] = useState<'upload' | 'draw' | null>(null)
  const [loadingSig, setLoadingSig] = useState(false)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const isDrawing = useRef(false)
  const lastPos = useRef<{ x: number; y: number } | null>(null)

  // Stamp state
  const [stampData, setStampData] = useState<string | null>(null)
  const [loadingStamp, setLoadingStamp] = useState(false)
  const isManagerRole = user?.role === 'super_admin' || user?.role === 'manager'

  useEffect(() => {
    api.get('/users/me/signature').then(r => {
      if (r.data.signature_data) setSignatureData(r.data.signature_data)
    }).catch(() => {})
    if (isManagerRole) {
      api.get('/users/me/stamp').then(r => {
        if (r.data.stamp_data) setStampData(r.data.stamp_data)
      }).catch(() => {})
    }
  }, [])

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault()
    setSaving(true)
    try {
      await usersApi.updateMyProfile(form as any)
      await loadMe()
      toast.success('پروفایل به‌روز شد')
    } catch { toast.error('خطا در ذخیره') }
    finally { setSaving(false) }
  }

  const handlePwChange = async (e: React.FormEvent) => {
    e.preventDefault()
    if (pwForm.new_password !== pwForm.confirm) { toast.error('رمزهای جدید مطابقت ندارند'); return }
    setChangingPw(true)
    try {
      await authApi.changePassword(pwForm.current_password, pwForm.new_password)
      toast.success('رمز عبور تغییر کرد')
      setPwForm({ current_password: '', new_password: '', confirm: '' })
    } catch { toast.error('رمز عبور فعلی اشتباه است') }
    finally { setChangingPw(false) }
  }

  const handleAvatarUpload = async (file: File) => {
    try {
      await usersApi.uploadAvatar(file)
      await loadMe()
      toast.success('تصویر پروفایل به‌روز شد')
    } catch { toast.error('خطا در آپلود تصویر') }
  }

  const handleSignatureUpload = async (file: File) => {
    setLoadingSig(true)
    try {
      const form = new FormData()
      form.append('file', file)
      const res = await api.post('/users/me/signature', form, { headers: { 'Content-Type': 'multipart/form-data' } })
      setSignatureData(res.data.signature_data)
      setSigMode(null)
      toast.success('امضا آپلود شد')
    } catch { toast.error('خطا در آپلود امضا') }
    finally { setLoadingSig(false) }
  }

  const handleDeleteSignature = async () => {
    setLoadingSig(true)
    try {
      await api.delete('/users/me/signature')
      setSignatureData(null)
      toast.success('امضا حذف شد')
    } catch { toast.error('خطا در حذف امضا') }
    finally { setLoadingSig(false) }
  }

  const handleStampUpload = async (file: File) => {
    setLoadingStamp(true)
    try {
      const formData = new FormData()
      formData.append('file', file)
      const res = await api.post('/users/me/stamp', formData, { headers: { 'Content-Type': 'multipart/form-data' } })
      setStampData(res.data.stamp_data)
      toast.success('مهر شخصی آپلود شد')
    } catch (e: any) { toast.error(e.response?.data?.detail || 'خطا در آپلود مهر') }
    finally { setLoadingStamp(false) }
  }

  const handleDeleteStamp = async () => {
    setLoadingStamp(true)
    try {
      await api.delete('/users/me/stamp')
      setStampData(null)
      toast.success('مهر شخصی حذف شد')
    } catch { toast.error('خطا در حذف مهر') }
    finally { setLoadingStamp(false) }
  }

  // Canvas draw handlers
  const startDraw = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    isDrawing.current = true
    const canvas = canvasRef.current
    if (!canvas) return
    const rect = canvas.getBoundingClientRect()
    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX
    const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY
    lastPos.current = { x: clientX - rect.left, y: clientY - rect.top }
  }

  const draw = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!isDrawing.current || !canvasRef.current || !lastPos.current) return
    e.preventDefault()
    const canvas = canvasRef.current
    const ctx = canvas.getContext('2d')
    if (!ctx) return
    const rect = canvas.getBoundingClientRect()
    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX
    const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY
    const x = clientX - rect.left
    const y = clientY - rect.top
    ctx.beginPath()
    ctx.moveTo(lastPos.current.x, lastPos.current.y)
    ctx.lineTo(x, y)
    ctx.strokeStyle = '#1a1a2e'
    ctx.lineWidth = 2.5
    ctx.lineCap = 'round'
    ctx.lineJoin = 'round'
    ctx.stroke()
    lastPos.current = { x, y }
  }

  const endDraw = () => { isDrawing.current = false; lastPos.current = null }

  const clearCanvas = () => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (ctx) ctx.clearRect(0, 0, canvas.width, canvas.height)
  }

  const saveDrawnSignature = async () => {
    const canvas = canvasRef.current
    if (!canvas) return
    const dataUrl = canvas.toDataURL('image/png')
    setLoadingSig(true)
    try {
      await api.post('/users/me/signature/draw', { signature_data: dataUrl })
      setSignatureData(dataUrl)
      setSigMode(null)
      toast.success('امضا ذخیره شد')
    } catch { toast.error('خطا در ذخیره امضا') }
    finally { setLoadingSig(false) }
  }

  const NOTIF_LABELS: Record<string, string> = {
    deadline_reminder: 'یادآوری ددلاین',
    overdue_alert: 'هشدار تسک معوق',
    daily_summary: 'خلاصه روزانه',
    weekly_summary: 'خلاصه هفتگی',
    mention_alert: 'اعلان منشن',
    task_assigned: 'اعلان محول شدن تسک',
  }

  if (!user) return null

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <h1 className="text-2xl font-bold text-gray-900">پروفایل من</h1>

      {/* Avatar */}
      <div className="card p-6 flex items-center gap-6">
        <div className="relative">
          <Avatar name={user.full_name} size="lg" />
          <label className="absolute -bottom-1 -left-1 w-7 h-7 bg-primary-600 rounded-full flex items-center justify-center cursor-pointer hover:bg-primary-700 transition-colors">
            <Upload size={12} className="text-white" />
            <input type="file" className="hidden" accept="image/*" onChange={e => e.target.files?.[0] && handleAvatarUpload(e.target.files[0])} />
          </label>
        </div>
        <div>
          <h2 className="text-lg font-bold text-gray-900">{user.full_name}</h2>
          <p className="text-gray-500 text-sm">{user.position}</p>
          <span className="text-xs bg-primary-100 text-primary-700 px-2 py-0.5 rounded-full font-medium mt-1 inline-block">
            {user.role === 'super_admin' ? 'مدیر ارشد' : user.role === 'manager' ? 'مدیر' : user.role === 'team_lead' ? 'سرتیم' : 'عضو'}
          </span>
        </div>
      </div>

      {/* Profile Form */}
      <div className="card p-6">
        <h3 className="font-semibold text-gray-800 mb-5 flex items-center gap-2"><Save size={16} />اطلاعات پروفایل</h3>
        <form onSubmit={handleSave} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">نام کامل</label>
              <input className="input-field" value={form.full_name} onChange={e => setForm({...form, full_name: e.target.value})} />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">سمت</label>
              <input className="input-field" value={form.position} onChange={e => setForm({...form, position: e.target.value})} />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">موبایل</label>
              <input className="input-field" value={form.mobile} onChange={e => setForm({...form, mobile: e.target.value})} dir="ltr" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">ایمیل دریافت اعلان</label>
              <input type="email" className="input-field" value={form.notification_email} onChange={e => setForm({...form, notification_email: e.target.value})} dir="ltr" />
            </div>
          </div>

          <div>
            <label className="flex items-center gap-3 cursor-pointer">
              <div className={`w-10 h-6 rounded-full transition-colors ${form.email_notifications_enabled ? 'bg-primary-600' : 'bg-gray-300'}`}
                onClick={() => setForm({...form, email_notifications_enabled: !form.email_notifications_enabled})}>
                <div className={`w-4 h-4 bg-white rounded-full m-1 transition-transform ${form.email_notifications_enabled ? 'translate-x-4' : ''}`} />
              </div>
              <span className="text-sm font-medium text-gray-700">دریافت ایمیل اعلان</span>
            </label>
          </div>

          {form.email_notifications_enabled && (
            <div className="bg-gray-50 rounded-xl p-4">
              <p className="text-sm font-medium text-gray-700 mb-3">نوع اعلان‌های ایمیلی</p>
              <div className="grid grid-cols-2 gap-2">
                {Object.entries(NOTIF_LABELS).map(([key, label]) => (
                  <label key={key} className="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox"
                      checked={!!form.notification_preferences[key]}
                      onChange={e => setForm({...form, notification_preferences: {...form.notification_preferences, [key]: e.target.checked}})}
                      className="rounded border-gray-300 text-primary-600"
                    />
                    <span className="text-sm text-gray-700">{label}</span>
                  </label>
                ))}
              </div>
            </div>
          )}

          <button type="submit" disabled={saving} className="btn-primary">{saving ? 'در حال ذخیره...' : 'ذخیره تغییرات'}</button>
        </form>
      </div>

      {/* Electronic Signature */}
      <div className="card p-6">
        <h3 className="font-semibold text-gray-800 mb-5 flex items-center gap-2"><PenLine size={16} />امضای الکترونیک</h3>

        {signatureData ? (
          <div className="space-y-4">
            <div className="border border-gray-200 rounded-xl p-4 bg-gray-50 flex items-center justify-center" style={{ minHeight: 120 }}>
              <img src={signatureData} alt="امضا" className="max-h-28 max-w-full object-contain" />
            </div>
            <div className="flex gap-3">
              <button type="button" onClick={() => setSigMode('upload')} className="btn-secondary flex items-center gap-2 text-sm">
                <Upload size={14} />آپلود امضای جدید
              </button>
              <button type="button" onClick={() => setSigMode('draw')} className="btn-secondary flex items-center gap-2 text-sm">
                <PenLine size={14} />رسم امضا
              </button>
              <button type="button" onClick={handleDeleteSignature} disabled={loadingSig} className="flex items-center gap-2 text-sm text-red-600 hover:text-red-700 border border-red-200 hover:border-red-300 rounded-lg px-3 py-2 transition-colors">
                <Trash2 size={14} />حذف امضا
              </button>
            </div>
          </div>
        ) : (
          <div className="text-center text-gray-500 py-6 space-y-3">
            <PenLine size={40} className="mx-auto text-gray-300" />
            <p className="text-sm">هنوز امضایی ثبت نشده است</p>
            <div className="flex gap-3 justify-center">
              <button type="button" onClick={() => setSigMode('upload')} className="btn-primary flex items-center gap-2 text-sm">
                <Upload size={14} />آپلود تصویر امضا
              </button>
              <button type="button" onClick={() => setSigMode('draw')} className="btn-secondary flex items-center gap-2 text-sm">
                <PenLine size={14} />رسم امضا با ماوس
              </button>
            </div>
          </div>
        )}

        {/* Upload mode */}
        {sigMode === 'upload' && (
          <div className="mt-4 border-2 border-dashed border-primary-300 rounded-xl p-6 text-center bg-primary-50">
            <label className="cursor-pointer">
              <Upload size={28} className="mx-auto text-primary-400 mb-2" />
              <p className="text-sm text-primary-600 font-medium">فایل تصویر امضا را انتخاب کنید</p>
              <p className="text-xs text-gray-400 mt-1">PNG، JPG — حداکثر ۱ مگابایت</p>
              <input
                type="file"
                className="hidden"
                accept="image/*"
                onChange={e => e.target.files?.[0] && handleSignatureUpload(e.target.files[0])}
              />
            </label>
            <button type="button" onClick={() => setSigMode(null)} className="mt-3 text-sm text-gray-500 hover:text-gray-700">انصراف</button>
          </div>
        )}

        {/* Draw mode */}
        {sigMode === 'draw' && (
          <div className="mt-4 space-y-3">
            <p className="text-sm text-gray-600">امضای خود را با ماوس یا انگشت رسم کنید:</p>
            <div className="border-2 border-gray-300 rounded-xl overflow-hidden bg-white" style={{ lineHeight: 0 }}>
              <canvas
                ref={canvasRef}
                width={560}
                height={180}
                className="cursor-crosshair touch-none"
                style={{ display: 'block', width: '100%', height: 'auto' }}
                onMouseDown={startDraw}
                onMouseMove={draw}
                onMouseUp={endDraw}
                onMouseLeave={endDraw}
                onTouchStart={startDraw}
                onTouchMove={draw}
                onTouchEnd={endDraw}
              />
            </div>
            <div className="flex gap-3">
              <button type="button" onClick={saveDrawnSignature} disabled={loadingSig} className="btn-primary flex items-center gap-2 text-sm">
                <Check size={14} />{loadingSig ? 'در حال ذخیره...' : 'ذخیره امضا'}
              </button>
              <button type="button" onClick={clearCanvas} className="btn-secondary text-sm">پاک کردن</button>
              <button type="button" onClick={() => setSigMode(null)} className="text-sm text-gray-500 hover:text-gray-700">انصراف</button>
            </div>
          </div>
        )}
      </div>

      {/* Personal Stamp — managers only */}
      {isManagerRole && (
        <div className="card p-6">
          <h3 className="font-semibold text-gray-800 mb-5 flex items-center gap-2"><Stamp size={16} />مهر شخصی</h3>

          {stampData ? (
            <div className="space-y-4">
              <div className="border border-gray-200 rounded-xl p-4 bg-gray-50 flex items-center justify-center" style={{ minHeight: 120 }}>
                <img src={stampData} alt="مهر شخصی" className="max-h-28 max-w-full object-contain" />
              </div>
              <div className="flex gap-3">
                <label className="btn-secondary flex items-center gap-2 text-sm cursor-pointer">
                  <Upload size={14} />آپلود مهر جدید
                  <input type="file" className="hidden" accept="image/*"
                    onChange={e => e.target.files?.[0] && handleStampUpload(e.target.files[0])} />
                </label>
                <button type="button" onClick={handleDeleteStamp} disabled={loadingStamp}
                  className="flex items-center gap-2 text-sm text-red-600 hover:text-red-700 border border-red-200 hover:border-red-300 rounded-lg px-3 py-2 transition-colors">
                  <Trash2 size={14} />حذف مهر
                </button>
              </div>
            </div>
          ) : (
            <div className="text-center text-gray-500 py-6 space-y-3">
              <Stamp size={40} className="mx-auto text-gray-300" />
              <p className="text-sm">هنوز مهر شخصی ثبت نشده است</p>
              <label className="btn-primary flex items-center gap-2 text-sm cursor-pointer w-fit mx-auto">
                <Upload size={14} />آپلود تصویر مهر
                <input type="file" className="hidden" accept="image/*"
                  onChange={e => e.target.files?.[0] && handleStampUpload(e.target.files[0])} />
              </label>
            </div>
          )}
        </div>
      )}

      {/* Change Password */}
      <div className="card p-6">
        <h3 className="font-semibold text-gray-800 mb-5 flex items-center gap-2"><Lock size={16} />تغییر رمز عبور</h3>
        <form onSubmit={handlePwChange} className="space-y-4">
          {[
            { label: 'رمز عبور فعلی', key: 'current_password' },
            { label: 'رمز عبور جدید', key: 'new_password' },
            { label: 'تکرار رمز جدید', key: 'confirm' },
          ].map(field => (
            <div key={field.key}>
              <label className="block text-sm font-medium text-gray-700 mb-1">{field.label}</label>
              <input type="password" className="input-field" dir="ltr"
                value={(pwForm as any)[field.key]}
                onChange={e => setPwForm({...pwForm, [field.key]: e.target.value})}
              />
            </div>
          ))}
          <button type="submit" disabled={changingPw} className="btn-primary">{changingPw ? 'در حال تغییر...' : 'تغییر رمز عبور'}</button>
        </form>
      </div>
    </div>
  )
}
