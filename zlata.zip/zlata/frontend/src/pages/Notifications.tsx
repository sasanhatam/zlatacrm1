import { useEffect, useState } from 'react'
import { notificationsApi } from '@/api/notifications'
import { useNotificationStore } from '@/store/notificationStore'
import { Announcement } from '@/types/chat'
import { useJalali } from '@/hooks/useJalali'
import { Bell, Megaphone, Check, CheckCheck } from 'lucide-react'
import clsx from 'clsx'

const PRIORITY_STYLES = {
  normal:    'border-gray-200 bg-white',
  important: 'border-yellow-200 bg-yellow-50',
  urgent:    'border-red-200 bg-red-50',
}

export default function Notifications() {
  const { notifications, fetchNotifications, markRead, markAllRead, unreadCount } = useNotificationStore()
  const [announcements, setAnnouncements] = useState<Announcement[]>([])
  const [tab, setTab] = useState<'notifications' | 'announcements'>('notifications')
  const { fromNow } = useJalali()

  useEffect(() => {
    fetchNotifications()
    notificationsApi.listAnnouncements().then(res => setAnnouncements(res.data))
  }, [])

  return (
    <div className="max-w-2xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-gray-900">اعلانات</h1>
        {unreadCount > 0 && (
          <button onClick={markAllRead} className="btn-secondary flex items-center gap-2 text-sm">
            <CheckCheck size={15} />
            همه را خوانده‌ام
          </button>
        )}
      </div>

      {/* Tabs */}
      <div className="flex gap-1 bg-gray-100 rounded-lg p-1 mb-6">
        <button onClick={() => setTab('notifications')}
          className={clsx('flex-1 flex items-center justify-center gap-2 py-2 rounded-lg text-sm font-medium transition-colors',
            tab === 'notifications' ? 'bg-white shadow-sm text-gray-800' : 'text-gray-500')}>
          <Bell size={15} />
          نوتیفیکیشن‌ها
          {unreadCount > 0 && <span className="bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">{unreadCount}</span>}
        </button>
        <button onClick={() => setTab('announcements')}
          className={clsx('flex-1 flex items-center justify-center gap-2 py-2 rounded-lg text-sm font-medium transition-colors',
            tab === 'announcements' ? 'bg-white shadow-sm text-gray-800' : 'text-gray-500')}>
          <Megaphone size={15} />
          اطلاعیه‌ها
        </button>
      </div>

      {tab === 'notifications' && (
        <div className="space-y-2">
          {notifications.map(n => (
            <div
              key={n.id}
              onClick={() => !n.is_read && markRead(n.id)}
              className={clsx('border rounded-xl p-4 cursor-pointer transition-all',
                n.is_read ? 'bg-white border-gray-200 opacity-70' : 'bg-blue-50 border-blue-200 shadow-sm'
              )}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1">
                  <p className="font-medium text-sm text-gray-800">{n.title}</p>
                  <p className="text-sm text-gray-600 mt-0.5">{n.body}</p>
                  <p className="text-xs text-gray-400 mt-1">{fromNow(n.created_at)}</p>
                </div>
                {!n.is_read && (
                  <div className="w-2.5 h-2.5 bg-blue-500 rounded-full flex-shrink-0 mt-1.5" />
                )}
              </div>
            </div>
          ))}
          {notifications.length === 0 && (
            <div className="text-center py-12 text-gray-400">
              <Bell size={40} className="mx-auto mb-3 text-gray-200" />
              <p>نوتیفیکیشنی ندارید</p>
            </div>
          )}
        </div>
      )}

      {tab === 'announcements' && (
        <div className="space-y-4">
          {announcements.map(ann => (
            <div key={ann.id} className={clsx('border-2 rounded-xl p-5 transition-all', PRIORITY_STYLES[ann.priority])}>
              <div className="flex items-start gap-2 mb-2">
                <Megaphone size={16} className="text-primary-600 mt-0.5 flex-shrink-0" />
                <h3 className="font-semibold text-gray-900">{ann.title}</h3>
                {ann.priority !== 'normal' && (
                  <span className={clsx('text-xs px-2 py-0.5 rounded-full font-medium',
                    ann.priority === 'urgent' ? 'bg-red-100 text-red-700' : 'bg-yellow-100 text-yellow-700'
                  )}>
                    {ann.priority === 'urgent' ? 'فوری' : 'مهم'}
                  </span>
                )}
              </div>
              <p className="text-sm text-gray-700 leading-relaxed">{ann.body}</p>
              <p className="text-xs text-gray-400 mt-3">{fromNow(ann.created_at)}</p>
            </div>
          ))}
          {announcements.length === 0 && (
            <div className="text-center py-12 text-gray-400">
              <Megaphone size={40} className="mx-auto mb-3 text-gray-200" />
              <p>اطلاعیه‌ای وجود ندارد</p>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
