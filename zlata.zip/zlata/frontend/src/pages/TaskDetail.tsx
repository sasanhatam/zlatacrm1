import { useState, useEffect, useRef } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { tasksApi } from '@/api/tasks'
import { usersApi } from '@/api/users'
import api from '@/api/client'
import { Task, SubTask, TaskComment, AuditLog, STATUS_LABELS, PRIORITY_LABELS } from '@/types/task'
import { User, Team } from '@/types/common'
import { PriorityBadge, StatusBadge } from '@/components/common/Badge'
import { Avatar } from '@/components/common/Avatar'
import { useJalali } from '@/hooks/useJalali'
import { useAuthStore } from '@/store/authStore'
import {
  ArrowRight, Paperclip, MessageSquare, Clock, CheckSquare, History,
  Send, Plus, Check, Share2, X, Upload, File, Image, ChevronLeft,
  UserCheck, Users, User as UserIcon,
} from 'lucide-react'
import toast from 'react-hot-toast'
import clsx from 'clsx'

type Tab = 'details' | 'comments' | 'subtasks' | 'history' | 'referral'

interface ReferralChainEntry {
  referral_id?: string
  from: string
  from_name: string
  to: string | null
  to_name: string | null
  to_team: string | null
  to_team_name: string | null
  note: string | null
  file_ids: string[]
  at: string
}

// ─── Referral Modal ───────────────────────────────────────────────────────────
function ReferModal({ taskId, taskTitle, allUsers, teams, onClose, onDone }: {
  taskId: string
  taskTitle: string
  allUsers: User[]
  teams: Team[]
  onClose: () => void
  onDone: () => void
}) {
  type TargetType = 'user' | 'manager' | 'team'
  const [targetType, setTargetType] = useState<TargetType>('user')
  const [toUserId, setToUserId] = useState('')
  const [toTeamId, setToTeamId] = useState('')
  const [note, setNote] = useState('')
  const [attachments, setAttachments] = useState<{ id: string; name: string; isImage: boolean }[]>([])
  const [uploading, setUploading] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const uploadFile = async (file: File) => {
    setUploading(true)
    try {
      const fd = new FormData()
      fd.append('file', file)
      fd.append('folder', 'referrals')
      const res: any = await api.post('/files/upload', fd, { headers: { 'Content-Type': 'multipart/form-data' } })
      setAttachments(prev => [...prev, {
        id: res.data.file_id,
        name: res.data.name,
        isImage: res.data.is_image,
      }])
    } catch {
      toast.error('خطا در آپلود فایل')
    } finally {
      setUploading(false)
    }
  }

  const handleFiles = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || [])
    files.forEach(f => uploadFile(f))
    e.target.value = ''
  }

  const submit = async () => {
    if (targetType === 'user' && !toUserId) return toast.error('کاربر مقصد را انتخاب کنید')
    if (targetType === 'team' && !toTeamId) return toast.error('تیم مقصد را انتخاب کنید')
    setSubmitting(true)
    try {
      await tasksApi.refer(taskId, {
        to_user_id: targetType === 'user' ? toUserId : undefined,
        to_team_id: targetType === 'team' ? toTeamId : undefined,
        to_manager: targetType === 'manager',
        note: note.trim() || undefined,
        file_ids: attachments.map(a => a.id),
      })
      toast.success('تسک با موفقیت ارجاع داده شد')
      onDone()
      onClose()
    } catch (e: any) {
      toast.error(e.response?.data?.detail || 'خطا در ارجاع تسک')
    } finally {
      setSubmitting(false)
    }
  }

  const targetOptions: { value: TargetType; label: string; icon: React.ReactNode; desc: string }[] = [
    { value: 'user', label: 'کاربر مشخص', icon: <UserIcon size={15} />, desc: 'ارجاع به یک نفر خاص از سازمان' },
    { value: 'manager', label: 'مدیر من', icon: <UserCheck size={15} />, desc: 'ارجاع به مدیر تیم خودتان' },
    { value: 'team', label: 'تیم دیگر', icon: <Users size={15} />, desc: 'ارجاع به یک تیم دیگر' },
  ]

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" dir="rtl">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b">
          <div>
            <h2 className="font-bold text-gray-900">ارجاع تسک</h2>
            <p className="text-xs text-gray-400 mt-0.5 truncate max-w-xs">{taskTitle}</p>
          </div>
          <button onClick={onClose} className="p-1.5 hover:bg-gray-100 rounded-lg">
            <X size={18} className="text-gray-400" />
          </button>
        </div>

        <div className="p-6 space-y-5">
          {/* Target type */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">ارجاع به</label>
            <div className="grid grid-cols-3 gap-2">
              {targetOptions.map(opt => (
                <button key={opt.value} type="button" onClick={() => setTargetType(opt.value)}
                  className={clsx(
                    'flex flex-col items-center gap-1.5 p-3 rounded-xl border-2 transition-all text-center',
                    targetType === opt.value
                      ? 'border-primary-500 bg-primary-50 text-primary-700'
                      : 'border-gray-200 text-gray-500 hover:border-gray-300'
                  )}>
                  {opt.icon}
                  <span className="text-xs font-medium">{opt.label}</span>
                  <span className="text-xs text-gray-400 leading-tight">{opt.desc}</span>
                </button>
              ))}
            </div>
          </div>

          {/* User / Team selector */}
          {targetType === 'user' && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">انتخاب کاربر</label>
              <select value={toUserId} onChange={e => setToUserId(e.target.value)}
                className="w-full border border-gray-300 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary-300">
                <option value="">انتخاب کنید...</option>
                {allUsers.map(u => (
                  <option key={u.id} value={u.id}>{u.full_name}{u.position ? ` — ${u.position}` : ''}</option>
                ))}
              </select>
            </div>
          )}

          {targetType === 'team' && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">انتخاب تیم</label>
              <select value={toTeamId} onChange={e => setToTeamId(e.target.value)}
                className="w-full border border-gray-300 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary-300">
                <option value="">انتخاب کنید...</option>
                {teams.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
              </select>
            </div>
          )}

          {targetType === 'manager' && (
            <div className="bg-blue-50 border border-blue-200 rounded-xl p-3 text-sm text-blue-700">
              تسک به مدیر تیم شما ارجاع داده خواهد شد
            </div>
          )}

          {/* Note */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">توضیحات / نوت برای نفر بعدی</label>
            <textarea
              value={note}
              onChange={e => setNote(e.target.value)}
              placeholder="توضیح دهید چه کاری انجام دادید و از نفر بعدی چه انتظاری دارید..."
              rows={4}
              className="w-full border border-gray-300 rounded-xl px-3 py-2 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-primary-300 leading-relaxed"
            />
          </div>

          {/* Attachments */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-sm font-medium text-gray-700">پیوست (فایل / عکس)</label>
              <button type="button" onClick={() => fileInputRef.current?.click()}
                disabled={uploading}
                className="flex items-center gap-1.5 text-xs text-primary-600 hover:text-primary-800 px-3 py-1.5 border border-primary-200 rounded-lg hover:bg-primary-50 transition-colors disabled:opacity-50">
                {uploading ? <div className="w-3 h-3 border-2 border-primary-500 border-t-transparent rounded-full animate-spin" /> : <Upload size={12} />}
                {uploading ? 'در حال آپلود...' : 'افزودن فایل'}
              </button>
              <input ref={fileInputRef} type="file" multiple className="hidden" onChange={handleFiles} />
            </div>

            {attachments.length > 0 && (
              <div className="space-y-2">
                {attachments.map((a, i) => (
                  <div key={a.id} className="flex items-center gap-3 bg-gray-50 rounded-xl px-3 py-2">
                    {a.isImage
                      ? <Image size={16} className="text-blue-500 flex-shrink-0" />
                      : <File size={16} className="text-gray-400 flex-shrink-0" />
                    }
                    <span className="text-sm text-gray-700 flex-1 truncate">{a.name}</span>
                    <button type="button" onClick={() => setAttachments(prev => prev.filter((_, j) => j !== i))}
                      className="text-gray-400 hover:text-red-500 p-0.5">
                      <X size={14} />
                    </button>
                  </div>
                ))}
              </div>
            )}

            {attachments.length === 0 && (
              <button type="button" onClick={() => fileInputRef.current?.click()}
                className="w-full border-2 border-dashed border-gray-200 rounded-xl p-4 text-center hover:border-primary-300 transition-colors">
                <Upload size={18} className="mx-auto mb-1 text-gray-300" />
                <p className="text-xs text-gray-400">کلیک برای افزودن فایل یا عکس</p>
              </button>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center gap-3 px-6 py-4 border-t bg-gray-50 rounded-b-2xl">
          <button onClick={onClose} className="flex-1 py-2.5 text-sm text-gray-500 border border-gray-200 rounded-xl hover:bg-gray-100 transition-colors">
            انصراف
          </button>
          <button onClick={submit} disabled={submitting || uploading}
            className="flex-1 flex items-center justify-center gap-2 bg-primary-600 text-white py-2.5 rounded-xl text-sm hover:bg-primary-700 disabled:opacity-50 transition-colors">
            <Share2 size={15} />
            {submitting ? 'در حال ارجاع...' : 'ارجاع تسک'}
          </button>
        </div>
      </div>
    </div>
  )
}

// ─── Referral Chain ───────────────────────────────────────────────────────────
function ReferralChain({ chain }: { chain: ReferralChainEntry[] }) {
  const { fromNow } = useJalali()
  const [fileUrls, setFileUrls] = useState<Record<string, string>>({})

  useEffect(() => {
    const allIds = chain.flatMap(e => e.file_ids || [])
    allIds.forEach(fid => {
      if (!fileUrls[fid]) {
        api.get(`/files/${fid}/url`).then((r: any) => {
          setFileUrls(prev => ({ ...prev, [fid]: r.data.url }))
        }).catch(() => {})
      }
    })
  }, [chain])

  if (chain.length === 0) {
    return (
      <div className="text-center py-10 text-gray-400">
        <Share2 size={36} className="mx-auto mb-3 text-gray-200" />
        <p className="text-sm">هنوز هیچ ارجاعی ثبت نشده</p>
      </div>
    )
  }

  return (
    <div className="relative">
      {/* Vertical line */}
      <div className="absolute right-5 top-6 bottom-6 w-px bg-gray-200" />

      <div className="space-y-6">
        {chain.map((entry, i) => (
          <div key={i} className="flex gap-4 relative">
            <div className="w-10 h-10 rounded-full bg-primary-100 flex items-center justify-center flex-shrink-0 relative z-10">
              {entry.to_team_name
                ? <Users size={16} className="text-primary-600" />
                : <UserIcon size={16} className="text-primary-600" />
              }
            </div>

            <div className="flex-1 bg-white border border-gray-200 rounded-2xl p-4 shadow-sm">
              {/* From → To */}
              <div className="flex items-center gap-2 mb-2 flex-wrap">
                <span className="font-semibold text-gray-900 text-sm">{entry.from_name}</span>
                <ChevronLeft size={14} className="text-gray-400 flex-shrink-0" />
                <span className="font-semibold text-primary-700 text-sm">
                  {entry.to_team_name
                    ? <span className="flex items-center gap-1"><Users size={12} />{entry.to_team_name}</span>
                    : entry.to_name || '—'
                  }
                </span>
                <span className="text-xs text-gray-400 mr-auto">{fromNow(entry.at)}</span>
              </div>

              {/* Note */}
              {entry.note && (
                <div className="bg-amber-50 border border-amber-100 rounded-xl px-3 py-2 mb-3">
                  <p className="text-sm text-amber-900 leading-relaxed whitespace-pre-wrap">{entry.note}</p>
                </div>
              )}

              {/* Attachments */}
              {(entry.file_ids || []).length > 0 && (
                <div className="space-y-1.5">
                  {entry.file_ids.map(fid => (
                    <a key={fid} href={fileUrls[fid] || '#'} target="_blank" rel="noreferrer"
                      className="flex items-center gap-2 text-xs text-primary-600 hover:text-primary-800 bg-primary-50 px-3 py-1.5 rounded-lg w-fit">
                      <Paperclip size={12} />
                      {fileUrls[fid] ? 'مشاهده پیوست' : 'در حال بارگذاری...'}
                    </a>
                  ))}
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

// ─── Main TaskDetail ──────────────────────────────────────────────────────────
export default function TaskDetail() {
  const { id } = useParams<{ id: string }>()
  const navigate = useNavigate()
  const { format, fromNow } = useJalali()
  const { user: currentUser } = useAuthStore()

  const [task, setTask] = useState<Task | null>(null)
  const [comments, setComments] = useState<TaskComment[]>([])
  const [subtasks, setSubtasks] = useState<SubTask[]>([])
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([])
  const [referralChain, setReferralChain] = useState<ReferralChainEntry[]>([])
  const [users, setUsers] = useState<Record<string, User>>({})
  const [allUsers, setAllUsers] = useState<User[]>([])
  const [teams, setTeams] = useState<Team[]>([])
  const [tab, setTab] = useState<Tab>('details')
  const [newComment, setNewComment] = useState('')
  const [newSubtask, setNewSubtask] = useState('')
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [showReferModal, setShowReferModal] = useState(false)

  const loadData = async () => {
    if (!id) return
    const [taskRes, commentRes, subtaskRes, auditRes, userRes, teamRes, referralRes] = await Promise.all([
      tasksApi.get(id),
      tasksApi.getComments(id),
      tasksApi.getSubtasks(id),
      tasksApi.getAuditLog(id),
      usersApi.list(),
      usersApi.listTeams(),
      tasksApi.getReferrals(id),
    ])
    setTask(taskRes.data)
    setComments(commentRes.data)
    setSubtasks(subtaskRes.data)
    setAuditLogs(auditRes.data)
    setAllUsers(userRes.data)
    setTeams(teamRes.data)
    setReferralChain(referralRes.data)
    const uMap: Record<string, User> = {}
    userRes.data.forEach((u: User) => { uMap[u.id] = u })
    setUsers(uMap)
  }

  useEffect(() => {
    loadData().finally(() => setLoading(false))
  }, [id])

  const handleStatusChange = async (newStatus: string) => {
    if (!task) return
    setSaving(true)
    try {
      const { data } = await tasksApi.update(task.id, { status: newStatus as any })
      setTask(data)
      toast.success('وضعیت تسک به‌روز شد')
    } catch { toast.error('خطا در به‌روزرسانی') }
    finally { setSaving(false) }
  }

  const handleChecklistToggle = async (idx: number) => {
    if (!task) return
    const updated = task.checklist.map((item, i) => i === idx ? { ...item, is_done: !item.is_done } : item)
    await tasksApi.updateChecklist(task.id, updated)
    setTask({ ...task, checklist: updated })
  }

  const submitComment = async () => {
    if (!newComment.trim() || !id) return
    try {
      const { data } = await tasksApi.addComment(id, newComment.trim())
      setComments(prev => [...prev, data])
      setNewComment('')
    } catch { toast.error('خطا در ارسال کامنت') }
  }

  const addSubtask = async () => {
    if (!newSubtask.trim() || !id) return
    try {
      const { data } = await tasksApi.createSubtask(id, { title: newSubtask.trim() })
      setSubtasks(prev => [...prev, data])
      setNewSubtask('')
    } catch { toast.error('خطا در ایجاد زیرتسک') }
  }

  const toggleSubtask = async (sub: SubTask) => {
    if (!id) return
    const { data } = await tasksApi.updateSubtask(id, sub.id, { is_done: !sub.is_done })
    setSubtasks(prev => prev.map(s => s.id === sub.id ? data : s))
  }

  if (loading) return (
    <div className="flex items-center justify-center h-64">
      <div className="w-8 h-8 border-4 border-primary-500 border-t-transparent rounded-full animate-spin" />
    </div>
  )
  if (!task) return <div className="text-center py-12 text-gray-500">تسک یافت نشد</div>

  const tabs: { key: Tab; label: string; icon: React.ReactNode; badge?: number }[] = [
    { key: 'details', label: 'جزئیات', icon: <CheckSquare size={15} /> },
    { key: 'referral', label: 'ارجاع', icon: <Share2 size={15} />, badge: referralChain.length || undefined },
    { key: 'comments', label: 'کامنت‌ها', icon: <MessageSquare size={15} />, badge: comments.length || undefined },
    { key: 'subtasks', label: 'زیرتسک‌ها', icon: <Plus size={15} />, badge: subtasks.length || undefined },
    { key: 'history', label: 'تاریخچه', icon: <History size={15} /> },
  ]

  return (
    <div className="max-w-4xl mx-auto" dir="rtl">
      {/* Back */}
      <button onClick={() => navigate('/tasks')} className="flex items-center gap-2 text-sm text-gray-500 hover:text-gray-800 mb-4 transition-colors">
        <ArrowRight size={16} />
        بازگشت به تسک‌ها
      </button>

      {/* Header */}
      <div className="card p-6 mb-4">
        <div className="flex items-start justify-between gap-4 mb-4">
          <h1 className="text-xl font-bold text-gray-900 flex-1">{task.title}</h1>
          <div className="flex items-center gap-2 flex-shrink-0">
            <PriorityBadge priority={task.priority} />
            <select
              value={task.status}
              onChange={e => handleStatusChange(e.target.value)}
              disabled={saving}
              className="input-field w-auto text-sm py-1.5"
            >
              {Object.entries(STATUS_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
            </select>
            <button
              onClick={() => setShowReferModal(true)}
              className="flex items-center gap-1.5 bg-orange-50 border border-orange-200 text-orange-700 px-3 py-1.5 rounded-lg text-sm hover:bg-orange-100 transition-colors"
            >
              <Share2 size={14} />
              ارجاع
            </button>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-sm">
          <div>
            <p className="text-gray-500 mb-1">مسئول فعلی</p>
            {task.assignee_id && users[task.assignee_id] ? (
              <div className="flex items-center gap-2">
                <Avatar name={users[task.assignee_id].full_name} size="xs" />
                <span>{users[task.assignee_id].full_name}</span>
              </div>
            ) : <span className="text-gray-400">نامشخص</span>}
          </div>
          <div>
            <p className="text-gray-500 mb-1">ددلاین</p>
            <p className={clsx('font-medium', task.due_date && new Date(task.due_date) < new Date() && task.status !== 'done' ? 'text-red-600' : 'text-gray-800')}>
              {format(task.due_date)}
            </p>
          </div>
          <div>
            <p className="text-gray-500 mb-1">ایجاد شده</p>
            <p className="text-gray-800">{format(task.created_at)}</p>
          </div>
          {task.delay_hours !== undefined && task.delay_hours !== null && (
            <div>
              <p className="text-gray-500 mb-1">تاخیر</p>
              <p className={task.delay_hours > 0 ? 'text-red-600 font-medium' : 'text-green-600 font-medium'}>
                {task.delay_hours > 0 ? `${task.delay_hours.toFixed(1)} ساعت دیرکرد` : `${Math.abs(task.delay_hours).toFixed(1)} ساعت زودتر`}
              </p>
            </div>
          )}
        </div>

        {task.tags.length > 0 && (
          <div className="flex flex-wrap gap-2 mt-4">
            {task.tags.map(tag => <span key={tag} className="text-xs bg-primary-50 text-primary-700 px-2.5 py-1 rounded-full">{tag}</span>)}
          </div>
        )}

        {/* Referral chain summary in header */}
        {referralChain.length > 0 && (
          <div className="mt-4 pt-4 border-t border-gray-100">
            <p className="text-xs text-gray-400 mb-2">مسیر ارجاع:</p>
            <div className="flex items-center gap-1 flex-wrap">
              {referralChain.map((e, i) => (
                <span key={i} className="flex items-center gap-1">
                  <span className="text-xs bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full">{e.from_name}</span>
                  <ChevronLeft size={10} className="text-gray-400" />
                  {i === referralChain.length - 1 && (
                    <span className="text-xs bg-primary-100 text-primary-700 px-2 py-0.5 rounded-full font-medium">
                      {e.to_team_name || e.to_name}
                    </span>
                  )}
                </span>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Tabs */}
      <div className="card overflow-hidden">
        <div className="flex border-b border-gray-200 overflow-x-auto">
          {tabs.map(t => (
            <button key={t.key} onClick={() => setTab(t.key)}
              className={clsx(
                'flex items-center gap-1.5 px-4 py-3 text-sm font-medium border-b-2 transition-colors whitespace-nowrap',
                tab === t.key ? 'border-primary-600 text-primary-600 bg-primary-50/50' : 'border-transparent text-gray-500 hover:text-gray-800 hover:bg-gray-50'
              )}>
              {t.icon}
              {t.label}
              {t.badge !== undefined && (
                <span className="bg-gray-200 text-gray-600 text-xs px-1.5 py-0.5 rounded-full leading-none">
                  {t.badge}
                </span>
              )}
            </button>
          ))}
        </div>

        <div className="p-6">

          {/* Referral Tab */}
          {tab === 'referral' && (
            <div>
              <div className="flex items-center justify-between mb-5">
                <h3 className="font-medium text-gray-700">زنجیره ارجاعات</h3>
                <button onClick={() => setShowReferModal(true)}
                  className="flex items-center gap-2 bg-primary-600 text-white px-4 py-2 rounded-xl text-sm hover:bg-primary-700">
                  <Share2 size={14} />
                  ارجاع جدید
                </button>
              </div>
              <ReferralChain chain={referralChain} />
            </div>
          )}

          {/* Details Tab */}
          {tab === 'details' && (
            <div className="space-y-6">
              {task.description && (
                <div>
                  <h3 className="font-medium text-gray-700 mb-2">توضیحات</h3>
                  <p className="text-gray-600 leading-relaxed text-sm whitespace-pre-wrap">{task.description}</p>
                </div>
              )}
              {task.checklist.length > 0 && (
                <div>
                  <h3 className="font-medium text-gray-700 mb-3">
                    چک‌لیست ({task.checklist.filter(c => c.is_done).length}/{task.checklist.length})
                  </h3>
                  <div className="space-y-2">
                    {task.checklist.map((item, idx) => (
                      <div key={idx} onClick={() => handleChecklistToggle(idx)}
                        className="flex items-center gap-3 p-2 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors">
                        <div className={clsx(
                          'w-5 h-5 rounded border-2 flex items-center justify-center flex-shrink-0 transition-colors',
                          item.is_done ? 'bg-green-500 border-green-500' : 'border-gray-300'
                        )}>
                          {item.is_done && <Check size={12} className="text-white" />}
                        </div>
                        <span className={clsx('text-sm', item.is_done && 'line-through text-gray-400')}>{item.text}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              {!task.description && task.checklist.length === 0 && (
                <p className="text-center text-gray-400 text-sm py-4">جزئیات اضافه‌ای ثبت نشده</p>
              )}
            </div>
          )}

          {/* Comments Tab */}
          {tab === 'comments' && (
            <div className="space-y-4">
              {comments.map(comment => (
                <div key={comment.id} className="flex gap-3">
                  <Avatar name={users[comment.author_id]?.full_name || '?'} size="sm" />
                  <div className="flex-1 bg-gray-50 rounded-xl p-3">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-sm font-medium text-gray-800">{users[comment.author_id]?.full_name || 'کاربر'}</span>
                      <span className="text-xs text-gray-400">{fromNow(comment.created_at)}</span>
                    </div>
                    <p className="text-sm text-gray-700 leading-relaxed whitespace-pre-wrap">{comment.content}</p>
                  </div>
                </div>
              ))}
              {comments.length === 0 && <p className="text-center text-gray-400 text-sm py-4">هنوز کامنتی ثبت نشده</p>}

              <div className="flex gap-3 mt-4 pt-4 border-t border-gray-100">
                <Avatar name={currentUser?.full_name || ''} size="sm" />
                <div className="flex-1 flex gap-2">
                  <textarea
                    value={newComment}
                    onChange={e => setNewComment(e.target.value)}
                    onKeyDown={e => { if (e.key === 'Enter' && e.ctrlKey) submitComment() }}
                    placeholder="کامنت بنویسید... (Ctrl+Enter برای ارسال)"
                    className="input-field resize-none flex-1"
                    rows={2}
                  />
                  <button onClick={submitComment} disabled={!newComment.trim()} className="btn-primary px-3 self-end">
                    <Send size={16} />
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Subtasks Tab */}
          {tab === 'subtasks' && (
            <div className="space-y-3">
              {subtasks.map(sub => (
                <div key={sub.id} onClick={() => toggleSubtask(sub)}
                  className="flex items-center gap-3 p-3 rounded-lg border border-gray-200 hover:bg-gray-50 cursor-pointer transition-colors">
                  <div className={clsx('w-5 h-5 rounded border-2 flex items-center justify-center flex-shrink-0',
                    sub.is_done ? 'bg-green-500 border-green-500' : 'border-gray-300')}>
                    {sub.is_done && <Check size={12} className="text-white" />}
                  </div>
                  <span className={clsx('text-sm flex-1', sub.is_done && 'line-through text-gray-400')}>{sub.title}</span>
                  <StatusBadge status={sub.status} />
                </div>
              ))}
              {subtasks.length === 0 && <p className="text-center text-gray-400 text-sm py-4">زیرتسکی وجود ندارد</p>}
              <div className="flex gap-2 mt-4 pt-4 border-t border-gray-100">
                <input
                  value={newSubtask}
                  onChange={e => setNewSubtask(e.target.value)}
                  onKeyDown={e => { if (e.key === 'Enter') addSubtask() }}
                  placeholder="عنوان زیرتسک جدید..."
                  className="input-field flex-1"
                />
                <button onClick={addSubtask} className="btn-primary"><Plus size={16} /></button>
              </div>
            </div>
          )}

          {/* History Tab */}
          {tab === 'history' && (
            <div className="space-y-3">
              {auditLogs.map(log => (
                <div key={log.id} className="flex gap-3 text-sm">
                  <div className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <Clock size={14} className="text-gray-500" />
                  </div>
                  <div>
                    <span className="font-medium text-gray-800">{users[log.user_id]?.full_name || 'کاربر'}</span>
                    <span className="text-gray-500 mx-1">—</span>
                    <span className="text-gray-600">{log.description || `${log.field} تغییر کرد`}</span>
                    {log.old_value && log.new_value && (
                      <span className="text-gray-400 mr-1 text-xs">از «{log.old_value}» به «{log.new_value}»</span>
                    )}
                    <p className="text-xs text-gray-400 mt-0.5">{fromNow(log.created_at)}</p>
                  </div>
                </div>
              ))}
              {auditLogs.length === 0 && <p className="text-center text-gray-400 text-sm py-4">تاریخچه‌ای ثبت نشده</p>}
            </div>
          )}

        </div>
      </div>

      {/* Referral Modal */}
      {showReferModal && task && (
        <ReferModal
          taskId={task.id}
          taskTitle={task.title}
          allUsers={allUsers.filter(u => u.id !== currentUser?.id)}
          teams={teams}
          onClose={() => setShowReferModal(false)}
          onDone={() => {
            if (id) {
              Promise.all([tasksApi.get(id), tasksApi.getReferrals(id)]).then(([t, r]) => {
                setTask(t.data)
                setReferralChain(r.data)
              })
            }
          }}
        />
      )}
    </div>
  )
}
