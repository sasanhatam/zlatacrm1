import { useState, useEffect, useRef, useCallback } from 'react'
import { chatApi } from '@/api/chat'
import { usersApi } from '@/api/users'
import { ChatRoom, Message } from '@/types/chat'
import { User } from '@/types/common'
import { useAuthStore } from '@/store/authStore'
import { useWebSocket } from '@/hooks/useWebSocket'
import { useJalali } from '@/hooks/useJalali'
import {
  Send, Plus, Paperclip, Users, Search, X,
  MessageSquare, Check, CheckCheck, Image as ImageIcon,
  ChevronLeft, ArrowRight,
} from 'lucide-react'
import toast from 'react-hot-toast'
import clsx from 'clsx'

// ─── Avatar ──────────────────────────────────────────────────────────────────
function Avatar({ name, size = 'md', className = '' }: { name: string; size?: 'xs' | 'sm' | 'md'; className?: string }) {
  const colors = ['bg-blue-500', 'bg-green-500', 'bg-purple-500', 'bg-orange-500', 'bg-pink-500', 'bg-teal-500']
  const color = colors[name.charCodeAt(0) % colors.length]
  const sizes = { xs: 'w-7 h-7 text-xs', sm: 'w-9 h-9 text-sm', md: 'w-10 h-10 text-sm' }
  return (
    <div className={clsx(sizes[size], color, 'rounded-full flex items-center justify-center text-white font-bold flex-shrink-0', className)}>
      {name.charAt(0)}
    </div>
  )
}

// ─── New Chat Modal ──────────────────────────────────────────────────────────
function NewChatModal({
  users, currentUserId, onClose, onSelectUser, onCreateGroup
}: {
  users: User[]
  currentUserId: string
  onClose: () => void
  onSelectUser: (user: User) => void
  onCreateGroup: (name: string, memberIds: string[]) => void
}) {
  const [search, setSearch] = useState('')
  const [mode, setMode] = useState<'direct' | 'group'>('direct')
  const [selected, setSelected] = useState<string[]>([])
  const [groupName, setGroupName] = useState('')

  const others = users.filter(u => u.id !== currentUserId)
  const filtered = others.filter(u =>
    u.full_name.toLowerCase().includes(search.toLowerCase()) ||
    u.position?.toLowerCase().includes(search.toLowerCase() || '') ||
    u.email.toLowerCase().includes(search.toLowerCase())
  )

  const toggleSelect = (id: string) => {
    setSelected(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id])
  }

  const handleDirectChat = (user: User) => {
    onSelectUser(user)
    onClose()
  }

  const handleCreateGroup = () => {
    if (!groupName.trim()) return toast.error('نام گروه را وارد کنید')
    if (selected.length < 1) return toast.error('حداقل یک نفر انتخاب کنید')
    onCreateGroup(groupName, selected)
    onClose()
  }

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" dir="rtl">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md flex flex-col max-h-[80vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
          <h2 className="font-bold text-gray-900 text-lg">
            {mode === 'direct' ? 'چت جدید' : 'گروه جدید'}
          </h2>
          <button onClick={onClose} className="p-1.5 hover:bg-gray-100 rounded-lg">
            <X size={18} className="text-gray-400" />
          </button>
        </div>

        {/* Mode toggle */}
        <div className="flex gap-2 px-5 py-3 border-b border-gray-100">
          <button
            onClick={() => setMode('direct')}
            className={clsx('flex-1 py-2 rounded-lg text-sm font-medium transition-colors',
              mode === 'direct' ? 'bg-primary-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            )}
          >
            <MessageSquare size={14} className="inline ml-1" />
            چت مستقیم
          </button>
          <button
            onClick={() => setMode('group')}
            className={clsx('flex-1 py-2 rounded-lg text-sm font-medium transition-colors',
              mode === 'group' ? 'bg-primary-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            )}
          >
            <Users size={14} className="inline ml-1" />
            گروه
          </button>
        </div>

        {/* Group name input */}
        {mode === 'group' && (
          <div className="px-5 py-3 border-b border-gray-100">
            <input
              type="text"
              value={groupName}
              onChange={e => setGroupName(e.target.value)}
              placeholder="نام گروه..."
              className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary-300"
            />
            {selected.length > 0 && (
              <p className="text-xs text-gray-500 mt-1">{selected.length} نفر انتخاب شده</p>
            )}
          </div>
        )}

        {/* Search */}
        <div className="px-5 py-3 border-b border-gray-100">
          <div className="relative">
            <Search size={15} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="جستجو در کاربران..."
              autoFocus
              className="w-full border border-gray-200 rounded-lg pr-9 pl-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary-300"
            />
          </div>
        </div>

        {/* Users list */}
        <div className="overflow-y-auto" style={{ maxHeight: '16rem' }}>
          {filtered.length === 0 ? (
            <p className="text-center text-gray-400 text-sm py-10">کاربری یافت نشد</p>
          ) : (
            filtered.map(user => {
              const isSelected = selected.includes(user.id)
              return (
                <button
                  key={user.id}
                  onClick={() => mode === 'direct' ? handleDirectChat(user) : toggleSelect(user.id)}
                  className={clsx(
                    'w-full flex items-center gap-3 px-5 py-3 hover:bg-gray-50 transition-colors border-b border-gray-50',
                    mode === 'group' && isSelected && 'bg-primary-50'
                  )}
                >
                  <Avatar name={user.full_name} size="sm" />
                  <div className="flex-1 text-right">
                    <p className="font-medium text-sm text-gray-800">{user.full_name}</p>
                    {user.position && <p className="text-xs text-gray-500">{user.position}</p>}
                  </div>
                  {mode === 'group' && (
                    <div className={clsx(
                      'w-5 h-5 rounded-full border-2 flex items-center justify-center flex-shrink-0 transition-colors',
                      isSelected ? 'bg-primary-600 border-primary-600' : 'border-gray-300'
                    )}>
                      {isSelected && <Check size={11} className="text-white" />}
                    </div>
                  )}
                </button>
              )
            })
          )}
        </div>

        {/* Group create button */}
        {mode === 'group' && (
          <div className="p-4 border-t border-gray-100">
            <button
              onClick={handleCreateGroup}
              disabled={selected.length === 0 || !groupName.trim()}
              className="w-full bg-primary-600 text-white py-2.5 rounded-xl text-sm font-medium hover:bg-primary-700 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
            >
              ایجاد گروه ({selected.length} نفر)
            </button>
          </div>
        )}
      </div>
    </div>
  )
}

// ─── Room Item ───────────────────────────────────────────────────────────────
function RoomItem({ room, isActive, currentUserId, users, onClick }: {
  room: ChatRoom
  isActive: boolean
  currentUserId: string
  users: Record<string, User>
  onClick: () => void
}) {
  const name = room.name || (() => {
    if (room.type === 'direct') {
      const otherId = room.member_ids.find(id => id !== currentUserId)
      return otherId ? users[otherId]?.full_name || 'کاربر' : 'چت مستقیم'
    }
    return 'گروه'
  })()

  return (
    <button
      onClick={onClick}
      className={clsx(
        'w-full flex items-center gap-3 px-4 py-3 transition-colors border-b border-gray-50 hover:bg-gray-50',
        isActive && 'bg-primary-50 border-r-[3px] border-r-primary-600'
      )}
    >
      <div className="relative">
        {room.type === 'group' ? (
          <div className="w-10 h-10 bg-primary-100 rounded-full flex items-center justify-center">
            <Users size={18} className="text-primary-600" />
          </div>
        ) : (
          <Avatar name={name} />
        )}
      </div>
      <div className="flex-1 min-w-0 text-right">
        <p className={clsx('text-sm truncate', isActive ? 'font-semibold text-primary-700' : 'font-medium text-gray-800')}>
          {name}
        </p>
        {room.last_message_preview && (
          <p className="text-xs text-gray-400 truncate">{room.last_message_preview}</p>
        )}
      </div>
    </button>
  )
}

// ─── File Attachment Display ─────────────────────────────────────────────────
function FileAttachment({ fileId, isMe }: { fileId: string; isMe: boolean }) {
  const [url, setUrl] = useState<string | null>(null)
  const [name, setName] = useState<string>('')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    import('@/api/client').then(({ default: api }) => {
      api.get(`/files/${fileId}/url`).then((res: any) => {
        setUrl(res.data.url)
        setName(res.data.name || 'فایل')
      }).catch(() => {}).finally(() => setLoading(false))
    })
  }, [fileId])

  if (loading) return <div className="w-32 h-10 bg-gray-200 animate-pulse rounded-lg" />
  if (!url) return <span className="text-xs opacity-60">فایل در دسترس نیست</span>

  const handleDownload = (e: React.MouseEvent) => {
    e.preventDefault()
    const a = document.createElement('a')
    a.href = url
    a.download = name
    a.target = '_blank'
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
  }

  return (
    <button
      onClick={handleDownload}
      className={clsx(
        'flex items-center gap-2 px-3 py-2 rounded-xl text-sm hover:opacity-80 transition-opacity w-full text-right',
        isMe ? 'bg-white/20 text-white' : 'bg-gray-100 text-gray-700'
      )}
    >
      <Paperclip size={14} className="flex-shrink-0" />
      <span className="truncate max-w-[180px]">{name}</span>
    </button>
  )
}

// ─── Message Bubble ──────────────────────────────────────────────────────────
function MessageBubble({ msg, isMe, senderName }: { msg: Message; isMe: boolean; senderName: string }) {
  const { fromNow } = useJalali()
  const hasFile = msg.file_id && (msg.type === 'file' || msg.type === 'image')
  return (
    <div className={clsx('flex gap-2 group', isMe ? 'flex-row-reverse' : 'flex-row')}>
      {!isMe && (
        <Avatar name={senderName} size="xs" className="mt-1" />
      )}
      <div className={clsx('max-w-[70%] flex flex-col gap-0.5', isMe ? 'items-end' : 'items-start')}>
        {!isMe && <span className="text-xs text-gray-500 px-1">{senderName}</span>}
        <div className={clsx(
          'px-4 py-2.5 rounded-2xl text-sm leading-relaxed break-words',
          isMe
            ? 'bg-primary-600 text-white rounded-tr-sm'
            : 'bg-white text-gray-800 rounded-tl-sm shadow-sm border border-gray-100'
        )}>
          {hasFile
            ? <FileAttachment fileId={msg.file_id!} isMe={isMe} />
            : msg.content
          }
        </div>
        <span className="text-xs text-gray-400 px-1">{fromNow(msg.created_at)}</span>
      </div>
    </div>
  )
}

// ─── Main Chat ───────────────────────────────────────────────────────────────
export default function Chat() {
  const { user: currentUser } = useAuthStore()

  const [rooms, setRooms] = useState<ChatRoom[]>([])
  const [activeRoom, setActiveRoom] = useState<ChatRoom | null>(null)
  const [messages, setMessages] = useState<Message[]>([])
  const [allUsers, setAllUsers] = useState<User[]>([])
  const [usersMap, setUsersMap] = useState<Record<string, User>>({})
  const [text, setText] = useState('')
  const [loading, setLoading] = useState(true)
  const [showNewChat, setShowNewChat] = useState(false)
  const [roomSearch, setRoomSearch] = useState('')
  const [sending, setSending] = useState(false)

  const messagesEnd = useRef<HTMLDivElement>(null)
  const fileRef = useRef<HTMLInputElement>(null)
  const textareaRef = useRef<HTMLTextAreaElement>(null)

  // Load rooms and users
  const loadRooms = useCallback(async () => {
    try {
      const [roomRes, userRes] = await Promise.all([
        chatApi.listRooms(),
        usersApi.list(),
      ])
      setRooms(roomRes.data)
      const users = userRes.data as User[]
      setAllUsers(users)
      const map: Record<string, User> = {}
      users.forEach(u => { map[u.id] = u })
      setUsersMap(map)
    } catch {
      toast.error('خطا در بارگذاری چت‌ها')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { loadRooms() }, [loadRooms])

  // Load messages when room changes
  useEffect(() => {
    if (!activeRoom) return
    chatApi.getMessages(activeRoom.id, { limit: 60 }).then(res => {
      setMessages(res.data)
      chatApi.markRead(activeRoom.id).catch(() => {})
    }).catch(() => toast.error('خطا در دریافت پیام‌ها'))
  }, [activeRoom?.id])

  // Auto scroll
  useEffect(() => {
    messagesEnd.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  // WebSocket for realtime
  const wsUrl = activeRoom ? `/api/chat/ws/${activeRoom.id}` : null
  useWebSocket(wsUrl, {
    onMessage: (data: any) => {
      if (data.type === 'message' && data.data) {
        setMessages(prev => {
          const exists = prev.some(m => m.id === data.data.id)
          return exists ? prev : [...prev, data.data]
        })
        setRooms(prev => prev.map(r =>
          r.id === activeRoom?.id
            ? { ...r, last_message_preview: data.data.content?.slice(0, 50) }
            : r
        ))
      }
    },
  })

  const sendMessage = async () => {
    if (!text.trim() || !activeRoom || sending) return
    const content = text.trim()
    setText('')
    setSending(true)
    try {
      await chatApi.sendMessage(activeRoom.id, { content })
      // Message arrives via WebSocket onMessage — no need to add here to avoid duplicates
      setRooms(prev => prev.map(r =>
        r.id === activeRoom.id
          ? { ...r, last_message_preview: content.slice(0, 50), last_message_at: new Date().toISOString() }
          : r
      ))
    } catch {
      toast.error('خطا در ارسال پیام')
      setText(content)
    } finally {
      setSending(false)
      textareaRef.current?.focus()
    }
  }

  const uploadFile = async (file: File) => {
    if (!activeRoom) return
    try {
      const { data: fileMeta } = await chatApi.uploadFile(activeRoom.id, file)
      await chatApi.sendMessage(activeRoom.id, { file_id: fileMeta.file_id })
      toast.success('فایل ارسال شد')
    } catch {
      toast.error('خطا در آپلود فایل')
    }
  }

  // Start direct chat with a user
  const startDirectChat = async (user: User) => {
    try {
      const res = await chatApi.createRoom({ type: 'direct', member_ids: [user.id] })
      const room = res.data
      // Add to rooms if not exists
      setRooms(prev => {
        const exists = prev.some(r => r.id === room.id)
        return exists ? prev : [room, ...prev]
      })
      setActiveRoom(room)
    } catch {
      toast.error('خطا در ایجاد چت')
    }
  }

  // Create group
  const createGroup = async (name: string, memberIds: string[]) => {
    try {
      const res = await chatApi.createRoom({ type: 'group', name, member_ids: memberIds })
      setRooms(prev => [res.data, ...prev])
      setActiveRoom(res.data)
      toast.success('گروه ایجاد شد')
    } catch {
      toast.error('خطا در ایجاد گروه')
    }
  }

  const getRoomName = (room: ChatRoom) => {
    if (room.name) return room.name
    if (room.type === 'direct') {
      const otherId = room.member_ids.find(id => id !== currentUser?.id)
      return otherId ? usersMap[otherId]?.full_name || 'کاربر' : 'چت مستقیم'
    }
    return 'گروه'
  }

  const filteredRooms = rooms.filter(r =>
    getRoomName(r).toLowerCase().includes(roomSearch.toLowerCase())
  )

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="w-8 h-8 border-4 border-primary-500 border-t-transparent rounded-full animate-spin" />
      </div>
    )
  }

  return (
    <div className="flex h-full overflow-hidden bg-gray-50" dir="rtl" style={{ height: 'calc(100vh - 60px)' }}>
      {/* ── Sidebar: room list ── */}
      <div className="w-80 flex flex-col bg-white border-l border-gray-200 flex-shrink-0">
        {/* Header */}
        <div className="px-4 py-4 border-b border-gray-100">
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-bold text-gray-900 text-base">پیام‌ها</h2>
            <button
              onClick={() => setShowNewChat(true)}
              className="flex items-center gap-1.5 bg-primary-600 text-white px-3 py-1.5 rounded-lg text-xs font-medium hover:bg-primary-700 transition-colors"
              title="چت جدید"
            >
              <Plus size={14} />
              چت جدید
            </button>
          </div>
          {/* Search rooms */}
          <div className="relative">
            <Search size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              value={roomSearch}
              onChange={e => setRoomSearch(e.target.value)}
              placeholder="جستجو در مکالمات..."
              className="w-full text-sm border border-gray-200 rounded-lg pr-8 pl-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary-300"
            />
          </div>
        </div>

        {/* Room list OR quick-start user list if no rooms */}
        <div className="flex-1 overflow-y-auto">
          {rooms.length === 0 ? (
            <div className="p-4">
              <p className="text-xs text-gray-400 mb-3 text-right">شروع چت با:</p>
              <div className="space-y-1">
                {allUsers.filter(u => u.id !== currentUser?.id).map(u => (
                  <button
                    key={u.id}
                    onClick={() => startDirectChat(u)}
                    className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-gray-50 transition-colors"
                  >
                    <Avatar name={u.full_name} size="sm" />
                    <div className="text-right flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-700 truncate">{u.full_name}</p>
                      {u.position && <p className="text-xs text-gray-400 truncate">{u.position}</p>}
                    </div>
                  </button>
                ))}
              </div>
            </div>
          ) : filteredRooms.length === 0 ? (
            <p className="text-center text-gray-400 text-sm py-8">مکالمه‌ای یافت نشد</p>
          ) : (
            filteredRooms.map(room => (
              <RoomItem
                key={room.id}
                room={room}
                isActive={activeRoom?.id === room.id}
                currentUserId={currentUser?.id || ''}
                users={usersMap}
                onClick={() => setActiveRoom(room)}
              />
            ))
          )}
        </div>
      </div>

      {/* ── Chat area ── */}
      {activeRoom ? (
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Chat header */}
          <div className="flex items-center gap-3 px-5 py-3 bg-white border-b border-gray-200 shadow-sm">
            {activeRoom.type === 'group' ? (
              <div className="w-9 h-9 bg-primary-100 rounded-full flex items-center justify-center">
                <Users size={16} className="text-primary-600" />
              </div>
            ) : (
              <Avatar name={getRoomName(activeRoom)} size="sm" />
            )}
            <div>
              <p className="font-semibold text-gray-900">{getRoomName(activeRoom)}</p>
              <p className="text-xs text-gray-400">
                {activeRoom.type === 'group'
                  ? `${activeRoom.member_ids.length} عضو`
                  : (() => {
                    const otherId = activeRoom.member_ids.find(id => id !== currentUser?.id)
                    const other = otherId ? usersMap[otherId] : null
                    return other?.position || 'آنلاین'
                  })()
                }
              </p>
            </div>
            <button
              onClick={() => setActiveRoom(null)}
              className="mr-auto p-1.5 hover:bg-gray-100 rounded-lg text-gray-400 lg:hidden"
            >
              <X size={16} />
            </button>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-gray-50">
            {messages.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-gray-400 py-16">
                <MessageSquare size={40} className="mb-3 opacity-20" />
                <p className="text-sm">اولین پیام را ارسال کنید!</p>
              </div>
            ) : (
              messages.map(msg => (
                <MessageBubble
                  key={msg.id}
                  msg={msg}
                  isMe={msg.sender_id === currentUser?.id}
                  senderName={usersMap[msg.sender_id]?.full_name || 'کاربر'}
                />
              ))
            )}
            <div ref={messagesEnd} />
          </div>

          {/* Input */}
          <div className="bg-white border-t border-gray-200 px-4 py-3">
            <div className="flex items-end gap-2">
              <input
                type="file"
                ref={fileRef}
                className="hidden"
                tabIndex={-1}
                aria-hidden="true"
                onChange={e => { e.target.files?.[0] && uploadFile(e.target.files[0]); e.target.value = '' }}
              />
              <button
                type="button"
                onClick={e => { e.preventDefault(); e.stopPropagation(); fileRef.current?.click() }}
                className="p-2.5 hover:bg-gray-100 rounded-xl text-gray-400 hover:text-gray-600 transition-colors flex-shrink-0"
                title="پیوست فایل"
              >
                <Paperclip size={18} />
              </button>
              <textarea
                ref={textareaRef}
                value={text}
                onChange={e => {
                  setText(e.target.value)
                  e.target.style.height = 'auto'
                  e.target.style.height = Math.min(e.target.scrollHeight, 120) + 'px'
                }}
                onKeyDown={e => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault()
                    sendMessage()
                  }
                }}
                placeholder="پیام بنویسید... (Enter برای ارسال، Shift+Enter برای خط جدید)"
                rows={1}
                className="flex-1 resize-none border border-gray-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary-300 max-h-32 bg-gray-50"
                style={{ overflowY: 'auto' }}
              />
              <button
                onClick={sendMessage}
                disabled={!text.trim() || sending}
                className="p-2.5 bg-primary-600 text-white rounded-xl hover:bg-primary-700 disabled:opacity-40 disabled:cursor-not-allowed transition-colors flex-shrink-0"
                title="ارسال"
              >
                <Send size={18} />
              </button>
            </div>
          </div>
        </div>
      ) : (
        /* Empty state */
        <div className="flex-1 flex flex-col items-center justify-center text-gray-400 bg-gray-50">
          <div className="w-20 h-20 bg-white rounded-2xl shadow-sm flex items-center justify-center mb-4">
            <MessageSquare size={36} className="text-primary-300" />
          </div>
          <p className="text-lg font-medium text-gray-500 mb-2">یک گفتگو انتخاب کنید</p>
          <p className="text-sm text-gray-400 mb-6">یا چت جدیدی شروع کنید</p>
          <button
            onClick={() => setShowNewChat(true)}
            className="flex items-center gap-2 bg-primary-600 text-white px-5 py-2.5 rounded-xl text-sm font-medium hover:bg-primary-700 transition-colors"
          >
            <Plus size={16} />
            شروع چت جدید
          </button>
        </div>
      )}

      {/* New chat modal */}
      {showNewChat && (
        <NewChatModal
          users={allUsers}
          currentUserId={currentUser?.id || ''}
          onClose={() => setShowNewChat(false)}
          onSelectUser={startDirectChat}
          onCreateGroup={createGroup}
        />
      )}
    </div>
  )
}
