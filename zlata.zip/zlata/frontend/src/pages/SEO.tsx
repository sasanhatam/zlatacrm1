import { useState, useEffect, useRef, useCallback } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import api from '@/api/client'
import { usersApi } from '@/api/users'
import { useAuthStore } from '@/store/authStore'
import {
  Plus, Search, Edit2, Trash2, Save, X, Image, Upload,
  Bold, Italic, Underline, AlignRight, AlignLeft, AlignCenter,
  List, Code, Link2, Eye, EyeOff, ChevronRight,
} from 'lucide-react'
import toast from 'react-hot-toast'
import clsx from 'clsx'

type SEOStatus = 'draft' | 'in_progress' | 'review' | 'published'

interface SEOItem {
  id: string
  title: string
  keyword: string
  url: string
  anchor_text: string
  body_html: string
  seo_title: string
  meta_description: string
  internal_link_text: string
  schema_code: string
  status: SEOStatus
  assignee_id: string | null
  created_by: string
  publish_date: string | null
  featured_image_data: string | null
  extra_image_data: string[]
  created_at: string
  updated_at: string
}

const STATUS_LABELS: Record<SEOStatus, string> = {
  draft: 'پیش‌نویس',
  in_progress: 'در حال نوشتن',
  review: 'در بررسی',
  published: 'منتشر شده',
}

const STATUS_COLORS: Record<SEOStatus, string> = {
  draft: 'bg-gray-100 text-gray-600',
  in_progress: 'bg-blue-100 text-blue-700',
  review: 'bg-yellow-100 text-yellow-700',
  published: 'bg-green-100 text-green-700',
}

// ─── Rich Text Editor ─────────────────────────────────────────────────────────
function RichEditor({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  const editorRef = useRef<HTMLDivElement>(null)
  const isComposing = useRef(false)
  const [showSource, setShowSource] = useState(false)
  const [sourceHtml, setSourceHtml] = useState('')
  // track current active format for toolbar state
  const [activeFormats, setActiveFormats] = useState<Set<string>>(new Set())

  // init editor with value on mount only
  useEffect(() => {
    if (editorRef.current) {
      editorRef.current.innerHTML = value || ''
      // use <p> for Enter key, not <div>
      document.execCommand('defaultParagraphSeparator', false, 'p')
    }
  }, []) // eslint-disable-line react-hooks/exhaustive-deps

  const updateActiveFormats = useCallback(() => {
    const formats = new Set<string>()
    if (document.queryCommandState('bold')) formats.add('bold')
    if (document.queryCommandState('italic')) formats.add('italic')
    if (document.queryCommandState('underline')) formats.add('underline')
    setActiveFormats(formats)
  }, [])

  const exec = useCallback((cmd: string, val?: string) => {
    editorRef.current?.focus()
    document.execCommand(cmd, false, val)
    if (editorRef.current) onChange(editorRef.current.innerHTML)
    updateActiveFormats()
  }, [onChange, updateActiveFormats])

  const insertLink = () => {
    const url = window.prompt('آدرس لینک را وارد کنید:')
    if (url) exec('createLink', url)
  }

  const toggleSource = () => {
    if (showSource) {
      // source → visual
      setShowSource(false)
      requestAnimationFrame(() => {
        if (editorRef.current) {
          editorRef.current.innerHTML = sourceHtml
          onChange(sourceHtml)
          document.execCommand('defaultParagraphSeparator', false, 'p')
        }
      })
    } else {
      // visual → source
      const html = editorRef.current?.innerHTML || ''
      setSourceHtml(html)
      onChange(html)
      setShowSource(true)
    }
  }

  const fmtBtn = (cmd: string, icon: React.ReactNode, title: string) => (
    <button type="button" title={title}
      onMouseDown={e => { e.preventDefault(); exec(cmd) }}
      className={`p-1.5 rounded transition-colors ${activeFormats.has(cmd) ? 'bg-primary-100 text-primary-700' : 'hover:bg-gray-200 text-gray-600 hover:text-gray-900'}`}>
      {icon}
    </button>
  )

  const btn = (action: () => void, icon: React.ReactNode, title: string) => (
    <button type="button" title={title} onMouseDown={e => { e.preventDefault(); action() }}
      className="p-1.5 hover:bg-gray-200 rounded text-gray-600 hover:text-gray-900 transition-colors">
      {icon}
    </button>
  )

  const toolbar = (
    <div className="flex flex-wrap items-center gap-0.5 px-2 py-1.5 bg-gray-50 border-b border-gray-200">
      {fmtBtn('bold', <Bold size={14} />, 'بولد')}
      {fmtBtn('italic', <Italic size={14} />, 'ایتالیک')}
      {fmtBtn('underline', <Underline size={14} />, 'زیرخط')}
      <span className="w-px h-5 bg-gray-300 mx-1" />
      {btn(() => exec('justifyRight'), <AlignRight size={14} />, 'راست‌چین')}
      {btn(() => exec('justifyCenter'), <AlignCenter size={14} />, 'وسط‌چین')}
      {btn(() => exec('justifyLeft'), <AlignLeft size={14} />, 'چپ‌چین')}
      <span className="w-px h-5 bg-gray-300 mx-1" />
      {btn(() => exec('insertUnorderedList'), <List size={14} />, 'لیست نقطه‌ای')}
      {btn(insertLink, <Link2 size={14} />, 'لینک')}
      <span className="w-px h-5 bg-gray-300 mx-1" />
      <select
        onMouseDown={e => e.stopPropagation()}
        onChange={e => { exec('formatBlock', e.target.value); e.target.value = 'default' }}
        defaultValue="default"
        className="text-xs border border-gray-200 rounded px-1 py-0.5 bg-white focus:outline-none cursor-pointer"
      >
        <option value="default" disabled>قالب‌بندی</option>
        <option value="p">پاراگراف</option>
        <option value="h1">H1 — تیتر اصلی</option>
        <option value="h2">H2 — تیتر دوم</option>
        <option value="h3">H3 — تیتر سوم</option>
        <option value="h4">H4 — تیتر چهارم</option>
        <option value="blockquote">نقل‌قول</option>
      </select>
      <span className="w-px h-5 bg-gray-300 mx-1" />
      {btn(() => exec('removeFormat'), <span className="text-xs font-bold px-0.5">T̶</span>, 'حذف قالب‌بندی')}
      <button type="button" onClick={toggleSource}
        className={`mr-auto flex items-center gap-1 text-xs px-2 py-1 rounded transition-colors ${showSource ? 'bg-primary-100 text-primary-700' : 'hover:bg-gray-200 text-gray-500 hover:text-gray-700'}`}>
        {showSource ? <><Eye size={12} /> نمایش بصری</> : <><EyeOff size={12} /> کد HTML</>}
      </button>
    </div>
  )

  return (
    <div className="border border-gray-300 rounded-xl overflow-hidden focus-within:ring-2 focus-within:ring-primary-300">
      {toolbar}

      {showSource ? (
        <textarea
          value={sourceHtml}
          onChange={e => { setSourceHtml(e.target.value); onChange(e.target.value) }}
          onKeyDown={e => e.stopPropagation()}
          className="w-full min-h-[350px] p-4 text-xs font-mono resize-y focus:outline-none bg-gray-900 text-green-300 leading-relaxed"
          dir="ltr"
          spellCheck={false}
          autoFocus
        />
      ) : (
        <div
          ref={editorRef}
          contentEditable
          suppressContentEditableWarning
          dir="rtl"
          onCompositionStart={() => { isComposing.current = true }}
          onCompositionEnd={() => {
            isComposing.current = false
            if (editorRef.current) onChange(editorRef.current.innerHTML)
          }}
          onInput={() => {
            if (!isComposing.current && editorRef.current) onChange(editorRef.current.innerHTML)
          }}
          onKeyUp={updateActiveFormats}
          onMouseUp={updateActiveFormats}
          onSelect={updateActiveFormats}
          className="rich-editor-content min-h-[350px] px-5 py-4 text-sm outline-none font-sans"
          style={{ direction: 'rtl', textAlign: 'right', lineHeight: '2' }}
          data-placeholder="محتوای مقاله را اینجا بنویسید..."
        />
      )}
    </div>
  )
}

// ─── SEO Editor (full form) ───────────────────────────────────────────────────
function SEOEditor({ item, users, onSaved, onClose }: {
  item: Partial<SEOItem>
  users: any[]
  onSaved: (saved: SEOItem) => void
  onClose: () => void
}) {
  const [form, setForm] = useState({
    title: item.title || '',
    keyword: item.keyword || '',
    url: item.url || '',
    anchor_text: item.anchor_text || '',
    body_html: item.body_html || '',
    seo_title: item.seo_title || '',
    meta_description: item.meta_description || '',
    internal_link_text: item.internal_link_text || '',
    schema_code: item.schema_code || '',
    status: (item.status || 'draft') as SEOStatus,
    assignee_id: item.assignee_id || '',
  })
  const [schemaError, setSchemaError] = useState('')
  const [featuredImage, setFeaturedImage] = useState<string | null>(item.featured_image_data || null)
  const [extraImages, setExtraImages] = useState<string[]>(item.extra_image_data || [])
  const [saving, setSaving] = useState(false)
  const featuredRef = useRef<HTMLInputElement>(null)
  const extrasRef = useRef<HTMLInputElement>(null)

  const f = (field: string, val: string) => setForm(prev => ({ ...prev, [field]: val }))

  const save = async () => {
    if (!form.title.trim()) return toast.error('عنوان الزامی است')
    setSaving(true)
    try {
      const payload = { ...form, assignee_id: form.assignee_id || undefined }
      let res: any
      if (item.id) {
        res = await api.put(`/seo/${item.id}`, payload)
      } else {
        res = await api.post('/seo', payload)
      }
      // Upload featured image if new
      if (featuredImage && featuredImage !== item.featured_image_data) {
        const blob = await fetch(featuredImage).then(r => r.blob())
        const fd = new FormData()
        fd.append('file', blob, 'featured.jpg')
        const imgRes: any = await api.post(`/seo/${res.data.id}/featured-image`, fd, { headers: { 'Content-Type': 'multipart/form-data' } })
        res.data.featured_image_data = imgRes.data.featured_image_data
      }
      toast.success(item.id ? 'ذخیره شد' : 'محتوا ایجاد شد')
      onSaved(res.data)
    } catch (e: any) {
      toast.error(e.response?.data?.detail || 'خطا در ذخیره')
    } finally {
      setSaving(false)
    }
  }

  const handleFeaturedFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    const reader = new FileReader()
    reader.onload = () => setFeaturedImage(reader.result as string)
    reader.readAsDataURL(file)
  }

  const handleExtraFiles = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || [])
    files.forEach(file => {
      const reader = new FileReader()
      reader.onload = () => setExtraImages(prev => [...prev, reader.result as string])
      reader.readAsDataURL(file)
    })
  }

  const field = (label: string, key: string, placeholder = '', dir: 'rtl' | 'ltr' = 'rtl', hint?: string) => (
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
      {hint && <p className="text-xs text-gray-400 mb-1">{hint}</p>}
      <input
        type="text"
        value={(form as any)[key]}
        onChange={e => f(key, e.target.value)}
        placeholder={placeholder}
        dir={dir}
        className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary-300"
      />
    </div>
  )

  const charCount = (text: string, max: number) => (
    <span className={clsx('text-xs', text.length > max ? 'text-red-500' : 'text-gray-400')}>
      {text.length}/{max}
    </span>
  )

  return (
    <div className="fixed inset-0 bg-black/40 z-50 flex overflow-hidden" dir="rtl">
      <div className="bg-white w-full max-w-5xl mx-auto flex flex-col shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b bg-white sticky top-0 z-10">
          <div className="flex items-center gap-3">
            <button onClick={onClose} className="p-1.5 hover:bg-gray-100 rounded-lg text-gray-400">
              <X size={18} />
            </button>
            <h2 className="text-lg font-bold text-gray-900">{item.id ? 'ویرایش محتوا' : 'محتوای جدید'}</h2>
          </div>
          <div className="flex items-center gap-3">
            <select value={form.status} onChange={e => f('status', e.target.value)}
              className="text-sm border border-gray-300 rounded-lg px-3 py-1.5 focus:outline-none">
              {Object.entries(STATUS_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
            </select>
            <button onClick={save} disabled={saving}
              className="flex items-center gap-2 bg-primary-600 text-white px-5 py-2 rounded-lg text-sm hover:bg-primary-700 disabled:opacity-50">
              <Save size={15} />
              {saving ? 'در حال ذخیره...' : 'ذخیره'}
            </button>
          </div>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto">
          <div className="grid grid-cols-3 gap-0 h-full">
            {/* Main content area */}
            <div className="col-span-2 p-6 space-y-5 border-l">
              {field('عنوان مقاله *', 'title', 'عنوان کامل محتوا را وارد کنید')}

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-sm font-medium text-gray-700">محتوای مقاله *</label>
                </div>
                <RichEditor value={form.body_html} onChange={v => f('body_html', v)} />
              </div>

              {/* SEO meta */}
              <div className="border border-gray-200 rounded-xl p-4 space-y-3 bg-gray-50">
                <p className="text-sm font-semibold text-gray-700">اطلاعات SEO</p>
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-sm font-medium text-gray-700">سئو تایتل</label>
                    {charCount(form.seo_title, 60)}
                  </div>
                  <input value={form.seo_title} onChange={e => f('seo_title', e.target.value)}
                    placeholder="عنوان نمایشی در گوگل (حداکثر ۶۰ کاراکتر)"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary-300" />
                </div>
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-sm font-medium text-gray-700">متا دیسکریپشن</label>
                    {charCount(form.meta_description, 160)}
                  </div>
                  <textarea value={form.meta_description} onChange={e => f('meta_description', e.target.value)}
                    placeholder="توضیح کوتاه برای گوگل (حداکثر ۱۶۰ کاراکتر)"
                    rows={3} className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-primary-300" />
                </div>
              </div>

              {/* Internal linking */}
              <div className="border border-gray-200 rounded-xl p-4 space-y-3 bg-gray-50">
                <p className="text-sm font-semibold text-gray-700">لینک‌سازی داخلی</p>
                {field('انکر تکست این صفحه', 'anchor_text', 'کلمه‌ای که سایر صفحات با آن به اینجا لینک می‌دهند')}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">متن لینک‌های داخلی از سایر صفحات</label>
                  <textarea value={form.internal_link_text} onChange={e => f('internal_link_text', e.target.value)}
                    placeholder="هر لینک را در یک خط بنویسید (URL | انکر تکست)"
                    rows={4} className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-primary-300" dir="ltr" />
                </div>
              </div>

              {/* Schema Markup */}
              <div className="border border-gray-200 rounded-xl overflow-hidden">
                <div className="flex items-center justify-between px-4 py-3 bg-gray-800">
                  <div className="flex items-center gap-2">
                    <Code size={15} className="text-green-400" />
                    <p className="text-sm font-semibold text-gray-100">کد Schema (JSON-LD)</p>
                  </div>
                  <div className="flex items-center gap-3">
                    {schemaError && (
                      <span className="text-xs text-red-400">{schemaError}</span>
                    )}
                    <button
                      type="button"
                      onClick={() => {
                        try {
                          if (!form.schema_code.trim()) return
                          const parsed = JSON.parse(form.schema_code)
                          const formatted = JSON.stringify(parsed, null, 2)
                          f('schema_code', formatted)
                          setSchemaError('')
                        } catch {
                          setSchemaError('JSON نامعتبر است')
                        }
                      }}
                      className="text-xs text-gray-300 hover:text-white px-2 py-1 rounded border border-gray-600 hover:border-gray-400 transition-colors"
                    >
                      Format JSON
                    </button>
                  </div>
                </div>
                <textarea
                  value={form.schema_code}
                  onChange={e => {
                    f('schema_code', e.target.value)
                    setSchemaError('')
                  }}
                  onKeyDown={e => {
                    // Tab inserts 2 spaces instead of losing focus
                    if (e.key === 'Tab') {
                      e.preventDefault()
                      const el = e.currentTarget
                      const start = el.selectionStart
                      const end = el.selectionEnd
                      const val = el.value
                      f('schema_code', val.substring(0, start) + '  ' + val.substring(end))
                      requestAnimationFrame(() => {
                        el.selectionStart = el.selectionEnd = start + 2
                      })
                    }
                  }}
                  placeholder={`{\n  "@context": "https://schema.org",\n  "@type": "Article",\n  "name": "عنوان مقاله"\n}`}
                  rows={10}
                  spellCheck={false}
                  dir="ltr"
                  className="w-full px-4 py-3 text-xs font-mono resize-y focus:outline-none bg-gray-900 text-green-300 leading-relaxed placeholder-gray-600 min-h-[200px]"
                />
              </div>
            </div>

            {/* Sidebar */}
            <div className="p-5 space-y-5 bg-gray-50">
              {/* Assignee */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">اساین به</label>
                <select value={form.assignee_id} onChange={e => f('assignee_id', e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none">
                  <option value="">انتخاب کنید</option>
                  {users.map(u => <option key={u.id} value={u.id}>{u.full_name}</option>)}
                </select>
              </div>

              {/* Keyword */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">کلمه کلیدی اصلی</label>
                <input value={form.keyword} onChange={e => f('keyword', e.target.value)}
                  placeholder="مثال: طراحی سایت"
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary-300" />
              </div>

              {/* URL */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">آدرس URL صفحه</label>
                <input value={form.url} onChange={e => f('url', e.target.value)}
                  placeholder="/blog/article-slug"
                  dir="ltr"
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary-300 text-left" />
              </div>

              {/* Featured image */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">تصویر شاخص</label>
                <input ref={featuredRef} type="file" accept="image/*" onChange={handleFeaturedFile} className="hidden" />
                {featuredImage ? (
                  <div className="relative">
                    <img src={featuredImage} alt="featured" className="w-full h-36 object-cover rounded-xl border" />
                    <button type="button" onClick={() => setFeaturedImage(null)}
                      className="absolute top-2 left-2 p-1 bg-red-500 text-white rounded-full hover:bg-red-600">
                      <X size={12} />
                    </button>
                  </div>
                ) : (
                  <button type="button" onClick={() => featuredRef.current?.click()}
                    className="w-full border-2 border-dashed border-gray-300 rounded-xl p-6 text-center hover:border-primary-400 transition-colors">
                    <Image size={24} className="mx-auto mb-2 text-gray-400" />
                    <p className="text-xs text-gray-400">کلیک برای آپلود</p>
                  </button>
                )}
              </div>

              {/* Extra images */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="block text-sm font-medium text-gray-700">تصاویر اضافی</label>
                  <button type="button" onClick={() => extrasRef.current?.click()}
                    className="flex items-center gap-1 text-xs text-primary-600 hover:text-primary-800">
                    <Upload size={12} /> افزودن
                  </button>
                </div>
                <input ref={extrasRef} type="file" accept="image/*" multiple onChange={handleExtraFiles} className="hidden" />
                {extraImages.length > 0 && (
                  <div className="grid grid-cols-3 gap-2">
                    {extraImages.map((img, i) => (
                      <div key={i} className="relative">
                        <img src={img} alt="" className="w-full h-16 object-cover rounded-lg border" />
                        <button type="button" onClick={() => setExtraImages(prev => prev.filter((_, j) => j !== i))}
                          className="absolute -top-1 -right-1 p-0.5 bg-red-500 text-white rounded-full">
                          <X size={10} />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

// ─── Main SEO Page ────────────────────────────────────────────────────────────
export default function SEO() {
  const { id } = useParams()
  const navigate = useNavigate()
  const { user: currentUser } = useAuthStore()
  const [items, setItems] = useState<SEOItem[]>([])
  const [users, setUsers] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState<SEOStatus | ''>('')
  const [editing, setEditing] = useState<Partial<SEOItem> | null>(null)

  const load = async () => {
    try {
      const [itemsRes, usersRes] = await Promise.all([
        api.get('/seo'),
        usersApi.list(),
      ])
      setItems((itemsRes as any).data)
      setUsers((usersRes as any).data)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { load() }, [])

  const userMap = Object.fromEntries(users.map((u: any) => [u.id, u.full_name]))

  const filtered = items.filter(item => {
    const q = search.toLowerCase()
    const matchSearch = !q || item.title.toLowerCase().includes(q) || item.keyword.toLowerCase().includes(q)
    const matchStatus = !statusFilter || item.status === statusFilter
    return matchSearch && matchStatus
  })

  const del = async (item: SEOItem) => {
    if (!confirm(`حذف "${item.title}"؟`)) return
    await api.delete(`/seo/${item.id}`)
    setItems(prev => prev.filter(i => i.id !== item.id))
    toast.success('حذف شد')
  }

  const handleSaved = (saved: SEOItem) => {
    setItems(prev => {
      const idx = prev.findIndex(i => i.id === saved.id)
      if (idx >= 0) { const n = [...prev]; n[idx] = saved; return n }
      return [saved, ...prev]
    })
    setEditing(null)
  }

  if (loading) return (
    <div className="flex items-center justify-center h-64">
      <div className="w-8 h-8 border-4 border-primary-500 border-t-transparent rounded-full animate-spin" />
    </div>
  )

  return (
    <div dir="rtl">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">برنامه‌ریزی SEO</h1>
          <p className="text-sm text-gray-500 mt-0.5">مدیریت و زمانبندی محتوای سئو</p>
        </div>
        <button
          onClick={() => setEditing({})}
          className="flex items-center gap-2 bg-primary-600 text-white px-4 py-2 rounded-xl text-sm hover:bg-primary-700"
        >
          <Plus size={16} />
          محتوای جدید
        </button>
      </div>

      {/* Filters */}
      <div className="flex gap-3 mb-5">
        <div className="relative flex-1 max-w-sm">
          <Search size={15} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input value={search} onChange={e => setSearch(e.target.value)}
            placeholder="جستجو در عنوان یا کلمه کلیدی..."
            className="w-full border border-gray-300 rounded-xl px-3 py-2 pr-9 text-sm focus:outline-none focus:ring-2 focus:ring-primary-300" />
        </div>
        <div className="flex gap-2">
          {(['', 'draft', 'in_progress', 'review', 'published'] as const).map(s => (
            <button key={s} onClick={() => setStatusFilter(s)}
              className={clsx(
                'px-3 py-1.5 rounded-xl text-sm border transition-colors',
                statusFilter === s
                  ? 'bg-primary-600 text-white border-primary-600'
                  : 'bg-white text-gray-600 border-gray-300 hover:border-primary-300'
              )}>
              {s ? STATUS_LABELS[s] : 'همه'}
            </button>
          ))}
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-4 mb-6">
        {(['draft', 'in_progress', 'review', 'published'] as SEOStatus[]).map(s => (
          <div key={s} className="card p-4">
            <p className="text-xs text-gray-400 mb-1">{STATUS_LABELS[s]}</p>
            <p className="text-2xl font-bold text-gray-900">{items.filter(i => i.status === s).length}</p>
          </div>
        ))}
      </div>

      {/* Table */}
      <div className="card overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-gray-50 border-b border-gray-100">
              <th className="text-right px-4 py-3 font-medium text-gray-500">عنوان</th>
              <th className="text-right px-4 py-3 font-medium text-gray-500">کلمه کلیدی</th>
              <th className="text-right px-4 py-3 font-medium text-gray-500">URL</th>
              <th className="text-right px-4 py-3 font-medium text-gray-500">وضعیت</th>
              <th className="text-right px-4 py-3 font-medium text-gray-500">مسئول</th>
              <th className="px-4 py-3" />
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-50">
            {filtered.map(item => (
              <tr key={item.id} className="hover:bg-gray-50 group">
                <td className="px-4 py-3">
                  <button onClick={() => setEditing(item)}
                    className="font-medium text-gray-900 hover:text-primary-600 text-right">
                    {item.title}
                  </button>
                  {item.keyword && (
                    <div className="flex flex-wrap gap-1 mt-1">
                      <span className="text-xs bg-primary-50 text-primary-600 px-2 py-0.5 rounded-full">{item.keyword}</span>
                    </div>
                  )}
                </td>
                <td className="px-4 py-3 text-gray-500 font-mono text-xs">{item.keyword || '—'}</td>
                <td className="px-4 py-3">
                  {item.url
                    ? <span className="text-xs text-blue-600 font-mono" dir="ltr">{item.url}</span>
                    : <span className="text-gray-400">—</span>
                  }
                </td>
                <td className="px-4 py-3">
                  <span className={clsx('text-xs px-2 py-1 rounded-full font-medium', STATUS_COLORS[item.status])}>
                    {STATUS_LABELS[item.status]}
                  </span>
                </td>
                <td className="px-4 py-3 text-gray-500 text-xs">
                  {item.assignee_id ? userMap[item.assignee_id] || '—' : '—'}
                </td>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity justify-end">
                    <button onClick={() => setEditing(item)}
                      className="p-1.5 hover:bg-gray-100 rounded-lg text-gray-400 hover:text-primary-600">
                      <Edit2 size={14} />
                    </button>
                    <button onClick={() => del(item)}
                      className="p-1.5 hover:bg-red-50 rounded-lg text-gray-400 hover:text-red-500">
                      <Trash2 size={14} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
            {filtered.length === 0 && (
              <tr>
                <td colSpan={6} className="text-center py-12 text-gray-400">
                  <Search size={36} className="mx-auto mb-3 text-gray-200" />
                  <p>محتوایی یافت نشد</p>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {editing !== null && (
        <SEOEditor
          item={editing}
          users={users}
          onSaved={handleSaved}
          onClose={() => setEditing(null)}
        />
      )}
    </div>
  )
}
