import { useState, useEffect, useRef } from 'react'
import api from '@/api/client'
import { companiesApi } from '@/api/companies'
import { Company } from '@/types/common'
import { Mail, Building2, Save, TestTube, CheckCircle, XCircle, FileText, Upload, Trash2, Image } from 'lucide-react'
import toast from 'react-hot-toast'

interface LetterheadSettings {
  has_logo: boolean
  has_stamp: boolean
  letterhead_logo_data: string | null
  letterhead_stamp_data: string | null
  letterhead_header_data: string | null
  letterhead_footer_data: string | null
}

function ImageUploadBox({
  label, hint, imageData, uploading, onUpload, onDelete
}: {
  label: string
  hint?: string
  imageData: string | null
  uploading: boolean
  onUpload: (file: File) => void
  onDelete: () => void
}) {
  const inputRef = useRef<HTMLInputElement>(null)

  return (
    <div className="border border-gray-200 rounded-xl overflow-hidden">
      <div className="flex items-center justify-between px-4 py-3 bg-gray-50 border-b border-gray-100">
        <div>
          <p className="text-sm font-semibold text-gray-800">{label}</p>
          {hint && <p className="text-xs text-gray-400 mt-0.5">{hint}</p>}
        </div>
        <div className="flex items-center gap-2">
          {imageData && (
            <button type="button" onClick={onDelete}
              className="flex items-center gap-1.5 text-xs text-red-500 hover:text-red-700 px-3 py-1.5 border border-red-200 rounded-lg hover:bg-red-50 transition-colors">
              <Trash2 size={12} />
              حذف
            </button>
          )}
          <label className="flex items-center gap-1.5 text-xs text-primary-600 hover:text-primary-800 px-3 py-1.5 border border-primary-200 rounded-lg hover:bg-primary-50 transition-colors cursor-pointer">
            <Upload size={12} />
            {imageData ? 'تغییر تصویر' : 'آپلود تصویر'}
            <input ref={inputRef} type="file" accept="image/*" className="hidden"
              onChange={e => e.target.files?.[0] && onUpload(e.target.files[0])} />
          </label>
        </div>
      </div>
      {imageData ? (
        <div className="bg-white p-0">
          <img src={imageData} alt={label} className="w-full h-auto object-cover block" />
          {uploading && (
            <div className="absolute inset-0 bg-white/70 flex items-center justify-center">
              <div className="w-6 h-6 border-4 border-primary-500 border-t-transparent rounded-full animate-spin" />
            </div>
          )}
        </div>
      ) : (
        <label className="flex flex-col items-center justify-center p-10 cursor-pointer hover:bg-gray-50 transition-colors min-h-[120px]"
          onClick={() => inputRef.current?.click()}>
          {uploading
            ? <div className="w-8 h-8 border-4 border-primary-500 border-t-transparent rounded-full animate-spin" />
            : <>
                <Image size={32} className="text-gray-300 mb-3" />
                <p className="text-sm text-gray-400">کلیک برای انتخاب تصویر</p>
                <p className="text-xs text-gray-300 mt-1">PNG، JPG یا WebP</p>
              </>
          }
        </label>
      )}
    </div>
  )
}

export default function SystemSettings() {
  const [smtp, setSmtp] = useState({
    smtp_host: '', smtp_port: 587, smtp_username: '', smtp_password: '',
    smtp_from_email: '', smtp_from_name: '', smtp_use_tls: true
  })
  const [org, setOrg] = useState({
    org_name: '', org_address: '', org_phone: '', org_website: '', stale_task_days: 7
  })
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState<string | null>(null)
  const [testResult, setTestResult] = useState<boolean | null>(null)
  const [companies, setCompanies] = useState<Company[]>([])
  const [activeCompanyIdx, setActiveCompanyIdx] = useState(0)
  const [lhUploading, setLhUploading] = useState<string | null>(null)

  const loadCompanies = () =>
    companiesApi.list().then(r => setCompanies(r.data)).catch(() => {})

  useEffect(() => {
    Promise.all([
      api.get('/admin/settings'),
      loadCompanies(),
    ]).then(([sRes]: any) => {
      const d = sRes.data
      setSmtp({
        smtp_host: d.smtp_host, smtp_port: d.smtp_port, smtp_username: d.smtp_username,
        smtp_password: d.smtp_password || '', smtp_from_email: d.smtp_from_email,
        smtp_from_name: d.smtp_from_name, smtp_use_tls: d.smtp_use_tls
      })
      setOrg({
        org_name: d.org_name, org_address: d.org_address || '', org_phone: d.org_phone || '',
        org_website: d.org_website || '', stale_task_days: d.stale_task_days
      })
    }).finally(() => setLoading(false))
  }, [])

  const saveSmtp = async (e: React.FormEvent) => {
    e.preventDefault(); setSaving('smtp')
    try { await api.put('/admin/settings/smtp', smtp); toast.success('تنظیمات SMTP ذخیره شد') }
    catch { toast.error('خطا در ذخیره') } finally { setSaving(null) }
  }

  const saveOrg = async (e: React.FormEvent) => {
    e.preventDefault(); setSaving('org')
    try { await api.put('/admin/settings/org', org); toast.success('اطلاعات سازمان ذخیره شد') }
    catch { toast.error('خطا در ذخیره') } finally { setSaving(null) }
  }

  const testSmtp = async () => {
    setSaving('test')
    try {
      const res: any = await api.post('/admin/settings/smtp/test')
      setTestResult(res.data.success)
      toast(res.data.success ? `ایمیل تست به ${res.data.sent_to} ارسال شد` : 'ارسال ناموفق',
        { icon: res.data.success ? '✅' : '❌' })
    } catch { setTestResult(false) } finally { setSaving(null) }
  }

  const uploadCompanyLh = async (companyId: string, type: 'header' | 'footer', file: File) => {
    setLhUploading(`${companyId}_${type}`)
    try {
      if (type === 'header') await companiesApi.uploadLetterheadHeader(companyId, file)
      else await companiesApi.uploadLetterheadFooter(companyId, file)
      toast.success('تصویر آپلود شد')
      await loadCompanies()
    } catch { toast.error('خطا در آپلود') } finally { setLhUploading(null) }
  }

  const deleteCompanyLh = async (companyId: string, type: 'header' | 'footer') => {
    setLhUploading(`${companyId}_del_${type}`)
    try {
      if (type === 'header') await companiesApi.deleteLetterheadHeader(companyId)
      else await companiesApi.deleteLetterheadFooter(companyId)
      toast.success('حذف شد')
      await loadCompanies()
    } catch { toast.error('خطا در حذف') } finally { setLhUploading(null) }
  }

  if (loading) return (
    <div className="flex items-center justify-center h-64">
      <div className="w-8 h-8 border-4 border-primary-500 border-t-transparent rounded-full animate-spin" />
    </div>
  )

  return (
    <div className="max-w-3xl mx-auto space-y-6" dir="rtl">
      <h1 className="text-2xl font-bold text-gray-900">تنظیمات سیستم</h1>

      {/* SMTP */}
      <div className="card p-6">
        <h3 className="font-semibold text-gray-800 mb-5 flex items-center gap-2">
          <Mail size={16} />تنظیمات ایمیل (SMTP)
        </h3>
        <form onSubmit={saveSmtp} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Host</label>
              <input className="input-field" value={smtp.smtp_host} onChange={e => setSmtp({ ...smtp, smtp_host: e.target.value })} dir="ltr" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Port</label>
              <input type="number" className="input-field" value={smtp.smtp_port} onChange={e => setSmtp({ ...smtp, smtp_port: +e.target.value })} dir="ltr" />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">نام کاربری Gmail</label>
            <input className="input-field" value={smtp.smtp_username} onChange={e => setSmtp({ ...smtp, smtp_username: e.target.value })} dir="ltr" placeholder="yourmail@gmail.com" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">App Password</label>
            <input type="password" className="input-field" value={smtp.smtp_password} onChange={e => setSmtp({ ...smtp, smtp_password: e.target.value })} dir="ltr" placeholder="xxxx xxxx xxxx xxxx" />
            <p className="text-xs text-gray-400 mt-1">از Google Account → Security → App Passwords بسازید</p>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">From Email</label>
              <input className="input-field" value={smtp.smtp_from_email} onChange={e => setSmtp({ ...smtp, smtp_from_email: e.target.value })} dir="ltr" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">From Name</label>
              <input className="input-field" value={smtp.smtp_from_name} onChange={e => setSmtp({ ...smtp, smtp_from_name: e.target.value })} />
            </div>
          </div>
          <label className="flex items-center gap-2 cursor-pointer">
            <input type="checkbox" checked={smtp.smtp_use_tls} onChange={e => setSmtp({ ...smtp, smtp_use_tls: e.target.checked })} className="rounded" />
            <span className="text-sm text-gray-700">استفاده از TLS</span>
          </label>
          <div className="flex gap-3">
            <button type="submit" disabled={!!saving} className="btn-primary flex items-center gap-2">
              <Save size={15} />{saving === 'smtp' ? 'در حال ذخیره...' : 'ذخیره'}
            </button>
            <button type="button" onClick={testSmtp} disabled={!!saving} className="btn-secondary flex items-center gap-2">
              <TestTube size={15} />تست ایمیل
              {testResult !== null && (testResult
                ? <CheckCircle size={14} className="text-green-500" />
                : <XCircle size={14} className="text-red-500" />)}
            </button>
          </div>
        </form>
      </div>

      {/* Org */}
      <div className="card p-6">
        <h3 className="font-semibold text-gray-800 mb-5 flex items-center gap-2">
          <Building2 size={16} />اطلاعات سازمان
        </h3>
        <form onSubmit={saveOrg} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">نام سازمان</label>
            <input className="input-field" value={org.org_name} onChange={e => setOrg({ ...org, org_name: e.target.value })} />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">آدرس</label>
            <input className="input-field" value={org.org_address} onChange={e => setOrg({ ...org, org_address: e.target.value })} />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">تلفن</label>
              <input className="input-field" value={org.org_phone} onChange={e => setOrg({ ...org, org_phone: e.target.value })} dir="ltr" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">وبسایت</label>
              <input className="input-field" value={org.org_website} onChange={e => setOrg({ ...org, org_website: e.target.value })} dir="ltr" />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">روز بدون فعالیت = تسک راکد</label>
            <input type="number" className="input-field w-24" value={org.stale_task_days}
              onChange={e => setOrg({ ...org, stale_task_days: +e.target.value })} min={1} max={90} />
          </div>
          <button type="submit" disabled={!!saving} className="btn-primary flex items-center gap-2">
            <Save size={15} />{saving === 'org' ? 'در حال ذخیره...' : 'ذخیره'}
          </button>
        </form>
      </div>

      {/* Letterhead — per company */}
      <div className="card p-6">
        <h3 className="font-semibold text-gray-800 mb-2 flex items-center gap-2">
          <FileText size={16} />سربرگ نامه‌ها (بر اساس شرکت)
        </h3>
        <p className="text-sm text-gray-500 mb-5">
          تصاویر سربرگ در خروجی نامه به صورت عرض کامل چاپ می‌شوند. هر شرکت می‌تواند سربرگ مستقل داشته باشد.
        </p>

        {companies.length === 0 ? (
          <div className="text-center py-10 text-gray-400">
            <Building2 size={32} className="mx-auto mb-2 opacity-30" />
            <p className="text-sm">هیچ شرکتی یافت نشد</p>
          </div>
        ) : (
          <>
            {/* Company tabs */}
            <div className="flex gap-2 mb-6 border-b border-gray-200 flex-wrap">
              {companies.map((c, i) => (
                <button
                  key={c.id}
                  onClick={() => setActiveCompanyIdx(i)}
                  className={[
                    'px-4 py-2 text-sm font-medium border-b-2 transition-colors -mb-px',
                    activeCompanyIdx === i
                      ? 'border-primary-600 text-primary-700'
                      : 'border-transparent text-gray-500 hover:text-gray-800'
                  ].join(' ')}
                >
                  {c.name}
                </button>
              ))}
            </div>

            {companies[activeCompanyIdx] && (() => {
              const co = companies[activeCompanyIdx]
              return (
                <div className="space-y-6">
                  <ImageUploadBox
                    label={`سربرگ (هدر) — ${co.name}`}
                    hint="در بالاترین قسمت نامه قرار می‌گیرد"
                    imageData={(co as any).letterhead_header_data ?? null}
                    uploading={lhUploading === `${co.id}_header`}
                    onUpload={f => uploadCompanyLh(co.id, 'header', f)}
                    onDelete={() => deleteCompanyLh(co.id, 'header')}
                  />
                  <ImageUploadBox
                    label={`پاورقی (فوتر) — ${co.name}`}
                    hint="در پایین‌ترین قسمت نامه قرار می‌گیرد"
                    imageData={(co as any).letterhead_footer_data ?? null}
                    uploading={lhUploading === `${co.id}_footer`}
                    onUpload={f => uploadCompanyLh(co.id, 'footer', f)}
                    onDelete={() => deleteCompanyLh(co.id, 'footer')}
                  />
                </div>
              )
            })()}
          </>
        )}
      </div>
    </div>
  )
}
