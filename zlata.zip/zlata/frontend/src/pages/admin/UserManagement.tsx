import { useState, useEffect } from 'react'
import { usersApi } from '@/api/users'
import { authApi } from '@/api/auth'
import { User, Team } from '@/types/common'
import { Avatar } from '@/components/common/Avatar'
import { Modal } from '@/components/common/Modal'
import { Plus, Edit, UserX, Search, Users, ClipboardList, Check, X, Phone, Trash2, Building2 } from 'lucide-react'
import { useAuthStore } from '@/store/authStore'
import toast from 'react-hot-toast'
import clsx from 'clsx'

interface Company { id: string; name: string }

const ROLE_LABELS: Record<string, string> = {
  super_admin: 'مدیر ارشد',
  manager: 'مدیر',
  team_lead: 'سرتیم',
  member: 'عضو',
}

interface RegRequest {
  id: string
  full_name: string
  mobile: string
  status: string
  rejection_reason: string | null
  requested_org_ids: string[]
  created_at: string
  reviewed_at: string | null
}

type Tab = 'users' | 'requests'

export default function UserManagement() {
  const { user: currentUser } = useAuthStore()
  const isSuperAdmin = currentUser?.role === 'super_admin'
  const [tab, setTab] = useState<Tab>('users')

  // ── users tab ──
  const [users, setUsers] = useState<User[]>([])
  const [teams, setTeams] = useState<Team[]>([])
  const [companies, setCompanies] = useState<Company[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [showCreate, setShowCreate] = useState(false)
  const [editUser, setEditUser] = useState<User | null>(null)
  const [form, setForm] = useState({
    email: '', password: '', full_name: '', role: 'member',
    position: '', mobile: '', notification_email: '', team_ids: [] as string[],
    organization_ids: [] as string[],
  })
  const [editOrgIds, setEditOrgIds] = useState<string[]>([])

  // ── requests tab ──
  const [requests, setRequests] = useState<RegRequest[]>([])
  const [reqLoading, setReqLoading] = useState(false)
  const [reqFilter, setReqFilter] = useState<'pending' | 'approved' | 'rejected'>('pending')
  const [rejectModal, setRejectModal] = useState<{ id: string; name: string } | null>(null)
  const [rejectReason, setRejectReason] = useState('')
  const [actionLoading, setActionLoading] = useState<string | null>(null)

  useEffect(() => {
    Promise.all([usersApi.list(), usersApi.listTeams(), authApi.listCompaniesPublic()])
      .then(([uRes, tRes, cRes]) => { setUsers(uRes.data); setTeams(tRes.data); setCompanies(cRes.data) })
      .finally(() => setLoading(false))
  }, [])

  const loadRequests = async (status = reqFilter) => {
    setReqLoading(true)
    try {
      const { data } = await authApi.listRegisterRequests(status)
      setRequests(data as RegRequest[])
    } catch { toast.error('خطا در بارگذاری درخواست‌ها') }
    finally { setReqLoading(false) }
  }

  useEffect(() => {
    if (tab === 'requests') loadRequests(reqFilter)
  }, [tab, reqFilter])

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const { data } = await usersApi.create(form as any)
      // assign to companies
      if (form.organization_ids.length) {
        await usersApi.update(data.id, { organization_ids: form.organization_ids } as any)
        data.organization_ids = form.organization_ids
      }
      setUsers(prev => [data, ...prev])
      toast.success('کاربر ایجاد شد')
      setShowCreate(false)
      setForm({ email: '', password: '', full_name: '', role: 'member', position: '', mobile: '', notification_email: '', team_ids: [], organization_ids: [] })
    } catch (err: any) {
      toast.error(err?.response?.data?.detail || 'خطا در ایجاد کاربر')
    }
  }

  const handleEdit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!editUser) return
    try {
      const { data } = await usersApi.update(editUser.id, {
        full_name: (e.target as any).full_name?.value || editUser.full_name,
        position: (e.target as any).position?.value || editUser.position,
        mobile: (e.target as any).mobile?.value || editUser.mobile,
        role: (e.target as any).role?.value as any || editUser.role,
        organization_ids: editOrgIds,
      })
      setUsers(prev => prev.map(u => u.id === data.id ? data : u))
      toast.success('کاربر ویرایش شد')
      setEditUser(null)
    } catch (err: any) {
      toast.error(err?.response?.data?.detail || 'خطا در ویرایش')
    }
  }

  const handleDeactivate = async (userId: string) => {
    if (!confirm('آیا از غیرفعال‌سازی این کاربر مطمئن هستید؟')) return
    await usersApi.deactivate(userId)
    setUsers(prev => prev.map(u => u.id === userId ? { ...u, is_active: false } : u))
    toast.success('کاربر غیرفعال شد')
  }

  const handlePermanentDelete = async (userId: string, name: string) => {
    if (!confirm(`کاربر "${name}" به طور کامل و دائمی حذف می‌شود. این عملیات قابل بازگشت نیست. ادامه می‌دهید؟`)) return
    try {
      await usersApi.permanentDelete(userId)
      setUsers(prev => prev.filter(u => u.id !== userId))
      toast.success('کاربر حذف شد')
    } catch (err: any) {
      toast.error(err?.response?.data?.detail || 'خطا در حذف کاربر')
    }
  }

  const handleActivate = async (userId: string) => {
    await usersApi.update(userId, { is_active: true } as any)
    setUsers(prev => prev.map(u => u.id === userId ? { ...u, is_active: true } : u))
    toast.success('کاربر فعال شد')
  }

  const handleApprove = async (id: string) => {
    setActionLoading(id)
    try {
      await authApi.approveRegisterRequest(id)
      toast.success('حساب کاربری ایجاد شد')
      loadRequests()
    } catch (err: any) {
      toast.error(err?.response?.data?.detail || 'خطا در تایید')
    } finally { setActionLoading(null) }
  }

  const handleReject = async () => {
    if (!rejectModal) return
    setActionLoading(rejectModal.id)
    try {
      await authApi.rejectRegisterRequest(rejectModal.id, rejectReason)
      toast.success('درخواست رد شد')
      setRejectModal(null)
      setRejectReason('')
      loadRequests()
    } catch (err: any) {
      toast.error(err?.response?.data?.detail || 'خطا در رد درخواست')
    } finally { setActionLoading(null) }
  }

  const filtered = users.filter(u =>
    !search ||
    u.full_name.toLowerCase().includes(search.toLowerCase()) ||
    u.email?.includes(search) ||
    u.mobile?.includes(search)
  )

  if (loading) return (
    <div className="flex items-center justify-center h-64">
      <div className="w-8 h-8 border-4 border-primary-500 border-t-transparent rounded-full animate-spin" />
    </div>
  )

  return (
    <div dir="rtl">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-gray-900">مدیریت کاربران</h1>
        {tab === 'users' && (
          <button onClick={() => setShowCreate(true)} className="btn-primary flex items-center gap-2">
            <Plus size={16} />کاربر جدید
          </button>
        )}
      </div>

      {/* Tabs */}
      <div className="flex gap-1 mb-6 bg-gray-100 p-1 rounded-xl w-fit">
        {([
          { key: 'users', label: 'کاربران', icon: <Users size={15} /> },
          { key: 'requests', label: 'درخواست‌های حساب', icon: <ClipboardList size={15} /> },
        ] as { key: Tab; label: string; icon: React.ReactNode }[]).map(t => (
          <button key={t.key} onClick={() => setTab(t.key)}
            className={clsx(
              'flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all',
              tab === t.key ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'
            )}>
            {t.icon}{t.label}
          </button>
        ))}
      </div>

      {/* ── Users Tab ── */}
      {tab === 'users' && (
        <>
          <div className="relative mb-4 max-w-md">
            <Search size={15} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input value={search} onChange={e => setSearch(e.target.value)}
              placeholder="جستجو بر اساس نام، ایمیل یا موبایل..." className="input-field pr-9" />
          </div>

          <div className="card overflow-hidden">
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  {['کاربر', 'موبایل', 'شرکت', 'نقش', 'سمت', 'وضعیت', 'عملیات'].map(h => (
                    <th key={h} className="text-right text-xs font-semibold text-gray-500 px-4 py-3">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {filtered.map(u => (
                  <tr key={u.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <Avatar name={u.full_name} size="sm" />
                        <div>
                          <p className="font-medium text-sm text-gray-800">{u.full_name}</p>
                          <p className="text-xs text-gray-400">{u.email || '—'}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-sm text-gray-600" dir="ltr">
                      {u.mobile ? (
                        <span className="flex items-center gap-1"><Phone size={12} className="text-gray-400" />{u.mobile}</span>
                      ) : '—'}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex flex-wrap gap-1">
                        {(u.organization_ids || []).map(oid => {
                          const c = companies.find(c => c.id === oid)
                          return c ? (
                            <span key={oid} className="text-xs bg-blue-50 text-blue-700 px-2 py-0.5 rounded-full">{c.name}</span>
                          ) : null
                        })}
                        {(!u.organization_ids || u.organization_ids.length === 0) && <span className="text-xs text-gray-400">—</span>}
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <span className="text-xs bg-primary-50 text-primary-700 px-2 py-0.5 rounded-full">
                        {ROLE_LABELS[u.role]}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-sm text-gray-600">{u.position || '—'}</td>
                    <td className="px-4 py-3">
                      <span className={clsx('text-xs px-2 py-0.5 rounded-full font-medium',
                        u.is_active ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500')}>
                        {u.is_active ? 'فعال' : 'غیرفعال'}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1">
                        <button onClick={() => { setEditUser(u); setEditOrgIds(u.organization_ids || []) }}
                          className="p-1.5 hover:bg-gray-100 rounded-lg text-gray-500" title="ویرایش">
                          <Edit size={14} />
                        </button>
                        {u.is_active
                          ? <button onClick={() => handleDeactivate(u.id)}
                              className="p-1.5 hover:bg-red-50 text-red-500 rounded-lg" title="غیرفعال‌سازی">
                              <UserX size={14} />
                            </button>
                          : <button onClick={() => handleActivate(u.id)}
                              className="p-1.5 hover:bg-green-50 text-green-600 rounded-lg" title="فعال‌سازی">
                              <Check size={14} />
                            </button>
                        }
                        {isSuperAdmin && u.id !== currentUser?.id && (
                          <button onClick={() => handlePermanentDelete(u.id, u.full_name)}
                            className="p-1.5 hover:bg-red-100 text-red-700 rounded-lg" title="حذف دائمی">
                            <Trash2 size={14} />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
                {filtered.length === 0 && (
                  <tr><td colSpan={6} className="text-center py-10 text-gray-400 text-sm">کاربری یافت نشد</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </>
      )}

      {/* ── Requests Tab ── */}
      {tab === 'requests' && (
        <>
          <div className="flex gap-2 mb-4">
            {(['pending', 'approved', 'rejected'] as const).map(s => (
              <button key={s} onClick={() => setReqFilter(s)}
                className={clsx('px-4 py-1.5 rounded-lg text-sm font-medium transition-colors', reqFilter === s
                  ? s === 'pending' ? 'bg-amber-100 text-amber-700'
                    : s === 'approved' ? 'bg-green-100 text-green-700'
                    : 'bg-red-100 text-red-700'
                  : 'bg-gray-100 text-gray-500 hover:bg-gray-200')}>
                {s === 'pending' ? 'در انتظار' : s === 'approved' ? 'تایید شده' : 'رد شده'}
              </button>
            ))}
          </div>

          {reqLoading ? (
            <div className="flex justify-center py-12">
              <div className="w-7 h-7 border-4 border-primary-500 border-t-transparent rounded-full animate-spin" />
            </div>
          ) : (
            <div className="card overflow-hidden">
              <table className="w-full">
                <thead className="bg-gray-50 border-b border-gray-200">
                  <tr>
                    {['نام', 'موبایل', 'تاریخ درخواست', 'شرکت', 'وضعیت', ...(reqFilter === 'pending' ? ['عملیات'] : [])].map(h => (
                      <th key={h} className="text-right text-xs font-semibold text-gray-500 px-4 py-3">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {requests.map(r => (
                    <tr key={r.id} className="hover:bg-gray-50">
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <Avatar name={r.full_name} size="sm" />
                          <span className="text-sm font-medium text-gray-800">{r.full_name}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-600" dir="ltr">
                        <span className="flex items-center gap-1"><Phone size={12} className="text-gray-400" />{r.mobile}</span>
                      </td>
                      <td className="px-4 py-3 text-xs text-gray-500">
                        {new Date(r.created_at).toLocaleDateString('fa-IR')}
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex flex-wrap gap-1">
                          {(r.requested_org_ids || []).map(oid => {
                            const c = companies.find(c => c.id === oid)
                            return c ? (
                              <span key={oid} className="text-xs bg-blue-50 text-blue-700 px-2 py-0.5 rounded-full">{c.name}</span>
                            ) : null
                          })}
                          {(!r.requested_org_ids || r.requested_org_ids.length === 0) && <span className="text-xs text-gray-400">—</span>}
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <span className={clsx('text-xs px-2 py-1 rounded-full font-medium',
                          r.status === 'pending' ? 'bg-amber-100 text-amber-700'
                          : r.status === 'approved' ? 'bg-green-100 text-green-700'
                          : 'bg-red-100 text-red-700')}>
                          {r.status === 'pending' ? 'در انتظار' : r.status === 'approved' ? 'تایید شده' : 'رد شده'}
                        </span>
                        {r.rejection_reason && (
                          <p className="text-xs text-gray-400 mt-1">دلیل: {r.rejection_reason}</p>
                        )}
                      </td>
                      {reqFilter === 'pending' && (
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-2">
                            <button onClick={() => handleApprove(r.id)}
                              disabled={actionLoading === r.id}
                              className="flex items-center gap-1 px-3 py-1.5 bg-green-600 text-white text-xs rounded-lg hover:bg-green-700 disabled:opacity-50">
                              <Check size={12} /> تایید
                            </button>
                            <button onClick={() => { setRejectModal({ id: r.id, name: r.full_name }); setRejectReason('') }}
                              disabled={actionLoading === r.id}
                              className="flex items-center gap-1 px-3 py-1.5 bg-red-50 text-red-600 border border-red-200 text-xs rounded-lg hover:bg-red-100 disabled:opacity-50">
                              <X size={12} /> رد
                            </button>
                          </div>
                        </td>
                      )}
                    </tr>
                  ))}
                  {requests.length === 0 && (
                    <tr>
                      <td colSpan={5} className="text-center py-10 text-gray-400 text-sm">
                        {reqFilter === 'pending' ? 'هیچ درخواست جدیدی وجود ندارد' : 'موردی یافت نشد'}
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          )}
        </>
      )}

      {/* ── Create User Modal ── */}
      <Modal isOpen={showCreate} onClose={() => setShowCreate(false)} title="ایجاد کاربر جدید" size="lg">
        <form onSubmit={handleCreate} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">نام کامل *</label>
              <input className="input-field" value={form.full_name} onChange={e => setForm({...form, full_name: e.target.value})} required />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">ایمیل *</label>
              <input type="email" className="input-field" value={form.email} onChange={e => setForm({...form, email: e.target.value})} required dir="ltr" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">رمز عبور *</label>
              <input type="password" className="input-field" value={form.password} onChange={e => setForm({...form, password: e.target.value})} required dir="ltr" minLength={8} />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">نقش</label>
              <select className="input-field" value={form.role} onChange={e => setForm({...form, role: e.target.value})}>
                {Object.entries(ROLE_LABELS).map(([k,v]) => <option key={k} value={k}>{v}</option>)}
              </select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">سمت</label>
              <input className="input-field" value={form.position} onChange={e => setForm({...form, position: e.target.value})} />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">موبایل *</label>
              <input className="input-field" value={form.mobile} onChange={e => setForm({...form, mobile: e.target.value})} dir="ltr" placeholder="09xxxxxxxxx" required />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">ایمیل اعلان</label>
            <input type="email" className="input-field" value={form.notification_email} onChange={e => setForm({...form, notification_email: e.target.value})} dir="ltr" />
          </div>
          {companies.length > 0 && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2 flex items-center gap-1.5">
                <Building2 size={14} className="text-gray-400" /> شرکت(ها)
              </label>
              <div className="flex gap-4 flex-wrap">
                {companies.map(c => (
                  <label key={c.id} className="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox"
                      checked={form.organization_ids.includes(c.id)}
                      onChange={() => setForm(f => ({
                        ...f,
                        organization_ids: f.organization_ids.includes(c.id)
                          ? f.organization_ids.filter(x => x !== c.id)
                          : [...f.organization_ids, c.id]
                      }))}
                      className="w-4 h-4 text-primary-600 rounded" />
                    <span className="text-sm text-gray-700">{c.name}</span>
                  </label>
                ))}
              </div>
            </div>
          )}
          <div className="flex gap-3 pt-2">
            <button type="submit" className="btn-primary flex-1">ایجاد کاربر</button>
            <button type="button" onClick={() => setShowCreate(false)} className="btn-secondary flex-1">انصراف</button>
          </div>
        </form>
      </Modal>

      {/* ── Edit User Modal ── */}
      <Modal isOpen={!!editUser} onClose={() => setEditUser(null)} title="ویرایش کاربر" size="md">
        {editUser && (
          <form onSubmit={handleEdit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">نام کامل</label>
              <input name="full_name" className="input-field" defaultValue={editUser.full_name} required />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">سمت</label>
                <input name="position" className="input-field" defaultValue={editUser.position || ''} />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">موبایل</label>
                <input name="mobile" className="input-field" defaultValue={editUser.mobile || ''} dir="ltr" />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">نقش</label>
              <select name="role" className="input-field" defaultValue={editUser.role}>
                {Object.entries(ROLE_LABELS).map(([k,v]) => <option key={k} value={k}>{v}</option>)}
              </select>
            </div>
            {companies.length > 0 && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2 flex items-center gap-1.5">
                  <Building2 size={14} className="text-gray-400" /> شرکت(ها)
                </label>
                <div className="flex gap-4 flex-wrap">
                  {companies.map(c => (
                    <label key={c.id} className="flex items-center gap-2 cursor-pointer">
                      <input type="checkbox"
                        checked={editOrgIds.includes(c.id)}
                        onChange={() => setEditOrgIds(prev =>
                          prev.includes(c.id) ? prev.filter(x => x !== c.id) : [...prev, c.id]
                        )}
                        className="w-4 h-4 text-primary-600 rounded" />
                      <span className="text-sm text-gray-700">{c.name}</span>
                    </label>
                  ))}
                </div>
              </div>
            )}
            <div className="flex gap-3 pt-2">
              <button type="submit" className="btn-primary flex-1">ذخیره</button>
              <button type="button" onClick={() => setEditUser(null)} className="btn-secondary flex-1">انصراف</button>
            </div>
          </form>
        )}
      </Modal>

      {/* ── Reject Reason Modal ── */}
      <Modal isOpen={!!rejectModal} onClose={() => setRejectModal(null)} title="رد درخواست" size="sm">
        {rejectModal && (
          <div className="space-y-4">
            <p className="text-sm text-gray-600">درخواست <strong>{rejectModal.name}</strong> رد می‌شود.</p>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">دلیل رد (اختیاری)</label>
              <textarea value={rejectReason} onChange={e => setRejectReason(e.target.value)} rows={3}
                placeholder="دلیل رد درخواست را بنویسید..."
                className="input-field resize-none w-full" />
            </div>
            <div className="flex gap-3">
              <button onClick={handleReject} disabled={!!actionLoading}
                className="flex-1 bg-red-600 text-white py-2.5 rounded-lg text-sm hover:bg-red-700 disabled:opacity-50">
                تایید رد
              </button>
              <button onClick={() => setRejectModal(null)} className="flex-1 btn-secondary">انصراف</button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  )
}
