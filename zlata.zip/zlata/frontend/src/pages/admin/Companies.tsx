import { useState, useEffect, useRef } from 'react'
import { companiesApi } from '@/api/companies'
import { usersApi } from '@/api/users'
import { Company } from '@/types/common'
import { Modal } from '@/components/common/Modal'
import { Plus, Edit2, Users, Building2, Upload, Image } from 'lucide-react'
import toast from 'react-hot-toast'
import clsx from 'clsx'

interface CompanyUser {
  id: string
  full_name: string
  email: string
  role: string
  position?: string
  is_active: boolean
}

function CompanyForm({
  initial,
  onSubmit,
  loading,
}: {
  initial?: Partial<Company>
  onSubmit: (data: Partial<Company>) => void
  loading: boolean
}) {
  const [name, setName] = useState(initial?.name ?? '')
  const [official_name, setOfficialName] = useState(initial?.official_name ?? '')
  const [address, setAddress] = useState(initial?.address ?? '')
  const [phone, setPhone] = useState(initial?.phone ?? '')
  const [website, setWebsite] = useState(initial?.website ?? '')

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!name.trim()) { toast.error('نام شرکت الزامی است'); return }
    onSubmit({ name, official_name, address, phone, website })
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">نام شرکت *</label>
        <input className="input-field" value={name} onChange={e => setName(e.target.value)} required />
      </div>
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">نام رسمی</label>
        <input className="input-field" value={official_name} onChange={e => setOfficialName(e.target.value)} />
      </div>
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">آدرس</label>
        <input className="input-field" value={address} onChange={e => setAddress(e.target.value)} />
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">تلفن</label>
          <input className="input-field" value={phone} onChange={e => setPhone(e.target.value)} dir="ltr" />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">وب‌سایت</label>
          <input className="input-field" value={website} onChange={e => setWebsite(e.target.value)} dir="ltr" />
        </div>
      </div>
      <div className="flex gap-3 pt-2">
        <button type="submit" disabled={loading} className="btn-primary flex-1">
          {loading ? 'در حال ذخیره...' : 'ذخیره'}
        </button>
      </div>
    </form>
  )
}

export default function Companies() {
  const [companies, setCompanies] = useState<Company[]>([])
  const [selectedCompany, setSelectedCompany] = useState<Company | null>(null)
  const [companyUsers, setCompanyUsers] = useState<CompanyUser[]>([])
  const [allUsers, setAllUsers] = useState<any[]>([])
  const [showCreate, setShowCreate] = useState(false)
  const [showEdit, setShowEdit] = useState(false)
  const [showUsers, setShowUsers] = useState(false)
  const [showLetterhead, setShowLetterhead] = useState(false)
  const [formLoading, setFormLoading] = useState(false)
  const [loadingUsers, setLoadingUsers] = useState(false)
  const [addUserId, setAddUserId] = useState('')
  const [uploadingHeader, setUploadingHeader] = useState(false)
  const [uploadingFooter, setUploadingFooter] = useState(false)
  const headerInputRef = useRef<HTMLInputElement>(null)
  const footerInputRef = useRef<HTMLInputElement>(null)

  const load = () => {
    companiesApi.list().then(r => setCompanies(r.data)).catch(() => toast.error('خطا در بارگذاری شرکت‌ها'))
  }

  useEffect(() => {
    load()
    usersApi.list().then(r => setAllUsers(r.data)).catch(() => {})
  }, [])

  const loadCompanyUsers = (company: Company) => {
    setLoadingUsers(true)
    companiesApi.getUsers(company.id)
      .then(r => setCompanyUsers(r.data))
      .catch(() => toast.error('خطا در بارگذاری کاربران'))
      .finally(() => setLoadingUsers(false))
  }

  const handleCreate = async (data: Partial<Company>) => {
    setFormLoading(true)
    try {
      await companiesApi.create(data)
      toast.success('شرکت ایجاد شد')
      setShowCreate(false)
      load()
    } catch {
      toast.error('خطا در ایجاد شرکت')
    } finally {
      setFormLoading(false)
    }
  }

  const handleUpdate = async (data: Partial<Company>) => {
    if (!selectedCompany) return
    setFormLoading(true)
    try {
      await companiesApi.update(selectedCompany.id, data)
      toast.success('شرکت ویرایش شد')
      setShowEdit(false)
      load()
    } catch {
      toast.error('خطا در ویرایش شرکت')
    } finally {
      setFormLoading(false)
    }
  }

  const handleAddUser = async () => {
    if (!selectedCompany || !addUserId) return
    try {
      await companiesApi.addUser(selectedCompany.id, addUserId)
      toast.success('کاربر اضافه شد')
      setAddUserId('')
      loadCompanyUsers(selectedCompany)
    } catch {
      toast.error('خطا در افزودن کاربر')
    }
  }

  const handleRemoveUser = async (userId: string) => {
    if (!selectedCompany) return
    try {
      await companiesApi.removeUser(selectedCompany.id, userId)
      toast.success('کاربر حذف شد')
      loadCompanyUsers(selectedCompany)
    } catch {
      toast.error('خطا در حذف کاربر')
    }
  }

  const usersNotInCompany = allUsers.filter(u => !companyUsers.find(cu => cu.id === u.id))

  const handleUploadHeader = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!selectedCompany || !e.target.files?.[0]) return
    setUploadingHeader(true)
    try {
      await companiesApi.uploadLetterheadHeader(selectedCompany.id, e.target.files[0])
      toast.success('هدر سربرگ آپلود شد')
      load()
      // Update selectedCompany from fresh list
      companiesApi.list().then(r => {
        const updated = r.data.find(c => c.id === selectedCompany.id)
        if (updated) setSelectedCompany(updated)
      })
    } catch {
      toast.error('خطا در آپلود هدر')
    } finally {
      setUploadingHeader(false)
      if (headerInputRef.current) headerInputRef.current.value = ''
    }
  }

  const handleUploadFooter = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!selectedCompany || !e.target.files?.[0]) return
    setUploadingFooter(true)
    try {
      await companiesApi.uploadLetterheadFooter(selectedCompany.id, e.target.files[0])
      toast.success('فوتر سربرگ آپلود شد')
      load()
      companiesApi.list().then(r => {
        const updated = r.data.find(c => c.id === selectedCompany.id)
        if (updated) setSelectedCompany(updated)
      })
    } catch {
      toast.error('خطا در آپلود فوتر')
    } finally {
      setUploadingFooter(false)
      if (footerInputRef.current) footerInputRef.current.value = ''
    }
  }

  return (
    <div dir="rtl">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">مدیریت شرکت‌ها</h1>
          <p className="text-sm text-gray-500 mt-1">مدیریت شرکت‌های سیستم و اعضای هر شرکت</p>
        </div>
        <button onClick={() => setShowCreate(true)} className="btn-primary flex items-center gap-2">
          <Plus size={16} />
          شرکت جدید
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {companies.map(company => (
          <div key={company.id} className="card p-5">
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-primary-100 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Building2 size={20} className="text-primary-600" />
                </div>
                <div>
                  <h3 className="font-bold text-gray-900">{company.name}</h3>
                  {company.official_name && (
                    <p className="text-xs text-gray-500">{company.official_name}</p>
                  )}
                </div>
              </div>
            </div>

            {company.address && (
              <p className="text-xs text-gray-500 mb-1">{company.address}</p>
            )}
            {company.phone && (
              <p className="text-xs text-gray-500 mb-3" dir="ltr">{company.phone}</p>
            )}

            <div className="flex gap-2 pt-3 border-t border-gray-100 flex-wrap">
              <button
                onClick={() => {
                  setSelectedCompany(company)
                  setShowEdit(true)
                }}
                className="flex items-center gap-1.5 text-xs text-gray-600 hover:text-primary-600 transition-colors"
              >
                <Edit2 size={13} />
                ویرایش
              </button>
              <button
                onClick={() => {
                  setSelectedCompany(company)
                  setShowUsers(true)
                  loadCompanyUsers(company)
                }}
                className="flex items-center gap-1.5 text-xs text-gray-600 hover:text-primary-600 transition-colors mr-3"
              >
                <Users size={13} />
                اعضا
              </button>
              <button
                onClick={() => {
                  setSelectedCompany(company)
                  setShowLetterhead(true)
                }}
                className="flex items-center gap-1.5 text-xs text-gray-600 hover:text-primary-600 transition-colors mr-3"
              >
                <Image size={13} />
                سربرگ
              </button>
            </div>
          </div>
        ))}

        {companies.length === 0 && (
          <div className="col-span-3 text-center py-12 text-gray-400">
            <Building2 size={40} className="mx-auto mb-3 opacity-30" />
            <p>هیچ شرکتی ثبت نشده است</p>
          </div>
        )}
      </div>

      {/* Create Modal */}
      <Modal isOpen={showCreate} onClose={() => setShowCreate(false)} title="ایجاد شرکت جدید">
        <CompanyForm onSubmit={handleCreate} loading={formLoading} />
      </Modal>

      {/* Edit Modal */}
      <Modal isOpen={showEdit} onClose={() => setShowEdit(false)} title="ویرایش شرکت">
        {selectedCompany && (
          <CompanyForm initial={selectedCompany} onSubmit={handleUpdate} loading={formLoading} />
        )}
      </Modal>

      {/* Letterhead Modal */}
      <Modal
        isOpen={showLetterhead}
        onClose={() => setShowLetterhead(false)}
        title={`سربرگ نامه — ${selectedCompany?.name || ''}`}
        size="lg"
      >
        <div className="space-y-6">
          {/* Header upload */}
          <div>
            <h3 className="text-sm font-semibold text-gray-700 mb-2">تصویر هدر (سربرگ بالا)</h3>
            {selectedCompany?.letterhead_header_data && (
              <div className="mb-3 border border-gray-200 rounded-lg overflow-hidden">
                <img src={selectedCompany.letterhead_header_data} alt="header preview" className="w-full h-auto max-h-32 object-cover" />
              </div>
            )}
            <input
              ref={headerInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={handleUploadHeader}
            />
            <button
              onClick={() => headerInputRef.current?.click()}
              disabled={uploadingHeader}
              className="flex items-center gap-2 border border-gray-300 bg-white text-gray-700 px-4 py-2 rounded-lg text-sm hover:bg-gray-50 disabled:opacity-50"
            >
              <Upload size={14} />
              {uploadingHeader ? 'در حال آپلود...' : 'آپلود سربرگ (هدر)'}
            </button>
          </div>

          {/* Footer upload */}
          <div>
            <h3 className="text-sm font-semibold text-gray-700 mb-2">تصویر فوتر (پاورقی پایین)</h3>
            {selectedCompany?.letterhead_footer_data && (
              <div className="mb-3 border border-gray-200 rounded-lg overflow-hidden">
                <img src={selectedCompany.letterhead_footer_data} alt="footer preview" className="w-full h-auto max-h-32 object-cover" />
              </div>
            )}
            <input
              ref={footerInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={handleUploadFooter}
            />
            <button
              onClick={() => footerInputRef.current?.click()}
              disabled={uploadingFooter}
              className="flex items-center gap-2 border border-gray-300 bg-white text-gray-700 px-4 py-2 rounded-lg text-sm hover:bg-gray-50 disabled:opacity-50"
            >
              <Upload size={14} />
              {uploadingFooter ? 'در حال آپلود...' : 'آپلود پاورقی (فوتر)'}
            </button>
          </div>

          <p className="text-xs text-gray-400">تصاویر به صورت عرض کامل در سربرگ نامه نمایش داده می‌شوند</p>
        </div>
      </Modal>

      {/* Company Users Modal */}
      <Modal
        isOpen={showUsers}
        onClose={() => setShowUsers(false)}
        title={`اعضای ${selectedCompany?.name || ''}`}
        size="lg"
      >
        <div className="space-y-4">
          {/* Add user */}
          <div className="flex gap-2">
            <select
              className="input-field flex-1"
              value={addUserId}
              onChange={e => setAddUserId(e.target.value)}
            >
              <option value="">انتخاب کاربر برای افزودن</option>
              {usersNotInCompany.map(u => (
                <option key={u.id} value={u.id}>{u.full_name} ({u.email})</option>
              ))}
            </select>
            <button
              onClick={handleAddUser}
              disabled={!addUserId}
              className="btn-primary px-4"
            >
              افزودن
            </button>
          </div>

          {/* User list */}
          {loadingUsers ? (
            <div className="flex justify-center py-8">
              <div className="w-6 h-6 border-4 border-primary-500 border-t-transparent rounded-full animate-spin" />
            </div>
          ) : companyUsers.length === 0 ? (
            <p className="text-center text-gray-400 py-6">این شرکت عضوی ندارد</p>
          ) : (
            <div className="divide-y divide-gray-100">
              {companyUsers.map(u => (
                <div key={u.id} className="flex items-center justify-between py-3">
                  <div>
                    <p className="font-medium text-gray-800 text-sm">{u.full_name}</p>
                    <p className="text-xs text-gray-500">{u.email}</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className={clsx(
                      'text-xs px-2 py-0.5 rounded-full',
                      u.is_active ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
                    )}>
                      {u.is_active ? 'فعال' : 'غیرفعال'}
                    </span>
                    <button
                      onClick={() => handleRemoveUser(u.id)}
                      className="text-xs text-red-500 hover:text-red-700 transition-colors"
                    >
                      حذف
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </Modal>
    </div>
  )
}
