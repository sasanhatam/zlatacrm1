import { useState, useEffect, useCallback } from 'react'
import { attendanceApi, AttendanceRecord } from '@/api/attendance'
import { ClipboardList, Download, RefreshCw } from 'lucide-react'
import toast from 'react-hot-toast'

function formatMinutes(min: number | null): string {
  if (!min && min !== 0) return '—'
  const h = Math.floor(min / 60)
  const m = min % 60
  if (h === 0) return `${m} دقیقه`
  return `${h}h ${m > 0 ? `${m}m` : ''}`
}

function formatTime(iso: string | null): string {
  if (!iso) return '—'
  return new Date(iso).toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })
}

export default function AttendanceReport() {
  const [items, setItems] = useState<AttendanceRecord[]>([])
  const [summary, setSummary] = useState<any[]>([])
  const [users, setUsers] = useState<{ id: string; full_name: string; mobile: string }[]>([])
  const [loading, setLoading] = useState(false)
  const [filterUserId, setFilterUserId] = useState('')
  const [fromDate, setFromDate] = useState(() => {
    const d = new Date()
    d.setDate(1)
    return d.toISOString().slice(0, 10)
  })
  const [toDate, setToDate] = useState(() => new Date().toISOString().slice(0, 10))

  useEffect(() => {
    attendanceApi.usersList().then(r => setUsers(r.data)).catch(() => {})
  }, [])

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const params: Record<string, string> = {}
      if (fromDate) params.from_date = fromDate
      if (toDate) params.to_date = toDate
      if (filterUserId) params.user_id = filterUserId
      const r = await attendanceApi.report(params)
      setItems(r.data.items)
      setSummary(r.data.summary)
    } catch {
      toast.error('خطا در بارگذاری گزارش')
    } finally {
      setLoading(false)
    }
  }, [fromDate, toDate, filterUserId])

  useEffect(() => { load() }, [fromDate, toDate, filterUserId])

  const exportCsv = () => {
    const rows = [
      ['تاریخ', 'کاربر', 'موبایل', 'ورود', 'خروج', 'مدت (دقیقه)'].join(','),
      ...items.map(r => [
        r.jalali_date, r.user_name, r.user_mobile || '',
        r.clock_in ? new Date(r.clock_in).toLocaleTimeString('fa-IR') : '',
        r.clock_out ? new Date(r.clock_out).toLocaleTimeString('fa-IR') : '',
        r.duration_minutes ?? '',
      ].join(','))
    ].join('\n')
    const blob = new Blob(['﻿' + rows], { type: 'text/csv;charset=utf-8' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `attendance_${fromDate}_${toDate}.csv`
    a.click()
    URL.revokeObjectURL(url)
  }

  return (
    <div className="p-4 md:p-6 space-y-5" dir="rtl">
      <div className="flex items-center gap-3 flex-wrap">
        <ClipboardList size={22} className="text-primary-600" />
        <h1 className="text-xl font-bold text-gray-900">گزارش حضور و غیاب</h1>
        <div className="mr-auto flex gap-2">
          <button onClick={load} className="p-2 hover:bg-gray-100 rounded-lg" title="بروزرسانی">
            <RefreshCw size={16} className={loading ? 'animate-spin text-primary-600' : 'text-gray-500'} />
          </button>
          <button onClick={exportCsv} className="flex items-center gap-2 btn-secondary text-sm px-3 py-2">
            <Download size={15} />
            خروجی CSV
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white border border-gray-200 rounded-xl p-4 flex flex-wrap gap-4 items-end">
        <div>
          <label className="block text-xs text-gray-500 mb-1">از تاریخ</label>
          <input type="date" value={fromDate} onChange={e => setFromDate(e.target.value)}
            className="input-field text-sm" dir="ltr" />
        </div>
        <div>
          <label className="block text-xs text-gray-500 mb-1">تا تاریخ</label>
          <input type="date" value={toDate} onChange={e => setToDate(e.target.value)}
            className="input-field text-sm" dir="ltr" />
        </div>
        <div className="flex-1 min-w-[180px]">
          <label className="block text-xs text-gray-500 mb-1">کاربر</label>
          <select value={filterUserId} onChange={e => setFilterUserId(e.target.value)}
            className="input-field text-sm w-full">
            <option value="">همه کاربران</option>
            {users.map(u => (
              <option key={u.id} value={u.id}>{u.full_name} ({u.mobile})</option>
            ))}
          </select>
        </div>
      </div>

      {/* Summary cards */}
      {summary.length > 0 && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {summary.map(s => (
            <div key={s.user_id} className="bg-white border border-gray-200 rounded-xl p-4">
              <div className="font-bold text-gray-900 mb-1">{s.user_name}</div>
              <div className="text-xs text-gray-400 font-mono mb-3">{s.user_mobile}</div>
              <div className="flex gap-4 text-sm">
                <div>
                  <div className="text-gray-500">روزهای حاضر</div>
                  <div className="text-lg font-bold text-primary-700">{s.days_present.toLocaleString('fa-IR')}</div>
                </div>
                <div>
                  <div className="text-gray-500">مجموع کار</div>
                  <div className="text-lg font-bold text-green-700">{formatMinutes(s.total_minutes)}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Detail table */}
      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="text-right px-4 py-3 text-gray-600 font-medium">تاریخ</th>
                <th className="text-right px-4 py-3 text-gray-600 font-medium">کاربر</th>
                <th className="text-right px-4 py-3 text-gray-600 font-medium">ورود</th>
                <th className="text-right px-4 py-3 text-gray-600 font-medium">خروج</th>
                <th className="text-right px-4 py-3 text-gray-600 font-medium">مدت کار</th>
                <th className="text-right px-4 py-3 text-gray-600 font-medium">وضعیت</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {loading && (
                <tr><td colSpan={6} className="py-10 text-center">
                  <div className="w-6 h-6 border-2 border-primary-500 border-t-transparent rounded-full animate-spin mx-auto" />
                </td></tr>
              )}
              {!loading && items.length === 0 && (
                <tr><td colSpan={6} className="py-10 text-center text-gray-400">رکوردی یافت نشد</td></tr>
              )}
              {!loading && items.map(r => (
                <tr key={r.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-4 py-2.5 text-gray-700 font-mono text-xs whitespace-nowrap">{r.jalali_date}</td>
                  <td className="px-4 py-2.5">
                    <div className="font-medium text-gray-900">{r.user_name}</div>
                    {r.user_mobile && <div className="text-xs text-gray-400 font-mono">{r.user_mobile}</div>}
                  </td>
                  <td className="px-4 py-2.5 font-mono text-gray-700">{formatTime(r.clock_in)}</td>
                  <td className="px-4 py-2.5 font-mono text-gray-700">{formatTime(r.clock_out)}</td>
                  <td className="px-4 py-2.5 font-medium text-primary-700">{formatMinutes(r.duration_minutes)}</td>
                  <td className="px-4 py-2.5">
                    {r.is_active
                      ? <span className="inline-flex items-center gap-1 text-xs text-green-700 bg-green-100 px-2 py-0.5 rounded-full">
                          <span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse" />فعال
                        </span>
                      : <span className="text-xs text-gray-400">تمام شد</span>
                    }
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
