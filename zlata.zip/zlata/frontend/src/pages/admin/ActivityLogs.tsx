import { useState, useEffect, useCallback } from 'react'
import { activityLogsApi, ActivityLog, ActivityLogUser } from '@/api/activityLogs'
import { Activity, Search, ChevronRight, ChevronLeft, RefreshCw, User } from 'lucide-react'
import toast from 'react-hot-toast'

const ACTION_LABELS: Record<string, string> = {
  login: 'ورود',
  logout: 'خروج',
  change_password: 'تغییر رمز',
  register_request_submit: 'ارسال درخواست ثبت‌نام',
  register_request_approve: 'تأیید ثبت‌نام',
  register_request_reject: 'رد ثبت‌نام',
  user_create: 'ایجاد کاربر',
  user_update: 'ویرایش کاربر',
  user_deactivate: 'غیرفعال کاربر',
  user_delete_permanent: 'حذف کاربر',
  task_create: 'ایجاد تسک',
  task_update: 'ویرایش تسک',
  task_delete: 'حذف تسک',
  letter_create: 'ایجاد نامه',
  letter_submit_approval: 'ارسال برای تأیید',
  letter_approve: 'تأیید نامه',
  letter_reject: 'رد نامه',
  letter_send: 'ارسال نامه',
  letter_refer: 'ارجاع نامه',
}

const ACTION_COLORS: Record<string, string> = {
  login: 'bg-green-100 text-green-800',
  logout: 'bg-gray-100 text-gray-700',
  change_password: 'bg-yellow-100 text-yellow-800',
  register_request_submit: 'bg-blue-100 text-blue-800',
  register_request_approve: 'bg-green-100 text-green-800',
  register_request_reject: 'bg-red-100 text-red-800',
  user_create: 'bg-blue-100 text-blue-800',
  user_update: 'bg-amber-100 text-amber-800',
  user_deactivate: 'bg-orange-100 text-orange-800',
  user_delete_permanent: 'bg-red-100 text-red-800',
  task_create: 'bg-indigo-100 text-indigo-800',
  task_update: 'bg-indigo-50 text-indigo-700',
  task_delete: 'bg-red-100 text-red-800',
  letter_create: 'bg-purple-100 text-purple-800',
  letter_submit_approval: 'bg-purple-100 text-purple-800',
  letter_approve: 'bg-green-100 text-green-800',
  letter_reject: 'bg-red-100 text-red-800',
  letter_send: 'bg-green-100 text-green-800',
  letter_refer: 'bg-cyan-100 text-cyan-800',
}

const RESOURCE_TYPE_LABELS: Record<string, string> = {
  auth: 'احراز هویت',
  user: 'کاربر',
  task: 'تسک',
  letter: 'نامه',
  registration: 'ثبت‌نام',
}

export default function ActivityLogs() {
  const [logs, setLogs] = useState<ActivityLog[]>([])
  const [total, setTotal] = useState(0)
  const [page, setPage] = useState(1)
  const [loading, setLoading] = useState(false)
  const [search, setSearch] = useState('')
  const [filterAction, setFilterAction] = useState('')
  const [filterType, setFilterType] = useState('')
  const [filterUserId, setFilterUserId] = useState('')
  const [fromDate, setFromDate] = useState('')
  const [toDate, setToDate] = useState('')
  const [users, setUsers] = useState<ActivityLogUser[]>([])
  const limit = 50

  useEffect(() => {
    activityLogsApi.listUsers().then(r => setUsers(r.data)).catch(() => {})
  }, [])

  const load = useCallback(async (p = page) => {
    setLoading(true)
    try {
      const params: Record<string, string | number> = { page: p, limit }
      if (filterAction) params.action = filterAction
      if (filterType) params.resource_type = filterType
      if (filterUserId) params.user_id = filterUserId
      if (fromDate) params.from_date = fromDate
      if (toDate) params.to_date = toDate
      const r = await activityLogsApi.list(params)
      setLogs(r.data.items)
      setTotal(r.data.total)
    } catch {
      toast.error('خطا در بارگذاری لاگ‌ها')
    } finally {
      setLoading(false)
    }
  }, [page, filterAction, filterType, filterUserId, fromDate, toDate])

  useEffect(() => { load(1); setPage(1) }, [filterAction, filterType, filterUserId, fromDate, toDate])
  useEffect(() => { load(page) }, [page])

  const totalPages = Math.ceil(total / limit)

  const filtered = search
    ? logs.filter(l =>
        l.user_name.includes(search) ||
        l.user_mobile.includes(search) ||
        l.resource_title.includes(search) ||
        (ACTION_LABELS[l.action] || l.action).includes(search)
      )
    : logs

  const selectedUser = users.find(u => u.id === filterUserId)

  return (
    <div className="p-4 md:p-6 space-y-4" dir="rtl">
      <div className="flex items-center gap-3 flex-wrap">
        <Activity size={22} className="text-primary-600" />
        <h1 className="text-xl font-bold text-gray-900">لاگ فعالیت‌ها</h1>
        {selectedUser && (
          <span className="inline-flex items-center gap-1.5 bg-primary-100 text-primary-700 text-xs px-2.5 py-1 rounded-full font-medium">
            <User size={12} />
            {selectedUser.full_name}
          </span>
        )}
        <span className="text-sm text-gray-500 mr-auto">مجموع: {total.toLocaleString('fa-IR')}</span>
        <button onClick={() => load(page)} className="p-2 hover:bg-gray-100 rounded-lg" title="بروزرسانی">
          <RefreshCw size={16} className={loading ? 'animate-spin text-primary-600' : 'text-gray-500'} />
        </button>
      </div>

      {/* Filters */}
      <div className="bg-white border border-gray-200 rounded-xl p-4 space-y-3">
        <div className="flex flex-wrap gap-3">
          {/* User filter */}
          <div className="flex-1 min-w-[180px]">
            <label className="block text-xs text-gray-500 mb-1">کاربر</label>
            <select value={filterUserId} onChange={e => setFilterUserId(e.target.value)}
              className="input-field text-sm w-full">
              <option value="">همه کاربران</option>
              {users.map(u => (
                <option key={u.id} value={u.id}>{u.full_name} ({u.mobile})</option>
              ))}
            </select>
          </div>

          {/* Action filter */}
          <div className="flex-1 min-w-[150px]">
            <label className="block text-xs text-gray-500 mb-1">عملیات</label>
            <select value={filterAction} onChange={e => setFilterAction(e.target.value)}
              className="input-field text-sm w-full">
              <option value="">همه عملیات</option>
              {Object.entries(ACTION_LABELS).map(([k, v]) => (
                <option key={k} value={k}>{v}</option>
              ))}
            </select>
          </div>

          {/* Resource type filter */}
          <div className="flex-1 min-w-[130px]">
            <label className="block text-xs text-gray-500 mb-1">نوع منبع</label>
            <select value={filterType} onChange={e => setFilterType(e.target.value)}
              className="input-field text-sm w-full">
              <option value="">همه منابع</option>
              {Object.entries(RESOURCE_TYPE_LABELS).map(([k, v]) => (
                <option key={k} value={k}>{v}</option>
              ))}
            </select>
          </div>
        </div>

        <div className="flex flex-wrap gap-3 items-end">
          {/* Date range */}
          <div>
            <label className="block text-xs text-gray-500 mb-1">از تاریخ</label>
            <input type="date" value={fromDate} onChange={e => setFromDate(e.target.value)}
              className="input-field text-sm" dir="ltr" />
          </div>
          <div>
            <label className="block text-xs text-gray-500 mb-1">تا تاریخ</label>
            <input type="date" value={toDate} onChange={e => setToDate(e.target.value)}
              className="input-field text-sm" dir="ltr" />
          </div>

          {/* Local search */}
          <div className="flex-1 min-w-[160px]">
            <label className="block text-xs text-gray-500 mb-1">جستجو در نتایج</label>
            <div className="relative">
              <Search size={13} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <input value={search} onChange={e => setSearch(e.target.value)}
                placeholder="نام، عملیات، عنوان..."
                className="input-field pr-8 w-full text-sm" />
            </div>
          </div>

          {/* Clear filters */}
          {(filterUserId || filterAction || filterType || fromDate || toDate) && (
            <button
              onClick={() => { setFilterUserId(''); setFilterAction(''); setFilterType(''); setFromDate(''); setToDate('') }}
              className="text-xs text-red-500 hover:text-red-700 px-3 py-2 border border-red-200 rounded-lg hover:bg-red-50 transition-colors self-end"
            >
              پاک کردن فیلترها
            </button>
          )}
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="text-right px-4 py-3 text-gray-600 font-medium">تاریخ و ساعت</th>
                <th className="text-right px-4 py-3 text-gray-600 font-medium">کاربر</th>
                <th className="text-right px-4 py-3 text-gray-600 font-medium">عملیات</th>
                <th className="text-right px-4 py-3 text-gray-600 font-medium">منبع</th>
                <th className="text-right px-4 py-3 text-gray-600 font-medium">عنوان</th>
                <th className="text-right px-4 py-3 text-gray-600 font-medium hidden lg:table-cell">جزئیات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {loading && (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-gray-400">
                    <div className="w-6 h-6 border-2 border-primary-500 border-t-transparent rounded-full animate-spin mx-auto" />
                  </td>
                </tr>
              )}
              {!loading && filtered.length === 0 && (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-gray-400">لاگی یافت نشد</td>
                </tr>
              )}
              {!loading && filtered.map(log => (
                <tr key={log.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-4 py-3 text-gray-700 whitespace-nowrap font-mono text-xs">
                    {log.jalali_datetime || new Date(log.created_at).toLocaleString('fa-IR')}
                  </td>
                  <td className="px-4 py-3">
                    <div className="font-medium text-gray-900">{log.user_name || '—'}</div>
                    {log.user_mobile && <div className="text-xs text-gray-400 font-mono">{log.user_mobile}</div>}
                  </td>
                  <td className="px-4 py-3">
                    <span className={`inline-block px-2 py-0.5 rounded-full text-xs font-medium ${ACTION_COLORS[log.action] || 'bg-gray-100 text-gray-700'}`}>
                      {ACTION_LABELS[log.action] || log.action}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-gray-600">
                    {RESOURCE_TYPE_LABELS[log.resource_type] || log.resource_type}
                  </td>
                  <td className="px-4 py-3 text-gray-800 max-w-[180px] truncate" title={log.resource_title}>
                    {log.resource_title || '—'}
                  </td>
                  <td className="px-4 py-3 text-gray-500 text-xs hidden lg:table-cell max-w-[200px]">
                    {Object.keys(log.details).length > 0 && (
                      <div className="truncate font-mono" title={JSON.stringify(log.details, null, 2)}>
                        {JSON.stringify(log.details)}
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between px-4 py-3 border-t border-gray-200 bg-gray-50">
            <button
              onClick={() => setPage(p => Math.max(1, p - 1))}
              disabled={page <= 1}
              className="flex items-center gap-1 text-sm text-gray-600 hover:text-gray-900 disabled:opacity-40"
            >
              <ChevronRight size={16} />
              قبلی
            </button>
            <span className="text-sm text-gray-600">
              صفحه {page.toLocaleString('fa-IR')} از {totalPages.toLocaleString('fa-IR')}
            </span>
            <button
              onClick={() => setPage(p => Math.min(totalPages, p + 1))}
              disabled={page >= totalPages}
              className="flex items-center gap-1 text-sm text-gray-600 hover:text-gray-900 disabled:opacity-40"
            >
              بعدی
              <ChevronLeft size={16} />
            </button>
          </div>
        )}
      </div>
    </div>
  )
}
