import { useState, useEffect } from 'react'
import { useSearchParams, useNavigate } from 'react-router-dom'
import { tasksApi } from '@/api/tasks'
import { usersApi } from '@/api/users'
import { Task, TaskStatus, TaskPriority, STATUS_LABELS, PRIORITY_LABELS } from '@/types/task'
import { Team, User } from '@/types/common'
import { PriorityBadge, StatusBadge } from '@/components/common/Badge'
import { Avatar } from '@/components/common/Avatar'
import { Modal } from '@/components/common/Modal'
import { JalaliDatePicker } from '@/components/common/JalaliDatePicker'
import { useJalali } from '@/hooks/useJalali'
import { useAuthStore } from '@/store/authStore'
import { Plus, Filter, LayoutGrid, List, ChevronDown, ChevronUp } from 'lucide-react'
import toast from 'react-hot-toast'
import clsx from 'clsx'

const COLUMNS: { status: TaskStatus; label: string; color: string }[] = [
  { status: 'todo', label: 'در انتظار', color: 'border-gray-300' },
  { status: 'in_progress', label: 'در حال انجام', color: 'border-blue-400' },
  { status: 'in_review', label: 'در بررسی', color: 'border-purple-400' },
  { status: 'done', label: 'انجام شده', color: 'border-green-400' },
  { status: 'blocked', label: 'مسدود', color: 'border-red-400' },
]

// Convert "۱۴۰۳/۰۳/۲۵" or "1403/03/25" to ISO date string for backend
function jalaliToISO(jalaliStr: string): string | undefined {
  if (!jalaliStr) return undefined
  const latinized = jalaliStr.replace(/[۰-۹]/g, d => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)))
  const parts = latinized.split('/')
  if (parts.length !== 3) return undefined
  const [jy, jm, jd] = parts.map(Number)
  if (!jy || !jm || !jd) return undefined
  // Simple Jalali→Gregorian
  const j_d_no_arr = [31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29]
  let j_day_no = 365 * (jy - 979) + Math.floor((jy - 979) / 4) - Math.floor((jy - 979) / 100) + Math.floor((jy - 979) / 400)
  for (let i = 0; i < jm - 1; i++) j_day_no += j_d_no_arr[i]
  j_day_no += jd - 1
  let g_day_no = j_day_no + 79
  let gy = 1600 + 400 * Math.floor(g_day_no / 146097); g_day_no %= 146097
  let leap = true
  if (g_day_no >= 36525) {
    g_day_no--
    gy += 100 * Math.floor(g_day_no / 36524); g_day_no %= 36524
    if (g_day_no >= 365) g_day_no++
    else leap = false
  }
  gy += 4 * Math.floor(g_day_no / 1461); g_day_no %= 1461
  if (g_day_no >= 366) { leap = false; g_day_no--; gy += Math.floor(g_day_no / 365); g_day_no %= 365 }
  const g_d_no_arr = [31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
  let gm = 0
  for (gm = 0; gm < 12; gm++) { if (g_day_no < g_d_no_arr[gm]) break; g_day_no -= g_d_no_arr[gm] }
  return new Date(gy, gm, g_day_no + 1, 0, 0, 0).toISOString()
}

function TaskCard({ task, users, onClick }: { task: Task; users: Record<string, string>; onClick: () => void }) {
  const { format } = useJalali()
  const isOverdue = task.due_date && new Date(task.due_date) < new Date() && task.status !== 'done'

  return (
    <div
      onClick={onClick}
      className="bg-white rounded-xl border border-gray-200 p-4 cursor-pointer hover:shadow-md hover:border-primary-300 transition-all group"
    >
      <div className="flex items-start justify-between gap-2 mb-2">
        <h4 className="text-sm font-semibold text-gray-800 group-hover:text-primary-600 line-clamp-2 leading-snug">
          {task.title}
        </h4>
        <PriorityBadge priority={task.priority} />
      </div>

      {task.description && (
        <p className="text-xs text-gray-500 line-clamp-2 mb-3">{task.description}</p>
      )}

      {task.tags.length > 0 && (
        <div className="flex flex-wrap gap-1 mb-3">
          {task.tags.slice(0, 3).map(tag => (
            <span key={tag} className="text-xs bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full">{tag}</span>
          ))}
        </div>
      )}

      {task.checklist.length > 0 && (
        <div className="mb-3">
          <div className="flex justify-between text-xs text-gray-500 mb-1">
            <span>چک‌لیست</span>
            <span>{task.checklist.filter(c => c.is_done).length}/{task.checklist.length}</span>
          </div>
          <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
            <div
              className="h-full bg-green-500 rounded-full transition-all"
              style={{ width: `${(task.checklist.filter(c => c.is_done).length / task.checklist.length) * 100}%` }}
            />
          </div>
        </div>
      )}

      <div className="flex items-center justify-between mt-3 pt-3 border-t border-gray-100">
        {task.assignee_id && (
          <Avatar name={users[task.assignee_id] || '?'} size="xs" />
        )}
        {task.due_date && (
          <span className={clsx('text-xs', isOverdue ? 'text-red-600 font-medium' : 'text-gray-500')}>
            {isOverdue ? '⚠ ' : '📅 '}{format(task.due_date)}
          </span>
        )}
      </div>
    </div>
  )
}

// Collapsible Kanban Column
function KanbanColumn({
  col, tasks, users, onDrop, onTaskClick
}: {
  col: typeof COLUMNS[0]
  tasks: Task[]
  users: Record<string, string>
  onDrop: (e: React.DragEvent, status: TaskStatus) => void
  onTaskClick: (id: string) => void
}) {
  const [collapsed, setCollapsed] = useState(false)
  const [showAll, setShowAll] = useState(false)
  const LIMIT = 10
  const visible = showAll ? tasks : tasks.slice(0, LIMIT)

  return (
    <div
      className="flex-none"
      style={{ minWidth: collapsed ? 56 : 280 }}
      onDragOver={e => e.preventDefault()}
      onDrop={e => onDrop(e, col.status)}
    >
      <div className={clsx('bg-gray-50 rounded-xl border-t-4 p-3 h-full', col.color)}>
        {/* Header */}
        <div
          className="flex items-center justify-between mb-3 px-1 cursor-pointer"
          onClick={() => setCollapsed(c => !c)}
        >
          {!collapsed && (
            <span className="font-semibold text-sm text-gray-700">{col.label}</span>
          )}
          <div className="flex items-center gap-1.5">
            <span className="bg-gray-200 text-gray-600 text-xs font-bold px-2 py-0.5 rounded-full">
              {tasks.length}
            </span>
            {collapsed
              ? <ChevronDown size={14} className="text-gray-400" />
              : <ChevronUp size={14} className="text-gray-400" />
            }
          </div>
        </div>

        {/* Cards */}
        {!collapsed && (
          <>
            <div className="space-y-3 min-h-[200px]">
              {visible.map(task => (
                <div key={task.id} draggable onDragStart={e => e.dataTransfer.setData('taskId', task.id)}>
                  <TaskCard task={task} users={users} onClick={() => onTaskClick(task.id)} />
                </div>
              ))}
            </div>

            {tasks.length > LIMIT && (
              <button
                onClick={() => setShowAll(s => !s)}
                className="mt-3 w-full text-center text-xs text-primary-600 hover:text-primary-700 font-medium py-1.5 hover:bg-primary-50 rounded-lg transition-colors"
              >
                {showAll ? 'نمایش کمتر' : `نمایش بیشتر... (${tasks.length - LIMIT} تسک دیگر)`}
              </button>
            )}
          </>
        )}
      </div>
    </div>
  )
}

type AssignMode = 'user' | 'team' | 'team_manager'

function CreateTaskModal({ isOpen, onClose, teams, allUsers, onCreated }: {
  isOpen: boolean
  onClose: () => void
  teams: Team[]
  allUsers: User[]
  onCreated: (t: Task) => void
}) {
  const { user: currentUser } = useAuthStore()
  const [title, setTitle] = useState('')
  const [assignMode, setAssignMode] = useState<AssignMode>('user')
  const [assigneeId, setAssigneeId] = useState(currentUser?.id || '')
  const [teamId, setTeamId] = useState('')
  const [priority, setPriority] = useState<TaskPriority>('medium')
  const [dueDate, setDueDate] = useState('')
  const [description, setDescription] = useState('')
  const [loading, setLoading] = useState(false)

  // Reset when modal opens
  useEffect(() => {
    if (isOpen) {
      setAssigneeId(currentUser?.id || '')
      setTeamId('')
      setAssignMode('user')
    }
  }, [isOpen, currentUser?.id])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!title.trim()) { toast.error('عنوان الزامی است'); return }
    if (assignMode === 'user' && !assigneeId) { toast.error('مسئول را انتخاب کنید'); return }
    if ((assignMode === 'team' || assignMode === 'team_manager') && !teamId) { toast.error('تیم را انتخاب کنید'); return }
    setLoading(true)
    try {
      const payload: any = {
        title: title.trim(),
        priority,
        due_date: jalaliToISO(dueDate),
        description: description || undefined,
      }
      if (assignMode === 'user') {
        payload.assignee_id = assigneeId
      } else if (assignMode === 'team') {
        payload.team_id = teamId
      } else {
        // team_manager: let team manager assign
        payload.team_id = teamId
        payload.assignee_id = undefined
      }
      const { data } = await tasksApi.create(payload)
      toast.success('تسک ایجاد شد')
      onCreated(data)
      setTitle(''); setAssigneeId(currentUser?.id || ''); setTeamId('')
      setPriority('medium'); setDueDate(''); setDescription('')
      onClose()
    } catch { toast.error('خطا در ایجاد تسک') }
    finally { setLoading(false) }
  }

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="ایجاد تسک جدید" size="lg">
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">عنوان *</label>
          <input className="input-field" value={title} onChange={e => setTitle(e.target.value)} placeholder="عنوان تسک" required />
        </div>

        {/* Assignment mode */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">نوع اختصاص</label>
          <div className="flex gap-2 flex-wrap">
            {([
              { value: 'user', label: 'اختصاص به فرد' },
              { value: 'team', label: 'اختصاص به تیم' },
              { value: 'team_manager', label: 'مدیر تیم انتخاب کند' },
            ] as const).map(opt => (
              <label key={opt.value} className={clsx(
                'flex items-center gap-1.5 px-3 py-1.5 rounded-lg border cursor-pointer text-sm transition-colors',
                assignMode === opt.value
                  ? 'bg-primary-600 text-white border-primary-600'
                  : 'bg-white text-gray-600 border-gray-300 hover:border-primary-400'
              )}>
                <input
                  type="radio"
                  name="assignMode"
                  value={opt.value}
                  checked={assignMode === opt.value}
                  onChange={() => setAssignMode(opt.value)}
                  className="hidden"
                />
                {opt.label}
              </label>
            ))}
          </div>
        </div>

        {/* Assignee / Team selector */}
        <div className="grid grid-cols-2 gap-4">
          {assignMode === 'user' ? (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">مسئول *</label>
              <select className="input-field" value={assigneeId} onChange={e => setAssigneeId(e.target.value)} required>
                <option value="">انتخاب مسئول</option>
                {allUsers.map(u => (
                  <option key={u.id} value={u.id}>
                    {u.full_name}{u.id === currentUser?.id ? ' (من)' : ''}
                  </option>
                ))}
              </select>
            </div>
          ) : (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">تیم *</label>
              <select className="input-field" value={teamId} onChange={e => setTeamId(e.target.value)} required>
                <option value="">انتخاب تیم</option>
                {teams.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
              </select>
            </div>
          )}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">اولویت</label>
            <select className="input-field" value={priority} onChange={e => setPriority(e.target.value as TaskPriority)}>
              {Object.entries(PRIORITY_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
            </select>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">ددلاین</label>
          <JalaliDatePicker
            value={dueDate}
            onChange={setDueDate}
            placeholder="انتخاب تاریخ ددلاین"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">توضیحات</label>
          <textarea className="input-field resize-none" rows={3} value={description} onChange={e => setDescription(e.target.value)} placeholder="توضیحات تسک..." />
        </div>
        <div className="flex gap-3 pt-2">
          <button type="submit" disabled={loading} className="btn-primary flex-1">
            {loading ? 'در حال ایجاد...' : 'ایجاد تسک'}
          </button>
          <button type="button" onClick={onClose} className="btn-secondary flex-1">انصراف</button>
        </div>
      </form>
    </Modal>
  )
}

type SortField = 'priority' | 'due_date' | 'status' | 'title' | 'assignee' | 'created_at'
type SortDir = 'asc' | 'desc'

const PRIORITY_ORDER: Record<TaskPriority, number> = { urgent: 0, high: 1, medium: 2, low: 3 }
const STATUS_ORDER: Record<TaskStatus, number> = { blocked: 0, in_progress: 1, in_review: 2, todo: 3, done: 4 }

const PRIORITY_BORDER: Record<TaskPriority, string> = {
  urgent: 'border-r-4 border-red-500',
  high: 'border-r-4 border-orange-400',
  medium: 'border-r-4 border-yellow-400',
  low: 'border-r-4 border-green-400',
}

function SortableTh({ field, label, sortField, sortDir, onSort }: {
  field: SortField; label: string; sortField: SortField; sortDir: SortDir; onSort: (f: SortField) => void
}) {
  const active = sortField === field
  return (
    <th
      className="text-right text-xs font-semibold text-gray-500 px-4 py-3 cursor-pointer hover:text-primary-600 select-none whitespace-nowrap"
      onClick={() => onSort(field)}
    >
      <span className="flex items-center gap-1">
        {label}
        {active ? (sortDir === 'asc' ? <ChevronUp size={13} className="text-primary-500" /> : <ChevronDown size={13} className="text-primary-500" />) : null}
      </span>
    </th>
  )
}

export default function Tasks() {
  const [tasks, setTasks] = useState<Task[]>([])
  const [teams, setTeams] = useState<Team[]>([])
  const [allUsers, setAllUsers] = useState<User[]>([])
  const [users, setUsers] = useState<Record<string, string>>({})
  const [loading, setLoading] = useState(true)
  const [view, setView] = useState<'kanban' | 'list'>('list')
  const [showCreate, setShowCreate] = useState(false)
  const [filterStatus, setFilterStatus] = useState<TaskStatus | ''>('')
  const [filterPriority, setFilterPriority] = useState<TaskPriority | ''>('')
  const [filterOverdue, setFilterOverdue] = useState(false)
  const [sortField, setSortField] = useState<SortField>('priority')
  const [sortDir, setSortDir] = useState<SortDir>('asc')
  const navigate = useNavigate()
  const [searchParams] = useSearchParams()
  const search = searchParams.get('search') || ''

  useEffect(() => {
    Promise.all([
      tasksApi.list({ search: search || undefined, status: filterStatus || undefined, priority: filterPriority || undefined, page_size: 100 }),
      usersApi.listTeams(),
      usersApi.list(),
    ]).then(([taskRes, teamRes, userRes]) => {
      setTasks(taskRes.data.items)
      setTeams(teamRes.data)
      const usersArr = userRes.data as User[]
      setAllUsers(usersArr)
      const userMap: Record<string, string> = {}
      usersArr.forEach(u => { userMap[u.id] = u.full_name })
      setUsers(userMap)
    }).finally(() => setLoading(false))
  }, [search, filterStatus, filterPriority])

  const tasksByStatus = (status: TaskStatus) => tasks.filter(t => t.status === status)

  const handleDrop = async (e: React.DragEvent, toStatus: TaskStatus) => {
    const taskId = e.dataTransfer.getData('taskId')
    try {
      await tasksApi.update(taskId, { status: toStatus })
      setTasks(prev => prev.map(t => t.id === taskId ? { ...t, status: toStatus } : t))
    } catch { toast.error('خطا در به‌روزرسانی وضعیت') }
  }

  const handleInlineStatus = async (taskId: string, status: TaskStatus) => {
    try {
      await tasksApi.update(taskId, { status })
      setTasks(prev => prev.map(t => t.id === taskId ? { ...t, status } : t))
    } catch { toast.error('خطا در تغییر وضعیت') }
  }

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDir(d => d === 'asc' ? 'desc' : 'asc')
    } else {
      setSortField(field)
      setSortDir('asc')
    }
  }

  const now = new Date()
  const sortedTasks = [...tasks]
    .filter(t => !filterOverdue || (t.due_date && new Date(t.due_date) < now && t.status !== 'done'))
    .sort((a, b) => {
      let cmp = 0
      if (sortField === 'priority') {
        cmp = (PRIORITY_ORDER[a.priority] ?? 9) - (PRIORITY_ORDER[b.priority] ?? 9)
      } else if (sortField === 'status') {
        cmp = (STATUS_ORDER[a.status] ?? 9) - (STATUS_ORDER[b.status] ?? 9)
      } else if (sortField === 'due_date') {
        const da = a.due_date ? new Date(a.due_date).getTime() : Infinity
        const db = b.due_date ? new Date(b.due_date).getTime() : Infinity
        cmp = da - db
      } else if (sortField === 'title') {
        cmp = a.title.localeCompare(b.title, 'fa')
      } else if (sortField === 'assignee') {
        const na = a.assignee_id ? (users[a.assignee_id] || '') : ''
        const nb = b.assignee_id ? (users[b.assignee_id] || '') : ''
        cmp = na.localeCompare(nb, 'fa')
      } else if (sortField === 'created_at') {
        cmp = new Date(a.created_at).getTime() - new Date(b.created_at).getTime()
      }
      return sortDir === 'asc' ? cmp : -cmp
    })

  if (loading) return (
    <div className="flex items-center justify-center h-64">
      <div className="w-8 h-8 border-4 border-primary-500 border-t-transparent rounded-full animate-spin" />
    </div>
  )

  return (
    <div className="h-full flex flex-col" dir="rtl">
      {/* Header */}
      <div className="flex items-center justify-between mb-4 flex-wrap gap-3">
        <h1 className="text-2xl font-bold text-gray-900">تسک‌ها</h1>
        <div className="flex items-center gap-2 flex-wrap">
          {/* View toggle */}
          <div className="flex bg-gray-100 rounded-lg p-1">
            <button onClick={() => setView('list')} className={clsx('p-1.5 rounded', view === 'list' ? 'bg-white shadow-sm' : 'hover:bg-gray-200')} title="نمای لیست">
              <List size={16} />
            </button>
            <button onClick={() => setView('kanban')} className={clsx('p-1.5 rounded', view === 'kanban' ? 'bg-white shadow-sm' : 'hover:bg-gray-200')} title="نمای کانبان">
              <LayoutGrid size={16} />
            </button>
          </div>

          <button onClick={() => setShowCreate(true)} className="btn-primary flex items-center gap-2">
            <Plus size={16} />
            تسک جدید
          </button>
        </div>
      </div>

      {/* Filter chips row */}
      {view === 'list' && (
        <div className="flex flex-wrap gap-2 mb-4">
          {/* Status chips */}
          <button
            onClick={() => setFilterStatus('')}
            className={clsx('px-3 py-1 rounded-full text-xs font-medium border transition-colors', filterStatus === '' ? 'bg-gray-800 text-white border-gray-800' : 'bg-white text-gray-600 border-gray-300 hover:border-gray-400')}
          >
            همه وضعیت‌ها
          </button>
          {(Object.entries(STATUS_LABELS) as [TaskStatus, string][]).map(([k, v]) => (
            <button
              key={k}
              onClick={() => setFilterStatus(filterStatus === k ? '' : k)}
              className={clsx('px-3 py-1 rounded-full text-xs font-medium border transition-colors', filterStatus === k ? 'bg-primary-600 text-white border-primary-600' : 'bg-white text-gray-600 border-gray-300 hover:border-primary-300')}
            >
              {v}
            </button>
          ))}

          <div className="w-px bg-gray-200 mx-1" />

          {/* Priority chips */}
          <button
            onClick={() => setFilterPriority('')}
            className={clsx('px-3 py-1 rounded-full text-xs font-medium border transition-colors', filterPriority === '' ? 'bg-gray-800 text-white border-gray-800' : 'bg-white text-gray-600 border-gray-300 hover:border-gray-400')}
          >
            همه اولویت‌ها
          </button>
          {(Object.entries(PRIORITY_LABELS) as [TaskPriority, string][]).map(([k, v]) => (
            <button
              key={k}
              onClick={() => setFilterPriority(filterPriority === k ? '' : k)}
              className={clsx('px-3 py-1 rounded-full text-xs font-medium border transition-colors', filterPriority === k ? 'bg-primary-600 text-white border-primary-600' : 'bg-white text-gray-600 border-gray-300 hover:border-primary-300')}
            >
              {v}
            </button>
          ))}

          <div className="w-px bg-gray-200 mx-1" />

          {/* Overdue chip */}
          <button
            onClick={() => setFilterOverdue(f => !f)}
            className={clsx('px-3 py-1 rounded-full text-xs font-medium border transition-colors flex items-center gap-1', filterOverdue ? 'bg-red-600 text-white border-red-600' : 'bg-white text-red-600 border-red-300 hover:border-red-400')}
          >
            ⚠ فقط دیرکرد
          </button>
        </div>
      )}

      {/* Kanban View */}
      {view === 'kanban' ? (
        <div className="flex gap-4 overflow-x-auto pb-4 flex-1" style={{ minHeight: 0 }}>
          {COLUMNS.map(col => (
            <KanbanColumn
              key={col.status}
              col={col}
              tasks={tasksByStatus(col.status)}
              users={users}
              onDrop={handleDrop}
              onTaskClick={id => navigate(`/tasks/${id}`)}
            />
          ))}
        </div>
      ) : (
        /* Smart List View */
        <div className="card overflow-hidden flex-1 flex flex-col min-h-0">
          <div className="overflow-auto flex-1">
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-200 sticky top-0 z-10">
                <tr>
                  <SortableTh field="title" label="عنوان" sortField={sortField} sortDir={sortDir} onSort={handleSort} />
                  <SortableTh field="status" label="وضعیت" sortField={sortField} sortDir={sortDir} onSort={handleSort} />
                  <SortableTh field="priority" label="اولویت" sortField={sortField} sortDir={sortDir} onSort={handleSort} />
                  <SortableTh field="assignee" label="مسئول" sortField={sortField} sortDir={sortDir} onSort={handleSort} />
                  <SortableTh field="due_date" label="ددلاین" sortField={sortField} sortDir={sortDir} onSort={handleSort} />
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {sortedTasks.map(task => {
                  const isOverdue = task.due_date && new Date(task.due_date) < now && task.status !== 'done'
                  return (
                    <tr
                      key={task.id}
                      className={clsx(
                        'cursor-pointer transition-colors group',
                        PRIORITY_BORDER[task.priority],
                        isOverdue ? 'bg-red-50 hover:bg-red-100' : 'hover:bg-gray-50'
                      )}
                    >
                      <td className="px-4 py-3" onClick={() => navigate(`/tasks/${task.id}`)}>
                        <div className="font-medium text-sm text-gray-800 group-hover:text-primary-600">{task.title}</div>
                        {task.tags.length > 0 && (
                          <div className="flex gap-1 mt-1">
                            {task.tags.slice(0, 3).map(t => (
                              <span key={t} className="text-xs bg-gray-100 px-1.5 py-0.5 rounded text-gray-500">{t}</span>
                            ))}
                          </div>
                        )}
                      </td>
                      <td className="px-4 py-2" onClick={e => e.stopPropagation()}>
                        <select
                          value={task.status}
                          onChange={e => handleInlineStatus(task.id, e.target.value as TaskStatus)}
                          className="text-xs border border-gray-200 rounded-lg px-2 py-1 focus:outline-none focus:ring-1 focus:ring-primary-300 bg-white cursor-pointer"
                          onClick={e => e.stopPropagation()}
                        >
                          {(Object.entries(STATUS_LABELS) as [TaskStatus, string][]).map(([k, v]) => (
                            <option key={k} value={k}>{v}</option>
                          ))}
                        </select>
                      </td>
                      <td className="px-4 py-3" onClick={() => navigate(`/tasks/${task.id}`)}>
                        <PriorityBadge priority={task.priority} />
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-600" onClick={() => navigate(`/tasks/${task.id}`)}>
                        {task.assignee_id ? users[task.assignee_id] || '—' : '—'}
                      </td>
                      <td className={clsx('px-4 py-3 text-sm', isOverdue ? 'text-red-600 font-medium' : 'text-gray-500')} onClick={() => navigate(`/tasks/${task.id}`)}>
                        {task.due_date ? (
                          <span>{isOverdue ? '⚠ ' : ''}{new Date(task.due_date).toLocaleDateString('fa-IR')}</span>
                        ) : '—'}
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
            {sortedTasks.length === 0 && (
              <div className="text-center py-12 text-gray-400">تسکی یافت نشد</div>
            )}
          </div>
        </div>
      )}

      <CreateTaskModal
        isOpen={showCreate}
        onClose={() => setShowCreate(false)}
        teams={teams}
        allUsers={allUsers}
        onCreated={(t) => setTasks(prev => [t, ...prev])}
      />
    </div>
  )
}
