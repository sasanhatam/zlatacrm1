import { useState, useEffect } from 'react'
import { dashboardApi } from '@/api/dashboard'
import { usersApi } from '@/api/users'
import { tasksApi } from '@/api/tasks'
import { Task, TaskPriority, PRIORITY_LABELS } from '@/types/task'
import { Team } from '@/types/common'
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts'
import { TrendingUp, Clock, CheckCircle, AlertTriangle, Download, UserCheck, FileText, Calendar, RefreshCw } from 'lucide-react'
import { useAuthStore } from '@/store/authStore'
import toast from 'react-hot-toast'
import clsx from 'clsx'

const STATUS_COLORS: Record<string, string> = {
  todo: '#94a3b8', in_progress: '#3b82f6', in_review: '#a855f7',
  done: '#22c55e', blocked: '#ef4444',
}

const PRIORITY_BADGE_CLASSES: Record<TaskPriority, string> = {
  urgent: 'bg-red-100 text-red-700',
  high: 'bg-orange-100 text-orange-700',
  medium: 'bg-yellow-100 text-yellow-700',
  low: 'bg-green-100 text-green-700',
}

function StatCard({ label, value, icon: Icon, color }: { label: string; value: number | string; icon: any; color: string }) {
  return (
    <div className="card p-5 flex items-center gap-4">
      <div className={`w-12 h-12 ${color} rounded-xl flex items-center justify-center flex-shrink-0`}>
        <Icon size={22} className="text-white" />
      </div>
      <div>
        <p className="text-2xl font-bold text-gray-900">{value}</p>
        <p className="text-sm text-gray-500">{label}</p>
      </div>
    </div>
  )
}

function ReassignModal({ task, users, onClose, onDone }: {
  task: Task; users: any[]; onClose: () => void; onDone: () => void
}) {
  const [assigneeId, setAssigneeId] = useState('')
  const [note, setNote] = useState('')
  const [loading, setLoading] = useState(false)

  const handleSubmit = async () => {
    if (!assigneeId) { toast.error('مسئول را انتخاب کنید'); return }
    setLoading(true)
    try {
      await tasksApi.update(task.id, { assignee_id: assigneeId } as any)
      if (note.trim()) {
        await tasksApi.addComment(task.id, `ارجاع: ${note}`)
      }
      toast.success('تسک ارجاع داده شد')
      onDone()
    } catch {
      toast.error('خطا در ارجاع تسک')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4" dir="rtl">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-6 space-y-4">
        <h3 className="text-lg font-bold text-gray-900">ارجاع تسک</h3>
        <p className="text-sm text-gray-500 bg-gray-50 rounded-lg px-3 py-2">{task.title}</p>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">مسئول جدید *</label>
          <select
            value={assigneeId}
            onChange={e => setAssigneeId(e.target.value)}
            className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary-300"
          >
            <option value="">انتخاب کنید</option>
            {users.map((u: any) => (
              <option key={u.id} value={u.id}>{u.full_name}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">توضیح (اختیاری)</label>
          <textarea
            value={note}
            onChange={e => setNote(e.target.value)}
            rows={2}
            className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-primary-300"
            placeholder="دلیل ارجاع..."
          />
        </div>
        <div className="flex gap-3">
          <button
            onClick={handleSubmit}
            disabled={loading}
            className="flex-1 bg-primary-600 text-white rounded-lg py-2 text-sm font-medium hover:bg-primary-700 disabled:opacity-50 flex items-center justify-center gap-2"
          >
            {loading ? <RefreshCw size={14} className="animate-spin" /> : null}
            ارجاع
          </button>
          <button onClick={onClose} className="flex-1 border border-gray-300 text-gray-700 rounded-lg py-2 text-sm hover:bg-gray-50">
            انصراف
          </button>
        </div>
      </div>
    </div>
  )
}

export default function Dashboard() {
  const { user } = useAuthStore()
  const isManager = user?.role === 'super_admin' || user?.role === 'manager'

  const [overview, setOverview] = useState<any>(null)
  const [performance, setPerformance] = useState<any[]>([])
  const [teams, setTeams] = useState<Team[]>([])
  const [allUsers, setAllUsers] = useState<any[]>([])
  const [filterTeam, setFilterTeam] = useState('')
  const [loading, setLoading] = useState(true)
  const [overdueTasks, setOverdueTasks] = useState<Task[]>([])
  const [reassignTask, setReassignTask] = useState<Task | null>(null)
  const [userMap, setUserMap] = useState<Record<string, string>>({})

  useEffect(() => {
    Promise.all([
      dashboardApi.overview({ team_id: filterTeam || undefined }),
      dashboardApi.userPerformance({ team_id: filterTeam || undefined }),
      usersApi.listTeams(),
      ...(isManager ? [usersApi.list(), tasksApi.list({ page_size: 100 })] : []),
    ]).then(([overRes, perfRes, teamRes, ...rest]) => {
      setOverview(overRes.data)
      setPerformance(perfRes.data)
      setTeams(teamRes.data)
      if (isManager && rest.length >= 2) {
        const usersArr = (rest[0] as any).data as any[]
        const tasksRes = (rest[1] as any).data.items as Task[]
        setAllUsers(usersArr)
        const um: Record<string, string> = {}
        usersArr.forEach((u: any) => { um[u.id] = u.full_name })
        setUserMap(um)
        const now = new Date()
        setOverdueTasks(tasksRes.filter(t => t.due_date && new Date(t.due_date) < now && t.status !== 'done'))
      }
    }).finally(() => setLoading(false))
  }, [filterTeam, isManager])

  const handleExcel = async () => {
    try {
      const res = await dashboardApi.exportExcel({ team_id: filterTeam || undefined })
      const url = URL.createObjectURL(new Blob([res.data]))
      const a = document.createElement('a')
      a.href = url; a.download = 'tasks.xlsx'; a.click()
    } catch { toast.error('خطا در دانلود فایل') }
  }

  if (loading) return <div className="flex items-center justify-center h-64"><div className="w-8 h-8 border-4 border-primary-500 border-t-transparent rounded-full animate-spin" /></div>
  if (!overview) return null

  const pieData = [
    { name: 'در انتظار', value: overview.task_stats.todo, color: STATUS_COLORS.todo },
    { name: 'در حال انجام', value: overview.task_stats.in_progress, color: STATUS_COLORS.in_progress },
    { name: 'در بررسی', value: overview.task_stats.in_review, color: STATUS_COLORS.in_review },
    { name: 'انجام شده', value: overview.task_stats.done, color: STATUS_COLORS.done },
    { name: 'مسدود', value: overview.task_stats.blocked, color: STATUS_COLORS.blocked },
  ].filter(d => d.value > 0)

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900">داشبورد</h1>
        <div className="flex items-center gap-3">
          <select value={filterTeam} onChange={e => setFilterTeam(e.target.value)} className="input-field w-auto text-sm py-1.5">
            <option value="">همه تیم‌ها</option>
            {teams.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
          </select>
          <button onClick={handleExcel} className="btn-secondary flex items-center gap-2 text-sm">
            <Download size={15} />
            خروجی اکسل
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="کل تسک‌ها" value={overview.task_stats.total} icon={CheckCircle} color="bg-primary-600" />
        <StatCard label="در حال انجام" value={overview.task_stats.in_progress} icon={TrendingUp} color="bg-blue-500" />
        <StatCard label="معوق" value={overview.task_stats.overdue} icon={AlertTriangle} color="bg-red-500" />
        <StatCard label="راکد" value={overview.stale_tasks_count} icon={Clock} color="bg-orange-500" />
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Pie Chart */}
        <div className="card p-5">
          <h2 className="font-semibold text-gray-800 mb-4">توزیع وضعیت تسک‌ها</h2>
          <ResponsiveContainer width="100%" height={240}>
            <PieChart>
              <Pie data={pieData} cx="50%" cy="50%" outerRadius={90} dataKey="value" nameKey="name" label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`} labelLine={false}>
                {pieData.map((entry, index) => <Cell key={index} fill={entry.color} />)}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>

        {/* Team Stats Bar */}
        <div className="card p-5">
          <h2 className="font-semibold text-gray-800 mb-4">عملکرد تیم‌ها</h2>
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={overview.team_stats} layout="vertical">
              <XAxis type="number" />
              <YAxis type="category" dataKey="team_name" width={80} tick={{ fontSize: 12 }} />
              <Tooltip />
              <Bar dataKey="task_stats.done" name="انجام‌شده" fill="#22c55e" stackId="a" />
              <Bar dataKey="task_stats.in_progress" name="در انجام" fill="#3b82f6" stackId="a" />
              <Bar dataKey="task_stats.todo" name="در انتظار" fill="#94a3b8" stackId="a" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* User Performance */}
      <div className="card overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-200">
          <h2 className="font-semibold text-gray-800">عملکرد کاربران</h2>
        </div>
        <table className="w-full">
          <thead className="bg-gray-50 border-b border-gray-200">
            <tr>
              {['کاربر','کل تسک','انجام‌شده','به‌موقع','دیرکرد','میانگین تاخیر','نرخ موفقیت'].map(h => (
                <th key={h} className="text-right text-xs font-semibold text-gray-500 px-4 py-3">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {performance.map(p => (
              <tr key={p.user_id} className="hover:bg-gray-50 transition-colors">
                <td className="px-4 py-3 font-medium text-sm text-gray-800">{p.full_name}</td>
                <td className="px-4 py-3 text-sm text-gray-600">{p.total_assigned}</td>
                <td className="px-4 py-3 text-sm text-green-600 font-medium">{p.completed}</td>
                <td className="px-4 py-3 text-sm text-blue-600">{p.on_time}</td>
                <td className="px-4 py-3 text-sm text-red-600">{p.overdue}</td>
                <td className="px-4 py-3 text-sm text-gray-600">{p.avg_delay_hours ? `${p.avg_delay_hours}h` : '—'}</td>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-2">
                    <div className="flex-1 h-2 bg-gray-200 rounded-full overflow-hidden">
                      <div className="h-full bg-green-500 rounded-full" style={{ width: `${p.completion_rate}%` }} />
                    </div>
                    <span className="text-xs font-medium text-gray-700 w-10">{p.completion_rate}%</span>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {performance.length === 0 && <p className="text-center py-8 text-gray-400">داده‌ای یافت نشد</p>}
      </div>

      {/* Manager Oversight Section */}
      {isManager && (
        <div className="space-y-4">
          {/* Section header */}
          <div className="flex items-center gap-3">
            <h2 className="text-lg font-bold text-gray-900">نظارت مدیریتی</h2>
            <span className="text-xs bg-red-100 text-red-700 px-2 py-0.5 rounded-full font-medium">
              {overdueTasks.length} تسک دیرکرد
            </span>
          </div>

          {/* Overview stat cards */}
          <div className="grid grid-cols-3 gap-4">
            <StatCard
              label="تسک‌های معوق"
              value={overdueTasks.length}
              icon={AlertTriangle}
              color="bg-red-500"
            />
            <StatCard
              label="در انتظار تأیید نامه"
              value={overview?.letter_stats?.pending_approval ?? '—'}
              icon={FileText}
              color="bg-yellow-500"
            />
            <StatCard
              label="مرخصی‌های در انتظار"
              value={overview?.leave_stats?.pending ?? '—'}
              icon={Calendar}
              color="bg-blue-500"
            />
          </div>

          {/* Overdue tasks list */}
          {overdueTasks.length > 0 && (
            <div className="card overflow-hidden">
              <div className="px-6 py-4 border-b border-gray-200">
                <h3 className="font-semibold text-gray-800 text-sm">تسک‌های دیرکرده</h3>
              </div>
              <table className="w-full">
                <thead className="bg-red-50 border-b border-red-100">
                  <tr>
                    {['اولویت', 'عنوان تسک', 'مسئول', 'ددلاین', 'ارجاع'].map(h => (
                      <th key={h} className="text-right text-xs font-semibold text-gray-500 px-4 py-2">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {overdueTasks.map(task => (
                    <tr key={task.id} className="hover:bg-red-50 transition-colors">
                      <td className="px-4 py-2.5">
                        <span className={clsx('text-xs px-2 py-0.5 rounded-full font-medium', PRIORITY_BADGE_CLASSES[task.priority])}>
                          {PRIORITY_LABELS[task.priority]}
                        </span>
                      </td>
                      <td className="px-4 py-2.5 text-sm font-medium text-gray-800 max-w-xs truncate">{task.title}</td>
                      <td className="px-4 py-2.5 text-sm text-gray-600">
                        {task.assignee_id ? userMap[task.assignee_id] || '—' : '—'}
                      </td>
                      <td className="px-4 py-2.5 text-sm text-red-600 font-medium">
                        ⚠ {task.due_date ? new Date(task.due_date).toLocaleDateString('fa-IR') : '—'}
                      </td>
                      <td className="px-4 py-2.5">
                        <button
                          onClick={() => setReassignTask(task)}
                          className="flex items-center gap-1 text-xs bg-primary-600 text-white px-2.5 py-1 rounded-lg hover:bg-primary-700 transition-colors"
                        >
                          <UserCheck size={11} />
                          ارجاع
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Reassign Modal */}
      {reassignTask && (
        <ReassignModal
          task={reassignTask}
          users={allUsers}
          onClose={() => setReassignTask(null)}
          onDone={() => {
            setReassignTask(null)
            // Refresh overdue tasks
            tasksApi.list({ page_size: 100 }).then(r => {
              const now = new Date()
              setOverdueTasks(r.data.items.filter(t => t.due_date && new Date(t.due_date) < now && t.status !== 'done'))
            })
          }}
        />
      )}
    </div>
  )
}
