import { useState, useEffect } from 'react'
import {
  CalendarDays, Plus, Clock, MapPin, Video, Users,
  RefreshCw, CheckCircle, XCircle, AlertCircle, FileText, CalendarClock,
} from 'lucide-react'
import { meetingsApi, Meeting, MeetingStatus, MeetingType, AttendeeStatus } from '@/api/meetings'
import { usersApi } from '@/api/users'
import { useAuthStore } from '@/store/authStore'
import toast from 'react-hot-toast'
import clsx from 'clsx'

const STATUS_LABELS: Record<MeetingStatus, string> = {
  scheduled: 'برنامه‌ریزی شده',
  in_progress: 'در حال برگزاری',
  completed: 'برگزار شده',
  cancelled: 'لغو شده',
}

const STATUS_COLORS: Record<MeetingStatus, string> = {
  scheduled: 'bg-blue-100 text-blue-700',
  in_progress: 'bg-green-100 text-green-700',
  completed: 'bg-gray-100 text-gray-600',
  cancelled: 'bg-red-100 text-red-600',
}

const TYPE_ICONS: Record<MeetingType, any> = {
  in_person: MapPin,
  online: Video,
  hybrid: Users,
}

const ATTENDEE_LABELS: Record<AttendeeStatus, string> = {
  pending: 'در انتظار',
  accepted: 'پذیرفته',
  declined: 'رد کرده',
  tentative: 'احتمالی',
}

const ATTENDEE_COLORS: Record<AttendeeStatus, string> = {
  pending: 'text-yellow-600',
  accepted: 'text-green-600',
  declined: 'text-red-600',
  tentative: 'text-gray-500',
}

function MeetingCard({ meeting, onRespond, onSelect, onPropose }: {
  meeting: Meeting
  onRespond: (id: string, status: AttendeeStatus) => void
  onSelect: (m: Meeting) => void
  onPropose: (m: Meeting) => void
}) {
  const { user } = useAuthStore()
  const TypeIcon = TYPE_ICONS[meeting.meeting_type]
  const myAttendance = meeting.attendees?.find(a => a.user_id === user?.id)
  const start = new Date(meeting.start_time)
  const end = new Date(meeting.end_time)

  return (
    <div
      className="bg-white rounded-xl border border-gray-100 p-5 hover:border-primary-200 hover:shadow-sm transition-all cursor-pointer"
      onClick={() => onSelect(meeting)}
    >
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-2">
            <TypeIcon size={16} className="text-primary-500" />
            <h3 className="font-semibold text-gray-900">{meeting.title}</h3>
            <span className={clsx('text-xs px-2 py-0.5 rounded-full font-medium', STATUS_COLORS[meeting.status])}>
              {STATUS_LABELS[meeting.status]}
            </span>
          </div>

          <div className="flex items-center gap-4 text-sm text-gray-500 mb-2">
            <span className="flex items-center gap-1">
              <Clock size={13} />
              {start.toLocaleDateString('fa-IR')} · {start.toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })}
              {' - '}
              {end.toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })}
            </span>
            {meeting.location && (
              <span className="flex items-center gap-1">
                <MapPin size={13} />
                {meeting.location}
              </span>
            )}
          </div>

          <div className="flex items-center gap-3">
            <span className="text-xs text-gray-400">
              {meeting.attendees?.length || 0} نفر شرکت‌کننده
            </span>
            {myAttendance && (
              <span className={clsx('text-xs font-medium', ATTENDEE_COLORS[myAttendance.status as AttendeeStatus])}>
                وضعیت شما: {ATTENDEE_LABELS[myAttendance.status as AttendeeStatus]}
              </span>
            )}
          </div>
        </div>

        {myAttendance?.status === 'pending' && (
          <div className="flex gap-1" onClick={e => e.stopPropagation()}>
            <button
              onClick={() => onRespond(meeting.id, 'accepted')}
              className="p-1.5 bg-green-100 text-green-600 rounded-lg hover:bg-green-200"
              title="پذیرش"
            >
              <CheckCircle size={16} />
            </button>
            <button
              onClick={() => onRespond(meeting.id, 'declined')}
              className="p-1.5 bg-red-100 text-red-600 rounded-lg hover:bg-red-200"
              title="رد"
            >
              <XCircle size={16} />
            </button>
            <button
              onClick={() => onPropose(meeting)}
              className="p-1.5 bg-yellow-100 text-yellow-600 rounded-lg hover:bg-yellow-200"
              title="پیشنهاد زمان جدید"
            >
              <CalendarClock size={16} />
            </button>
          </div>
        )}
      </div>
    </div>
  )
}

function NewMeetingModal({ onClose, onSaved }: { onClose: () => void; onSaved: () => void }) {
  const [form, setForm] = useState({
    title: '',
    description: '',
    meeting_type: 'in_person' as MeetingType,
    start_time: '',
    end_time: '',
    location: '',
    online_link: '',
    agenda: '',
    attendee_ids: [] as string[],
  })
  const [users, setUsers] = useState<any[]>([])
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    usersApi.list().then(r => setUsers(r.data as any[])).catch(() => {})
  }, [])

  const save = async () => {
    if (!form.title.trim() || !form.start_time || !form.end_time) {
      return toast.error('عنوان، زمان شروع و پایان الزامی است')
    }
    setSaving(true)
    try {
      await meetingsApi.create({
        ...form,
        start_time: new Date(form.start_time).toISOString(),
        end_time: new Date(form.end_time).toISOString(),
      } as any)
      toast.success('جلسه ایجاد شد')
      onSaved()
    } catch (e: any) {
      toast.error(e.response?.data?.detail || 'خطا')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4" dir="rtl">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl flex flex-col max-h-[90vh]">
        <div className="flex items-center justify-between px-6 py-4 border-b">
          <h2 className="text-lg font-bold text-gray-900">جلسه جدید</h2>
          <button onClick={onClose} className="p-1.5 hover:bg-gray-100 rounded-lg">
            <XCircle size={18} className="text-gray-400" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">عنوان جلسه *</label>
            <input type="text" value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary-300"
              placeholder="عنوان جلسه" />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">نوع جلسه</label>
              <select value={form.meeting_type} onChange={e => setForm(f => ({ ...f, meeting_type: e.target.value as MeetingType }))}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary-300">
                <option value="in_person">حضوری</option>
                <option value="online">آنلاین</option>
                <option value="hybrid">ترکیبی</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">مکان / لینک</label>
              <input type="text"
                value={form.meeting_type === 'online' ? form.online_link : form.location}
                onChange={e => setForm(f => form.meeting_type === 'online'
                  ? { ...f, online_link: e.target.value }
                  : { ...f, location: e.target.value }
                )}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary-300"
                placeholder={form.meeting_type === 'online' ? 'لینک جلسه' : 'آدرس محل برگزاری'} />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">زمان شروع *</label>
              <input type="datetime-local" value={form.start_time}
                onChange={e => setForm(f => ({ ...f, start_time: e.target.value }))}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary-300" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">زمان پایان *</label>
              <input type="datetime-local" value={form.end_time}
                onChange={e => setForm(f => ({ ...f, end_time: e.target.value }))}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary-300" />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">دستور جلسه</label>
            <textarea value={form.agenda} onChange={e => setForm(f => ({ ...f, agenda: e.target.value }))}
              rows={3}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-primary-300"
              placeholder="موضوعات مورد بحث در جلسه" />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">شرکت‌کنندگان</label>
            <div className="border border-gray-200 rounded-lg p-3 max-h-40 overflow-y-auto space-y-1">
              {users.map((u: any) => (
                <label key={u.id} className="flex items-center gap-2 cursor-pointer hover:bg-gray-50 rounded px-1 py-0.5">
                  <input
                    type="checkbox"
                    checked={form.attendee_ids.includes(u.id)}
                    onChange={e => setForm(f => ({
                      ...f,
                      attendee_ids: e.target.checked
                        ? [...f.attendee_ids, u.id]
                        : f.attendee_ids.filter(id => id !== u.id)
                    }))}
                    className="rounded border-gray-300"
                  />
                  <span className="text-sm">{u.full_name}</span>
                  {u.position && <span className="text-xs text-gray-400">{u.position}</span>}
                </label>
              ))}
            </div>
          </div>
        </div>

        <div className="flex items-center justify-end gap-3 px-6 py-4 border-t bg-gray-50 rounded-b-2xl">
          <button onClick={onClose} className="text-sm text-gray-500 hover:text-gray-700 px-4 py-2">
            انصراف
          </button>
          <button onClick={save} disabled={saving}
            className="flex items-center gap-2 bg-primary-600 text-white px-5 py-2 rounded-lg text-sm hover:bg-primary-700 disabled:opacity-50">
            {saving ? <RefreshCw size={14} className="animate-spin" /> : <CalendarDays size={14} />}
            ایجاد جلسه
          </button>
        </div>
      </div>
    </div>
  )
}

function ProposeTimeModal({ meeting, onClose, onSaved }: {
  meeting: Meeting
  onClose: () => void
  onSaved: () => void
}) {
  const [startTime, setStartTime] = useState('')
  const [endTime, setEndTime] = useState('')
  const [note, setNote] = useState('')
  const [saving, setSaving] = useState(false)

  const save = async () => {
    if (!startTime || !endTime) return toast.error('زمان شروع و پایان الزامی است')
    if (new Date(endTime) <= new Date(startTime)) return toast.error('زمان پایان باید بعد از شروع باشد')
    setSaving(true)
    try {
      await meetingsApi.proposeTime(meeting.id, {
        start_time: new Date(startTime).toISOString(),
        end_time: new Date(endTime).toISOString(),
        note,
      })
      toast.success('پیشنهاد زمان ارسال شد')
      onSaved()
    } catch {
      toast.error('خطا در ارسال پیشنهاد')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4" dir="rtl">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md">
        <div className="flex items-center justify-between px-6 py-4 border-b">
          <h2 className="text-lg font-bold text-gray-900">پیشنهاد زمان جدید</h2>
          <button onClick={onClose} className="p-1.5 hover:bg-gray-100 rounded-lg">
            <XCircle size={18} className="text-gray-400" />
          </button>
        </div>
        <div className="p-6 space-y-4">
          <div className="bg-yellow-50 text-yellow-700 text-sm rounded-lg px-3 py-2">
            جلسه «{meeting.title}» — زمان فعلی: {new Date(meeting.start_time).toLocaleDateString('fa-IR')}
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">زمان شروع پیشنهادی *</label>
              <input type="datetime-local" value={startTime}
                onChange={e => setStartTime(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary-300" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">زمان پایان پیشنهادی *</label>
              <input type="datetime-local" value={endTime}
                onChange={e => setEndTime(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary-300" />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">توضیح (اختیاری)</label>
            <textarea value={note} onChange={e => setNote(e.target.value)} rows={2}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-primary-300"
              placeholder="دلیل پیشنهاد زمان جدید" />
          </div>
        </div>
        <div className="flex items-center justify-end gap-3 px-6 py-4 border-t bg-gray-50 rounded-b-2xl">
          <button onClick={onClose} className="text-sm text-gray-500 hover:text-gray-700">انصراف</button>
          <button onClick={save} disabled={saving}
            className="flex items-center gap-2 bg-yellow-500 text-white px-5 py-2 rounded-lg text-sm hover:bg-yellow-600 disabled:opacity-50">
            {saving ? <RefreshCw size={14} className="animate-spin" /> : <CalendarClock size={14} />}
            ارسال پیشنهاد
          </button>
        </div>
      </div>
    </div>
  )
}

function MeetingDetailModal({ meeting, onClose, onMinutes, onAcceptProposal, onRefresh }: {
  meeting: Meeting
  onClose: () => void
  onMinutes: () => void
  onAcceptProposal?: (userId: string) => void
  onRefresh?: () => void
}) {
  const { user } = useAuthStore()
  const TypeIcon = TYPE_ICONS[meeting.meeting_type]
  const start = new Date(meeting.start_time)
  const end = new Date(meeting.end_time)
  const isOrganizer = meeting.organizer_id === user?.id

  return (
    <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4" dir="rtl">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg max-h-[85vh] flex flex-col">
        <div className="flex items-center justify-between px-6 py-4 border-b">
          <h2 className="text-lg font-bold text-gray-900">{meeting.title}</h2>
          <button onClick={onClose} className="p-1.5 hover:bg-gray-100 rounded-lg">
            <XCircle size={18} className="text-gray-400" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          <div className="flex items-center gap-2">
            <TypeIcon size={16} className="text-primary-500" />
            <span className="text-sm text-gray-600">
              {meeting.meeting_type === 'in_person' ? 'حضوری' : meeting.meeting_type === 'online' ? 'آنلاین' : 'ترکیبی'}
            </span>
            <span className={clsx('text-xs px-2 py-0.5 rounded-full', STATUS_COLORS[meeting.status])}>
              {STATUS_LABELS[meeting.status]}
            </span>
          </div>

          <div className="bg-gray-50 rounded-lg p-3 space-y-2 text-sm">
            <div className="flex items-center gap-2 text-gray-700">
              <Clock size={14} className="text-gray-400" />
              <span>{start.toLocaleDateString('fa-IR')} از ساعت {start.toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })} تا {end.toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })}</span>
            </div>
            {meeting.location && (
              <div className="flex items-center gap-2 text-gray-700">
                <MapPin size={14} className="text-gray-400" />
                <span>{meeting.location}</span>
              </div>
            )}
            {meeting.online_link && (
              <div className="flex items-center gap-2 text-gray-700">
                <Video size={14} className="text-gray-400" />
                <a href={meeting.online_link} target="_blank" rel="noreferrer" className="text-primary-600 hover:underline">
                  {meeting.online_link}
                </a>
              </div>
            )}
          </div>

          {meeting.agenda && (
            <div>
              <h4 className="font-medium text-sm text-gray-700 mb-1">دستور جلسه</h4>
              <p className="text-sm text-gray-600 whitespace-pre-wrap">{meeting.agenda}</p>
            </div>
          )}

          <div>
            <h4 className="font-medium text-sm text-gray-700 mb-2">شرکت‌کنندگان ({meeting.attendees?.length || 0} نفر)</h4>
            <div className="space-y-1">
              {meeting.attendees?.map((a, i) => (
                <div key={i} className="flex items-center justify-between py-1">
                  <span className="text-sm">{a.full_name || a.user_id}</span>
                  <span className={clsx('text-xs font-medium', ATTENDEE_COLORS[a.status as AttendeeStatus])}>
                    {ATTENDEE_LABELS[a.status as AttendeeStatus]}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {isOrganizer && meeting.proposed_times?.length > 0 && (
            <div>
              <h4 className="font-medium text-sm text-yellow-700 mb-2 flex items-center gap-1">
                <CalendarClock size={14} />
                پیشنهادات زمان جدید ({meeting.proposed_times.length})
              </h4>
              <div className="space-y-2">
                {meeting.proposed_times.map((p, i) => {
                  const attendee = meeting.attendees?.find(a => a.user_id === p.user_id)
                  return (
                    <div key={i} className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <p className="text-sm font-medium text-gray-800">{attendee?.full_name || p.user_id}</p>
                          <p className="text-xs text-gray-600 mt-0.5">
                            {new Date(p.start_time).toLocaleDateString('fa-IR')} ·{' '}
                            {new Date(p.start_time).toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })}
                            {' - '}
                            {new Date(p.end_time).toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })}
                          </p>
                          {p.note && <p className="text-xs text-gray-500 mt-1">{p.note}</p>}
                        </div>
                        <button
                          onClick={() => onAcceptProposal?.(p.user_id)}
                          className="shrink-0 text-xs bg-green-100 text-green-700 hover:bg-green-200 px-2 py-1 rounded-lg font-medium"
                        >
                          قبول
                        </button>
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>
          )}
        </div>

        {isOrganizer && meeting.status === 'scheduled' && (
          <div className="px-6 py-4 border-t bg-gray-50 rounded-b-2xl">
            <button onClick={onMinutes}
              className="flex items-center gap-2 bg-primary-600 text-white px-4 py-2 rounded-lg text-sm hover:bg-primary-700 w-full justify-center">
              <FileText size={14} />
              ثبت صورت‌جلسه
            </button>
          </div>
        )}
      </div>
    </div>
  )
}

export default function Meetings() {
  const [meetings, setMeetings] = useState<Meeting[]>([])
  const [loading, setLoading] = useState(true)
  const [showNew, setShowNew] = useState(false)
  const [selected, setSelected] = useState<Meeting | null>(null)
  const [proposing, setProposing] = useState<Meeting | null>(null)
  const [filter, setFilter] = useState<'all' | 'upcoming'>('upcoming')

  const load = () => {
    setLoading(true)
    meetingsApi.list({ upcoming: filter === 'upcoming' })
      .then(r => setMeetings(r.data))
      .catch(() => toast.error('خطا در دریافت جلسات'))
      .finally(() => setLoading(false))
  }

  useEffect(() => { load() }, [filter])

  const handleRespond = async (id: string, status: AttendeeStatus) => {
    try {
      await meetingsApi.respond(id, status)
      toast.success(status === 'accepted' ? 'حضور شما ثبت شد' : 'عدم حضور شما ثبت شد')
      load()
    } catch {
      toast.error('خطا')
    }
  }

  const handleSelectMeeting = async (m: Meeting) => {
    try {
      const res = await meetingsApi.get(m.id)
      setSelected(res.data)
    } catch {
      setSelected(m)
    }
  }

  const handleAcceptProposal = async (userId: string) => {
    if (!selected) return
    try {
      await meetingsApi.acceptProposedTime(selected.id, userId)
      toast.success('زمان جدید اعمال شد و شرکت‌کنندگان دوباره دعوت شدند')
      setSelected(null)
      load()
    } catch {
      toast.error('خطا در اعمال زمان پیشنهادی')
    }
  }

  return (
    <div className="p-6 max-w-4xl mx-auto" dir="rtl">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <CalendarDays size={24} className="text-primary-600" />
          <h1 className="text-2xl font-bold text-gray-900">جلسات</h1>
        </div>
        <button
          onClick={() => setShowNew(true)}
          className="flex items-center gap-2 bg-primary-600 text-white px-4 py-2 rounded-lg text-sm hover:bg-primary-700"
        >
          <Plus size={15} />
          جلسه جدید
        </button>
      </div>

      <div className="flex gap-2 mb-4">
        {(['upcoming', 'all'] as const).map(f => (
          <button key={f} onClick={() => setFilter(f)}
            className={clsx(
              'px-3 py-1.5 rounded-lg text-sm font-medium transition-colors',
              filter === f ? 'bg-primary-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            )}>
            {f === 'upcoming' ? 'آینده' : 'همه'}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="flex justify-center py-16">
          <RefreshCw size={28} className="animate-spin text-primary-400" />
        </div>
      ) : meetings.length === 0 ? (
        <div className="text-center py-16 text-gray-400">
          <CalendarDays size={56} className="mx-auto mb-4 opacity-20" />
          <p>جلسه‌ای یافت نشد</p>
        </div>
      ) : (
        <div className="space-y-3">
          {meetings.map(m => (
            <MeetingCard
              key={m.id}
              meeting={m}
              onRespond={handleRespond}
              onSelect={handleSelectMeeting}
              onPropose={setProposing}
            />
          ))}
        </div>
      )}

      {showNew && (
        <NewMeetingModal
          onClose={() => setShowNew(false)}
          onSaved={() => { setShowNew(false); load() }}
        />
      )}

      {selected && (
        <MeetingDetailModal
          meeting={selected}
          onClose={() => setSelected(null)}
          onMinutes={() => {}}
          onAcceptProposal={handleAcceptProposal}
          onRefresh={load}
        />
      )}

      {proposing && (
        <ProposeTimeModal
          meeting={proposing}
          onClose={() => setProposing(null)}
          onSaved={() => { setProposing(null); load() }}
        />
      )}
    </div>
  )
}
