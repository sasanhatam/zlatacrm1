import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { kartablApi, KartablItem, KartablCounts } from '@/api/kartabl'
import { companiesApi } from '@/api/companies'
import { Company } from '@/types/common'
import { useAuthStore } from '@/store/authStore'
import {
  CheckSquare, FileText, Send, AlertTriangle, Mail,
  Clock, RefreshCw, SortAsc,
} from 'lucide-react'
import clsx from 'clsx'
import toast from 'react-hot-toast'

const TYPE_FILTERS = [
  { value: 'all', label: 'همه' },
  { value: 'tasks', label: 'تسک‌ها' },
  { value: 'letters', label: 'نامه‌ها' },
  { value: 'referrals', label: 'ارجاعات' },
]

const SORT_OPTIONS = [
  { value: 'date', label: 'تاریخ' },
  { value: 'priority', label: 'اولویت' },
  { value: 'status', label: 'وضعیت' },
]

const STATUS_FILTERS = [
  { value: 'all', label: 'همه' },
  { value: 'pending', label: 'انجام نشده' },
  { value: 'done', label: 'انجام شده' },
]

const PRIORITY_LABELS: Record<string, { label: string; cls: string }> = {
  urgent: { label: 'فوری', cls: 'bg-red-100 text-red-700' },
  high: { label: 'بالا', cls: 'bg-orange-100 text-orange-700' },
  medium: { label: 'متوسط', cls: 'bg-yellow-100 text-yellow-700' },
  normal: { label: 'عادی', cls: 'bg-blue-100 text-blue-700' },
  low: { label: 'کم', cls: 'bg-gray-100 text-gray-600' },
}

const TYPE_ICONS: Record<string, React.ReactNode> = {
  task: <CheckSquare size={16} className="text-blue-500" />,
  letter: <FileText size={16} className="text-green-500" />,
  referral: <Send size={16} className="text-purple-500" />,
}

const TYPE_LABELS: Record<string, string> = {
  task: 'تسک',
  letter: 'نامه',
  referral: 'ارجاع',
}

function ItemCard({ item, onClick }: { item: KartablItem; onClick: () => void }) {
  const prio = PRIORITY_LABELS[item.priority] || PRIORITY_LABELS['normal']
  const dateStr = item.date ? new Date(item.date).toLocaleDateString('fa-IR') : ''
  const dueDateStr = item.due_date ? new Date(item.due_date).toLocaleDateString('fa-IR') : ''

  return (
    <div
      onClick={onClick}
      className={clsx(
        'bg-white border rounded-xl p-4 cursor-pointer hover:shadow-md transition-all group',
        !item.is_read ? 'border-primary-300 border-r-4' : 'border-gray-200',
        item.is_overdue && 'ring-1 ring-red-300'
      )}
    >
      <div className="flex items-start gap-3">
        <div className="mt-0.5 flex-shrink-0">{TYPE_ICONS[item.item_type]}</div>
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2 mb-1">
            <h4 className={clsx(
              'text-sm font-semibold line-clamp-2 group-hover:text-primary-600',
              !item.is_read ? 'text-gray-900' : 'text-gray-700'
            )}>
              {item.title}
            </h4>
            <span className={clsx('text-xs font-medium px-2 py-0.5 rounded-full flex-shrink-0', prio.cls)}>
              {prio.label}
            </span>
          </div>

          <div className="flex items-center gap-3 text-xs text-gray-500 flex-wrap">
            <span className="bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full">
              {TYPE_LABELS[item.item_type]}
            </span>
            {item.sender_name && <span>از: {item.sender_name}</span>}
            <span className="flex items-center gap-1">
              <Clock size={11} />
              {dateStr}
            </span>
            {item.is_overdue && (
              <span className="flex items-center gap-1 text-red-600 font-medium">
                <AlertTriangle size={11} />
                سررسید گذشته ({dueDateStr})
              </span>
            )}
            {item.due_date && !item.is_overdue && (
              <span className="text-gray-400">سررسید: {dueDateStr}</span>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

export default function Kartabl() {
  const [items, setItems] = useState<KartablItem[]>([])
  const [counts, setCounts] = useState<KartablCounts | null>(null)
  const [companies, setCompanies] = useState<Company[]>([])
  const [loading, setLoading] = useState(true)
  const [typeFilter, setTypeFilter] = useState('all')
  const [sortBy, setSortBy] = useState('date')
  const [statusFilter, setStatusFilter] = useState('all')
  const [companyFilter, setCompanyFilter] = useState('')
  const { user } = useAuthStore()
  const navigate = useNavigate()

  const isMultiCompany = (user?.organization_ids?.length ?? 0) > 1

  useEffect(() => {
    if (isMultiCompany) {
      companiesApi.list().then(r => setCompanies(r.data)).catch(() => {})
    }
  }, [isMultiCompany])

  useEffect(() => {
    setLoading(true)
    kartablApi.list({
      type: typeFilter,
      sort: sortBy,
      status: statusFilter,
      company_id: companyFilter || undefined,
    })
      .then(r => {
        setItems(r.data.items)
        setCounts(r.data.counts)
      })
      .catch(() => toast.error('خطا در بارگذاری کارتابل'))
      .finally(() => setLoading(false))
  }, [typeFilter, sortBy, statusFilter, companyFilter])

  const handleItemClick = (item: KartablItem) => {
    if (item.item_type === 'task') {
      navigate(`/tasks/${item.id}`)
    } else if (item.item_type === 'letter') {
      navigate(`/letters?id=${item.id}`)
    } else if (item.item_type === 'referral') {
      navigate(`/letters?ref=${item.id}`)
    }
  }

  return (
    <div className="h-full flex flex-col" dir="rtl">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">کارتابل</h1>
          <p className="text-sm text-gray-500 mt-1">مرکز یکپارچه مدیریت وظایف، نامه‌ها و ارجاعات</p>
        </div>
        <button
          onClick={() => {
            setLoading(true)
            kartablApi.list({ type: typeFilter, sort: sortBy, status: statusFilter })
              .then(r => { setItems(r.data.items); setCounts(r.data.counts) })
              .catch(() => toast.error('خطا در بارگذاری'))
              .finally(() => setLoading(false))
          }}
          className="p-2 rounded-lg hover:bg-gray-100 text-gray-500 transition-colors"
          title="بروزرسانی"
        >
          <RefreshCw size={18} />
        </button>
      </div>

      {/* Stats row */}
      {counts && (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 mb-6">
          {[
            { label: 'کل', value: counts.total, cls: 'bg-gray-50 text-gray-700' },
            { label: 'تسک‌ها', value: counts.tasks, cls: 'bg-blue-50 text-blue-700' },
            { label: 'نامه‌ها', value: counts.letters, cls: 'bg-green-50 text-green-700' },
            { label: 'ارجاعات', value: counts.referrals, cls: 'bg-purple-50 text-purple-700' },
            { label: 'خوانده نشده', value: counts.unread, cls: 'bg-yellow-50 text-yellow-700' },
            { label: 'سررسید گذشته', value: counts.overdue, cls: 'bg-red-50 text-red-700' },
          ].map(stat => (
            <div key={stat.label} className={clsx('rounded-xl p-3 text-center', stat.cls)}>
              <div className="text-2xl font-bold">{stat.value}</div>
              <div className="text-xs mt-0.5">{stat.label}</div>
            </div>
          ))}
        </div>
      )}

      {/* Filters */}
      <div className="flex flex-wrap gap-3 mb-4">
        {/* Type chips */}
        <div className="flex gap-1 bg-gray-100 rounded-lg p-1">
          {TYPE_FILTERS.map(f => (
            <button
              key={f.value}
              onClick={() => setTypeFilter(f.value)}
              className={clsx(
                'px-3 py-1.5 rounded-md text-sm font-medium transition-colors',
                typeFilter === f.value ? 'bg-white shadow-sm text-primary-600' : 'text-gray-600 hover:text-gray-800'
              )}
            >
              {f.label}
            </button>
          ))}
        </div>

        {/* Status chips */}
        <div className="flex gap-1 bg-gray-100 rounded-lg p-1">
          {STATUS_FILTERS.map(f => (
            <button
              key={f.value}
              onClick={() => setStatusFilter(f.value)}
              className={clsx(
                'px-3 py-1.5 rounded-md text-sm font-medium transition-colors',
                statusFilter === f.value ? 'bg-white shadow-sm text-primary-600' : 'text-gray-600 hover:text-gray-800'
              )}
            >
              {f.label}
            </button>
          ))}
        </div>

        {/* Sort dropdown */}
        <div className="flex items-center gap-2">
          <SortAsc size={16} className="text-gray-500" />
          <select
            value={sortBy}
            onChange={e => setSortBy(e.target.value)}
            className="input-field w-auto text-sm py-1.5"
          >
            {SORT_OPTIONS.map(o => (
              <option key={o.value} value={o.value}>{o.label}</option>
            ))}
          </select>
        </div>

        {/* Company filter */}
        {isMultiCompany && companies.length > 0 && (
          <div className="flex gap-1 bg-gray-100 rounded-lg p-1">
            <button
              onClick={() => setCompanyFilter('')}
              className={clsx(
                'px-3 py-1.5 rounded-md text-sm font-medium transition-colors',
                companyFilter === '' ? 'bg-white shadow-sm text-primary-600' : 'text-gray-600 hover:text-gray-800'
              )}
            >
              همه شرکت‌ها
            </button>
            {companies
              .filter(c => user?.organization_ids?.includes(c.id))
              .map(c => (
                <button
                  key={c.id}
                  onClick={() => setCompanyFilter(c.id)}
                  className={clsx(
                    'px-3 py-1.5 rounded-md text-sm font-medium transition-colors',
                    companyFilter === c.id ? 'bg-white shadow-sm text-primary-600' : 'text-gray-600 hover:text-gray-800'
                  )}
                >
                  {c.name}
                </button>
              ))}
          </div>
        )}
      </div>

      {/* Items list */}
      {loading ? (
        <div className="flex items-center justify-center h-64">
          <div className="w-8 h-8 border-4 border-primary-500 border-t-transparent rounded-full animate-spin" />
        </div>
      ) : items.length === 0 ? (
        <div className="flex flex-col items-center justify-center h-64 text-gray-400">
          <Mail size={48} className="mb-3 opacity-30" />
          <p className="text-lg font-medium">کارتابل خالی است</p>
          <p className="text-sm mt-1">هیچ آیتمی با فیلترهای انتخابی یافت نشد</p>
        </div>
      ) : (
        <div className="space-y-3 flex-1 overflow-y-auto">
          {items.map(item => (
            <ItemCard key={`${item.item_type}-${item.id}`} item={item} onClick={() => handleItemClick(item)} />
          ))}
        </div>
      )}
    </div>
  )
}
