import { useState, useEffect } from 'react'
import { Send, RefreshCw, FileText } from 'lucide-react'
import { lettersApi, Letter, LetterStatus, LetterType } from '@/api/letters'
import toast from 'react-hot-toast'
import clsx from 'clsx'

const STATUS_LABELS: Record<LetterStatus, string> = {
  draft: 'پیش‌نویس', pending: 'در انتظار', approved: 'تأیید شده',
  sent: 'ارسال شده', archived: 'بایگانی', rejected: 'رد شده',
}
const STATUS_COLORS: Record<LetterStatus, string> = {
  draft: 'bg-gray-100 text-gray-700', pending: 'bg-yellow-100 text-yellow-700',
  approved: 'bg-green-100 text-green-700', sent: 'bg-blue-100 text-blue-700',
  archived: 'bg-purple-100 text-purple-700', rejected: 'bg-red-100 text-red-700',
}
const TYPE_LABELS: Record<LetterType, string> = {
  outgoing: 'صادره', incoming: 'وارده', internal: 'داخلی',
}

export default function OutboxPage() {
  const [letters, setLetters] = useState<Letter[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    setLoading(true)
    lettersApi.outbox()
      .then(r => setLetters(r.data))
      .catch(() => toast.error('خطا در دریافت کارتابل'))
      .finally(() => setLoading(false))
  }, [])

  return (
    <div className="p-6 max-w-4xl mx-auto" dir="rtl">
      <div className="flex items-center gap-3 mb-6">
        <Send size={24} className="text-primary-600" />
        <h1 className="text-2xl font-bold text-gray-900">کارتابل خروجی</h1>
        <span className="bg-primary-100 text-primary-700 text-sm px-2 py-0.5 rounded-full">
          {letters.length} نامه
        </span>
      </div>

      {loading ? (
        <div className="flex justify-center py-16">
          <RefreshCw size={28} className="animate-spin text-primary-400" />
        </div>
      ) : letters.length === 0 ? (
        <div className="text-center py-16 text-gray-400">
          <Send size={56} className="mx-auto mb-4 opacity-20" />
          <p>کارتابل خروجی خالی است</p>
        </div>
      ) : (
        <div className="space-y-2">
          {letters.map(letter => (
            <div
              key={letter.id}
              className="bg-white rounded-xl border border-gray-100 p-4 hover:border-primary-200 hover:shadow-sm transition-all cursor-pointer"
            >
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1">
                  <h3 className="font-semibold text-gray-900 mb-1">{letter.subject}</h3>
                  <div className="flex items-center gap-2 text-sm text-gray-500">
                    <span>{TYPE_LABELS[letter.letter_type]}</span>
                    {letter.letter_number && <span className="font-mono">· {letter.letter_number}</span>}
                    {letter.recipient_name && <span>· به: {letter.recipient_name}</span>}
                    {letter.jalali_date && <span>· {letter.jalali_date}</span>}
                  </div>
                </div>
                <span className={clsx('text-xs px-2 py-1 rounded-full font-medium shrink-0', STATUS_COLORS[letter.status])}>
                  {STATUS_LABELS[letter.status]}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
