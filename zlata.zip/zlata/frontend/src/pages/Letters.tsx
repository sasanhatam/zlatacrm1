import { useState, useEffect } from 'react'
import {
  FileText, Plus, Send, Archive, CheckCircle, XCircle, Clock,
  Eye, Inbox, AlertTriangle, RefreshCw, RotateCcw, Edit2, Trash2,
  ChevronDown, ChevronUp, MessageSquare, GitBranch, Printer, Stamp,
  PenLine,
} from 'lucide-react'
import { lettersApi, Letter, LetterStatus, LetterType, LetterReferral, ReferralAction } from '@/api/letters'
import { useAuthStore } from '@/store/authStore'
import api from '@/api/client'
import toast from 'react-hot-toast'
import clsx from 'clsx'
import { usersApi } from '@/api/users'
import { companiesApi } from '@/api/companies'
import { Company } from '@/types/common'
import LetterPrintView from '@/components/letters/LetterPrintView'
import { LetterEditor } from '@/components/letters/LetterEditor'
import { JalaliDatePicker } from '@/components/common/JalaliDatePicker'

// Today's Jalali date helper
function todayJalali(): string {
  const now = new Date()
  const gy = now.getFullYear(), gm = now.getMonth() + 1, gd = now.getDate()
  const g_d_no = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
  if (gy > 1600) {
    const gyAdj = gy - 1600
    let g_day_no = 365 * gyAdj + Math.floor((gyAdj + 3) / 4) - Math.floor((gyAdj + 99) / 100) + Math.floor((gyAdj + 399) / 400)
    for (let i = 0; i < gm - 1; i++) g_day_no += g_d_no[i]
    if (gm > 2 && ((gyAdj + 1) % 4 === 0 && ((gyAdj + 1) % 100 !== 0 || (gyAdj + 1) % 400 === 0))) g_day_no++
    g_day_no += gd - 1
    let j_day_no = g_day_no - 79
    const j_np = Math.floor(j_day_no / 12053); j_day_no %= 12053
    let jy = 979 + 33 * j_np + 4 * Math.floor(j_day_no / 1461); j_day_no %= 1461
    if (j_day_no >= 366) { jy += Math.floor((j_day_no - 1) / 365); j_day_no = (j_day_no - 1) % 365 }
    const j_d_no_arr = [31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29]
    let jm = 0, jd = 0, i = 0
    for (; i < 11 && j_day_no >= j_d_no_arr[i]; i++) j_day_no -= j_d_no_arr[i]
    jm = i + 1; jd = j_day_no + 1
    const toPersian = (n: number | string) => String(n).replace(/[0-9]/g, d => '۰۱۲۳۴۵۶۷۸۹'[+d])
    return `${toPersian(jy)}/${toPersian(String(jm).padStart(2, '0'))}/${toPersian(String(jd).padStart(2, '0'))}`
  }
  return new Date().toLocaleDateString('fa-IR')
}

const STATUS_LABELS: Record<LetterStatus, string> = {
  draft: 'پیش‌نویس',
  pending: 'در انتظار تأیید',
  approved: 'تأیید شده',
  sent: 'ارسال شده',
  archived: 'بایگانی',
  rejected: 'رد شده',
}

const STATUS_COLORS: Record<LetterStatus, string> = {
  draft: 'bg-gray-100 text-gray-700',
  pending: 'bg-yellow-100 text-yellow-700',
  approved: 'bg-green-100 text-green-700',
  sent: 'bg-blue-100 text-blue-700',
  archived: 'bg-purple-100 text-purple-700',
  rejected: 'bg-red-100 text-red-700',
}

const TYPE_LABELS: Record<LetterType, string> = {
  outgoing: 'صادره',
  incoming: 'وارده',
  internal: 'داخلی',
}

const TYPE_COLORS: Record<LetterType, string> = {
  outgoing: 'bg-blue-50 text-blue-700',
  incoming: 'bg-green-50 text-green-700',
  internal: 'bg-purple-50 text-purple-700',
}

const PRIORITY_LABELS: Record<string, string> = {
  normal: 'عادی', urgent: 'فوری', very_urgent: 'خیلی فوری', confidential: 'محرمانه'
}

const ACTION_LABELS: Record<ReferralAction, string> = {
  for_action: 'جهت اقدام',
  for_info: 'جهت اطلاع',
  for_response: 'جهت پاسخ',
  for_review: 'جهت بررسی',
  for_archive: 'جهت بایگانی',
}

type Tab = 'all' | 'drafts' | 'pending' | 'inbox' | 'outbox'

function LetterDetail({
  letter, onClose, onAction, onReload, onEdit, onRevision,
}: {
  letter: Letter
  onClose: () => void
  onAction: (action: string, letter: Letter) => Promise<void>
  onReload: () => void
  onEdit: (letter: any) => void
  onRevision: (letter: any) => void
}) {
  const { user } = useAuthStore()
  const isManager = user?.role === 'super_admin' || user?.role === 'manager'
  const isCEO = user?.role === 'super_admin'
  const isMine = letter.sender_id === user?.id
  const [referrals, setReferrals] = useState<LetterReferral[]>([])
  const [comments, setComments] = useState<any[]>([])
  const [showReferral, setShowReferral] = useState(false)
  const [showComment, setShowComment] = useState(false)
  const [commentText, setCommentText] = useState('')
  const [referralData, setReferralData] = useState({ to_user_id: '', action: 'for_action' as ReferralAction, note: '' })
  const [users, setUsers] = useState<any[]>([])
  const [tab, setTab] = useState<'body' | 'referrals' | 'comments'>('body')
  const [printData, setPrintData] = useState<{ letter: any; letterhead: any } | null>(null)
  const [stampLoading, setStampLoading] = useState(false)
  const [letterDetail, setLetterDetail] = useState<any>(letter)

  useEffect(() => {
    lettersApi.getReferrals(letter.id).then(r => setReferrals(r.data)).catch(() => {})
    lettersApi.getComments(letter.id).then(r => setComments(r.data)).catch(() => {})
    usersApi.list().then(r => setUsers(r.data as any[])).catch(() => {})
    // Load detailed letter with user names
    api.get(`/letters/${letter.id}`).then(r => setLetterDetail(r.data)).catch(() => {})
  }, [letter.id])

  const submitReferral = async () => {
    if (!referralData.to_user_id) return toast.error('گیرنده را انتخاب کنید')
    try {
      await lettersApi.refer(letter.id, referralData as any)
      toast.success('نامه ارجاع داده شد')
      setShowReferral(false)
      lettersApi.getReferrals(letter.id).then(r => setReferrals(r.data))
    } catch (e: any) {
      toast.error(e.response?.data?.detail || 'خطا')
    }
  }

  const handlePrint = async () => {
    try {
      const res = await api.get(`/letters/${letter.id}/print-data`)
      setPrintData(res.data)
    } catch {
      toast.error('خطا در دریافت اطلاعات پرینت')
    }
  }

  const handleStamp = async () => {
    setStampLoading(true)
    try {
      if ((letter as any).is_stamped) {
        await api.delete(`/letters/${letter.id}/stamp`)
        toast.success('مهر برداشته شد')
      } else {
        await api.post(`/letters/${letter.id}/stamp`)
        toast.success('نامه مهر شد')
      }
      onReload()
    } catch (e: any) {
      toast.error(e.response?.data?.detail || 'خطا در مهر')
    } finally {
      setStampLoading(false)
    }
  }

  const handleSignAndStamp = async () => {
    setStampLoading(true)
    try {
      await api.post(`/letters/${letter.id}/sign-and-stamp`)
      toast.success('مهر و امضا با موفقیت اعمال شد')
      onReload()
    } catch (e: any) {
      toast.error(e.response?.data?.detail || 'خطا در مهر و امضا')
    } finally {
      setStampLoading(false)
    }
  }

  const submitComment = async () => {
    if (!commentText.trim()) return
    try {
      await lettersApi.addComment(letter.id, commentText)
      toast.success('یادداشت ثبت شد')
      setCommentText('')
      setShowComment(false)
      lettersApi.getComments(letter.id).then(r => setComments(r.data))
    } catch {
      toast.error('خطا در ثبت یادداشت')
    }
  }

  return (
    <div className="flex flex-col h-full bg-white">
      {/* Header */}
      <div className="flex items-center justify-between px-6 py-4 border-b border-gray-200 bg-gray-50">
        <button onClick={onClose} className="p-1.5 hover:bg-gray-200 rounded-lg transition-colors">
          <XCircle size={18} className="text-gray-500" />
        </button>
        <div className="flex items-center gap-2 flex-wrap justify-end">
          {isMine && (letter.status === 'draft' || letter.status === 'rejected') && (
            <button onClick={() => onEdit(letterDetail)}
              className="flex items-center gap-1.5 bg-blue-500 text-white px-3 py-1.5 rounded-lg text-xs hover:bg-blue-600">
              <Edit2 size={13} /> ویرایش
            </button>
          )}
          {isMine && (letter.status === 'approved' || letter.status === 'sent' || letter.status === 'archived') && (
            <button onClick={() => onRevision(letterDetail)}
              className="flex items-center gap-1.5 bg-teal-600 text-white px-3 py-1.5 rounded-lg text-xs hover:bg-teal-700">
              <RotateCcw size={13} /> بازنگری
            </button>
          )}
          {isMine && letter.status === 'draft' && (
            <button onClick={() => onAction('submit', letter)}
              className="flex items-center gap-1.5 bg-yellow-500 text-white px-3 py-1.5 rounded-lg text-xs hover:bg-yellow-600">
              <Send size={13} /> ارسال برای تأیید
            </button>
          )}
          {isManager && letter.status === 'pending' && (
            <>
              <button onClick={() => onAction('approve', letter)}
                className="flex items-center gap-1.5 bg-green-600 text-white px-3 py-1.5 rounded-lg text-xs hover:bg-green-700">
                <CheckCircle size={13} /> تأیید
              </button>
              <button onClick={() => onAction('reject', letter)}
                className="flex items-center gap-1.5 bg-red-500 text-white px-3 py-1.5 rounded-lg text-xs hover:bg-red-600">
                <XCircle size={13} /> رد
              </button>
            </>
          )}
          {isMine && letter.status === 'approved' && (
            <button onClick={() => onAction('send', letter)}
              className="flex items-center gap-1.5 bg-blue-600 text-white px-3 py-1.5 rounded-lg text-xs hover:bg-blue-700">
              <Send size={13} /> ارسال نهایی
            </button>
          )}
          {letter.status === 'sent' && (
            <button onClick={() => onAction('archive', letter)}
              className="flex items-center gap-1.5 bg-purple-600 text-white px-3 py-1.5 rounded-lg text-xs hover:bg-purple-700">
              <Archive size={13} /> بایگانی
            </button>
          )}
          <button onClick={() => setShowReferral(!showReferral)}
            className="flex items-center gap-1.5 bg-orange-500 text-white px-3 py-1.5 rounded-lg text-xs hover:bg-orange-600">
            <GitBranch size={13} /> ارجاع
          </button>
          {isMine && letter.status === 'draft' && (
            <button onClick={() => onAction('delete', letter)}
              className="flex items-center gap-1.5 bg-gray-100 text-gray-600 px-3 py-1.5 rounded-lg text-xs hover:bg-gray-200">
              <Trash2 size={13} /> حذف
            </button>
          )}
          {isManager && (letter.status === 'approved' || letter.status === 'sent') && (
            <>
              <button onClick={handleStamp} disabled={stampLoading}
                className={clsx(
                  'flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs transition-colors',
                  (letter as any).is_stamped
                    ? 'bg-amber-100 text-amber-700 hover:bg-amber-200'
                    : 'bg-amber-600 text-white hover:bg-amber-700'
                )}>
                <Stamp size={13} />{(letter as any).is_stamped ? 'برداشتن مهر' : 'مهر کردن'}
              </button>
              <button onClick={handleSignAndStamp} disabled={stampLoading}
                className="flex items-center gap-1.5 bg-indigo-600 text-white px-3 py-1.5 rounded-lg text-xs hover:bg-indigo-700 transition-colors">
                <PenLine size={13} /> مهر و امضا
              </button>
            </>
          )}
          <button onClick={handlePrint}
            className="flex items-center gap-1.5 bg-gray-700 text-white px-3 py-1.5 rounded-lg text-xs hover:bg-gray-800 transition-colors">
            <Printer size={13} /> پرینت / PDF
          </button>
        </div>
      </div>

      {/* Print overlay */}
      {printData && (
        <LetterPrintView
          letter={printData.letter}
          letterhead={printData.letterhead}
          onClose={() => setPrintData(null)}
        />
      )}

      {/* Status bar */}
      <div className="flex items-center gap-3 px-6 py-2 border-b border-gray-100 bg-white flex-wrap">
        <span className={clsx('text-xs px-2.5 py-1 rounded-full font-medium', STATUS_COLORS[letter.status])}>
          {STATUS_LABELS[letter.status]}
        </span>
        <span className={clsx('text-xs px-2 py-0.5 rounded', TYPE_COLORS[letter.letter_type])}>
          نامه {TYPE_LABELS[letter.letter_type]}
        </span>
        <span className="text-xs text-gray-400 font-medium">{PRIORITY_LABELS[letter.priority] || ''}</span>
        {(letter as any).is_stamped && (
          <span className="text-xs bg-amber-100 text-amber-700 px-2 py-0.5 rounded-full font-medium flex items-center gap-1">
            <Stamp size={10} /> ممهور
          </span>
        )}
        {(letter as any).signature_applied && (
          <span className="text-xs bg-indigo-100 text-indigo-700 px-2 py-0.5 rounded-full font-medium flex items-center gap-1">
            <PenLine size={10} /> امضا شده
          </span>
        )}
        {letter.letter_number && (
          <span className="text-xs text-gray-500 font-mono mr-auto">شماره: {letter.letter_number}</span>
        )}
      </div>

      {/* Referral form */}
      {showReferral && (
        <div className="px-6 py-3 bg-orange-50 border-b border-orange-100">
          <p className="text-sm font-medium text-orange-800 mb-2">ارجاع نامه</p>
          <div className="flex gap-2 flex-wrap">
            <select
              value={referralData.to_user_id}
              onChange={e => setReferralData(d => ({ ...d, to_user_id: e.target.value }))}
              className="border border-gray-300 rounded-lg px-2 py-1.5 text-sm flex-1 min-w-32"
            >
              <option value="">انتخاب گیرنده</option>
              {users.map((u: any) => (
                <option key={u.id} value={u.id}>{u.full_name}</option>
              ))}
            </select>
            <select
              value={referralData.action}
              onChange={e => setReferralData(d => ({ ...d, action: e.target.value as ReferralAction }))}
              className="border border-gray-300 rounded-lg px-2 py-1.5 text-sm"
            >
              {Object.entries(ACTION_LABELS).map(([k, v]) => (
                <option key={k} value={k}>{v}</option>
              ))}
            </select>
            <input
              type="text"
              placeholder="یادداشت (اختیاری)"
              value={referralData.note}
              onChange={e => setReferralData(d => ({ ...d, note: e.target.value }))}
              className="border border-gray-300 rounded-lg px-2 py-1.5 text-sm flex-1 min-w-40"
            />
            <button onClick={submitReferral}
              className="bg-orange-600 text-white px-4 py-1.5 rounded-lg text-sm hover:bg-orange-700">
              ارجاع
            </button>
            <button onClick={() => setShowReferral(false)}
              className="text-sm text-gray-500 px-2 py-1.5 hover:text-gray-700">
              انصراف
            </button>
          </div>
        </div>
      )}

      {/* Tabs */}
      <div className="flex border-b border-gray-200 px-4">
        {[
          { key: 'body', label: 'متن نامه' },
          { key: 'referrals', label: `ارجاعات (${referrals.length})` },
          { key: 'comments', label: `یادداشت‌ها (${comments.length})` },
        ].map(t => (
          <button key={t.key}
            onClick={() => setTab(t.key as any)}
            className={clsx(
              'px-4 py-2.5 text-sm font-medium border-b-2 transition-colors',
              tab === t.key
                ? 'border-primary-500 text-primary-600'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            )}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-6">
        {tab === 'body' && (
          <div>
            <h2 className="text-xl font-bold text-gray-900 mb-4">{letter.subject}</h2>
            <div className="grid grid-cols-2 gap-4 mb-6 text-sm">
              <div><span className="text-gray-500">تاریخ: </span><span>{letter.jalali_date}</span></div>
              {letter.recipient_name && <div><span className="text-gray-500">گیرنده: </span><span>{letter.recipient_name}</span></div>}
              {letter.rejection_reason && (
                <div className="col-span-2 bg-red-50 rounded-lg p-3 text-red-700">
                  دلیل رد: {letter.rejection_reason}
                </div>
              )}
            </div>
            {letter.body.trim().startsWith('<') ? (
              <div
                className="rich-editor-content text-gray-800 bg-gray-50 rounded-xl p-6 border border-gray-100"
                dir="rtl"
                dangerouslySetInnerHTML={{ __html: letter.body }}
              />
            ) : (
              <div className="text-gray-800 leading-relaxed whitespace-pre-wrap bg-gray-50 rounded-xl p-6 border border-gray-100">
                {letter.body}
              </div>
            )}

            {/* Workflow roles grid */}
            {(letterDetail.signer_name || letterDetail.approved_by_name || letterDetail.requester_name || letterDetail.actor_name || letterDetail.dispatcher_name) && (
              <div className="mt-4 pt-4 border-t border-gray-100">
                <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-3">نقش‌های جریان کاری</p>
                <div className="grid grid-cols-2 gap-3 text-sm">
                  {letterDetail.requester_name && (
                    <div className="flex items-center gap-2 bg-blue-50 rounded-lg px-3 py-2">
                      <span className="text-blue-500 text-xs font-medium">درخواست‌دهنده</span>
                      <span className="font-medium text-gray-800">{letterDetail.requester_name}</span>
                    </div>
                  )}
                  {letterDetail.actor_name && (
                    <div className="flex items-center gap-2 bg-green-50 rounded-lg px-3 py-2">
                      <span className="text-green-600 text-xs font-medium">اجراکننده</span>
                      <span className="font-medium text-gray-800">{letterDetail.actor_name}</span>
                    </div>
                  )}
                  {letterDetail.signer_name && (
                    <div className="flex items-center gap-2 bg-purple-50 rounded-lg px-3 py-2">
                      <span className="text-purple-600 text-xs font-medium">امضاکننده</span>
                      <span className="font-medium text-gray-800">{letterDetail.signer_name}</span>
                      {letterDetail.signer_position && (
                        <span className="text-gray-400 text-xs">({letterDetail.signer_position})</span>
                      )}
                    </div>
                  )}
                  {letterDetail.dispatcher_name && (
                    <div className="flex items-center gap-2 bg-orange-50 rounded-lg px-3 py-2">
                      <span className="text-orange-600 text-xs font-medium">ارسال‌کننده</span>
                      <span className="font-medium text-gray-800">{letterDetail.dispatcher_name}</span>
                    </div>
                  )}
                  {letterDetail.approved_by_name && (
                    <div className="flex items-center gap-2 bg-teal-50 rounded-lg px-3 py-2">
                      <span className="text-teal-600 text-xs font-medium">تأییدکننده</span>
                      <span className="font-medium text-gray-800">{letterDetail.approved_by_name}</span>
                      {letterDetail.approved_by_position && (
                        <span className="text-gray-400 text-xs">({letterDetail.approved_by_position})</span>
                      )}
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        )}

        {tab === 'referrals' && (
          <div className="space-y-3">
            {referrals.length === 0 ? (
              <p className="text-gray-400 text-sm text-center py-8">هیچ ارجاعی ثبت نشده</p>
            ) : referrals.map(r => (
              <div key={r.id} className="flex items-start gap-3 p-3 bg-orange-50 rounded-xl border border-orange-100">
                <GitBranch size={16} className="text-orange-500 mt-0.5 shrink-0" />
                <div className="flex-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-medium text-sm">{r.from_user_name}</span>
                    <span className="text-gray-400 text-xs">→</span>
                    <span className="font-medium text-sm">{r.to_user_name}</span>
                    <span className="text-xs bg-orange-100 text-orange-700 px-2 py-0.5 rounded-full">
                      {ACTION_LABELS[r.action]}
                    </span>
                    {r.is_read && <span className="text-xs text-green-600">✓ خوانده شده</span>}
                  </div>
                  {r.note && <p className="text-sm text-gray-600 mt-1">{r.note}</p>}
                  <p className="text-xs text-gray-400 mt-1">
                    {new Date(r.created_at).toLocaleDateString('fa-IR')}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}

        {tab === 'comments' && (
          <div className="space-y-3">
            {comments.map((c: any) => (
              <div key={c.id} className={clsx('p-3 rounded-xl border', c.is_private ? 'bg-yellow-50 border-yellow-100' : 'bg-gray-50 border-gray-100')}>
                <div className="flex items-center gap-2 mb-1">
                  <span className="font-medium text-sm">{c.author_name}</span>
                  {c.is_private && <span className="text-xs bg-yellow-200 text-yellow-700 px-1.5 rounded">خصوصی</span>}
                  <span className="text-xs text-gray-400 mr-auto">
                    {new Date(c.created_at).toLocaleDateString('fa-IR')}
                  </span>
                </div>
                <p className="text-sm text-gray-700">{c.content}</p>
              </div>
            ))}

            <div className="mt-4 pt-4 border-t border-gray-100">
              {showComment ? (
                <div className="space-y-2">
                  <textarea
                    value={commentText}
                    onChange={e => setCommentText(e.target.value)}
                    placeholder="یادداشت خود را بنویسید..."
                    rows={3}
                    className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-primary-300"
                  />
                  <div className="flex gap-2">
                    <button onClick={submitComment}
                      className="bg-primary-600 text-white px-4 py-1.5 rounded-lg text-sm hover:bg-primary-700">
                      ثبت
                    </button>
                    <button onClick={() => setShowComment(false)}
                      className="text-sm text-gray-500 px-3 py-1.5 hover:text-gray-700">
                      انصراف
                    </button>
                  </div>
                </div>
              ) : (
                <button onClick={() => setShowComment(true)}
                  className="flex items-center gap-2 text-primary-600 text-sm hover:text-primary-700">
                  <Plus size={14} /> افزودن یادداشت
                </button>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

// Workflow badge
function WorkflowBadge({ status }: { status: LetterStatus }) {
  const steps: LetterStatus[] = ['draft', 'pending', 'approved', 'sent', 'archived']
  const currentIdx = steps.indexOf(status)

  if (status === 'rejected') {
    return (
      <div className="flex items-center gap-1 text-xs mt-2">
        <span className="text-red-500 font-medium">رد شده</span>
      </div>
    )
  }

  return (
    <div className="flex items-center gap-0.5 mt-2">
      {steps.map((s, i) => (
        <div key={s} className="flex items-center">
          <div className={clsx(
            'w-2 h-2 rounded-full',
            i < currentIdx ? 'bg-green-400' : i === currentIdx ? 'bg-primary-500' : 'bg-gray-200'
          )} />
          {i < steps.length - 1 && (
            <div className={clsx('w-4 h-0.5', i < currentIdx ? 'bg-green-400' : 'bg-gray-200')} />
          )}
        </div>
      ))}
    </div>
  )
}


function LetterCompose({
  onClose, onSaved, replyTo, editLetter, revisionOf,
}: {
  onClose: () => void
  onSaved: () => void
  replyTo?: Letter
  editLetter?: any
  revisionOf?: any
}) {
  const { user } = useAuthStore()
  const src = editLetter || revisionOf  // source for pre-filling
  const isEdit = !!editLetter
  const isRevision = !!revisionOf

  const [form, setForm] = useState({
    letter_type: src ? src.letter_type : (replyTo ? replyTo.letter_type : 'outgoing') as LetterType,
    subject: isEdit ? src.subject : isRevision ? `[بازنگری] ${src.subject}` : replyTo ? `پاسخ: ${replyTo.subject}` : '',
    body: src?.body || '',
    priority: src?.priority || 'normal',
    recipient_name: src?.recipient_name || '',
    jalali_date: isEdit ? (src.jalali_date || todayJalali()) : todayJalali(),
    letter_number: isEdit ? (src.letter_number || '') : '',
    requester_id: src?.requester_id || '',
    actor_id: src?.actor_id || '',
    signer_id: src?.signer_id || '',
    dispatcher_id: src?.dispatcher_id || '',
  })
  const [additionalSigners, setAdditionalSigners] = useState<string[]>(src?.additional_signer_ids || [])
  const [saving, setSaving] = useState(false)
  const [savingDraft, setSavingDraft] = useState(false)
  const [composeUsers, setComposeUsers] = useState<any[]>([])
  const [nextNumber, setNextNumber] = useState<string>('')
  const [showPreview, setShowPreview] = useState(false)
  const [companies, setCompanies] = useState<Company[]>([])
  const [selectedCompanyId, setSelectedCompanyId] = useState(src?.organization_id || '')

  useEffect(() => {
    usersApi.list().then(r => setComposeUsers(r.data as any[])).catch(() => {})
    companiesApi.list().then(r => {
      setCompanies(r.data)
      if (!src?.organization_id && user?.organization_ids?.length === 1) {
        setSelectedCompanyId(user.organization_ids[0])
      }
    }).catch(() => {})
  }, [])

  useEffect(() => {
    api.get('/letters/next-number', { params: { letter_type: form.letter_type } })
      .then((r: any) => setNextNumber(r.data.number))
      .catch(() => {})
  }, [form.letter_type])

  const buildPayload = () => {
    const payload: any = { ...form, additional_signer_ids: additionalSigners }
    if (!payload.letter_number) delete payload.letter_number
    if (!payload.requester_id) delete payload.requester_id
    if (!payload.actor_id) delete payload.actor_id
    if (!payload.signer_id) delete payload.signer_id
    if (!payload.dispatcher_id) delete payload.dispatcher_id
    if (selectedCompanyId) payload.organization_id = selectedCompanyId
    return payload
  }

  const save = async (submit = false) => {
    if (!form.subject.trim() || !form.body.trim()) {
      return toast.error('موضوع و متن نامه الزامی است')
    }

    setSaving(true)
    if (!submit) setSavingDraft(true)

    try {
      if (isEdit) {
        // Update existing draft/rejected letter
        await lettersApi.update(editLetter.id, buildPayload())
        if (submit) {
          await lettersApi.submit(editLetter.id)
          toast.success('نامه ویرایش و برای تأیید ارسال شد')
        } else {
          toast.success('تغییرات نامه ذخیره شد')
        }
      } else {
        // Create new (original or revision)
        const payload = buildPayload()
        if (isRevision) payload.reply_to_id = revisionOf.id
        const res = await lettersApi.create(payload)
        if (submit) {
          await lettersApi.submit(res.data.id)
          toast.success(isRevision ? 'بازنگری برای تأیید ارسال شد' : 'نامه برای تأیید ارسال شد')
        } else {
          toast.success(isRevision ? 'بازنگری به عنوان پیش‌نویس ذخیره شد' : 'پیش‌نویس ذخیره شد')
        }
      }
      onSaved()
    } catch (e: any) {
      toast.error(e.response?.data?.detail || 'خطا')
    } finally {
      setSaving(false)
      setSavingDraft(false)
    }
  }

  return (
    <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4" dir="rtl">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl flex flex-col max-h-[90vh]">
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
          <h2 className="text-lg font-bold text-gray-900">
          {isEdit ? 'ویرایش نامه' : isRevision ? 'بازنگری نامه' : 'نامه جدید'}
        </h2>
          <button onClick={onClose} className="p-1.5 hover:bg-gray-100 rounded-lg">
            <XCircle size={18} className="text-gray-400" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {/* Company selector — only for users in multiple companies */}
          {companies.length > 1 && (user?.organization_ids?.length ?? 0) > 1 && (
            <div className="bg-blue-50 border border-blue-100 rounded-xl p-3">
              <label className="block text-xs font-semibold text-blue-700 mb-2">سربرگ نامه — شرکت</label>
              <div className="flex gap-3">
                {companies
                  .filter(c => user?.organization_ids?.includes(c.id))
                  .map(c => (
                    <label key={c.id} className="flex items-center gap-2 cursor-pointer">
                      <input type="radio" name="compose_company"
                        value={c.id}
                        checked={selectedCompanyId === c.id}
                        onChange={() => setSelectedCompanyId(c.id)}
                        className="text-primary-600" />
                      <span className="text-sm font-medium text-gray-700">{c.name}</span>
                    </label>
                  ))
                }
              </div>
            </div>
          )}

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">نوع نامه</label>
              <select
                value={form.letter_type}
                onChange={e => setForm(f => ({ ...f, letter_type: e.target.value as LetterType }))}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary-300"
              >
                <option value="outgoing">صادره</option>
                <option value="incoming">وارده</option>
                <option value="internal">داخلی</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">اولویت</label>
              <select
                value={form.priority}
                onChange={e => setForm(f => ({ ...f, priority: e.target.value }))}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary-300"
              >
                <option value="normal">عادی</option>
                <option value="urgent">فوری</option>
                <option value="very_urgent">خیلی فوری</option>
                <option value="confidential">محرمانه</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">گیرنده</label>
            <input
              type="text"
              placeholder="نام گیرنده یا سازمان"
              value={form.recipient_name}
              onChange={e => setForm(f => ({ ...f, recipient_name: e.target.value }))}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary-300"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">موضوع *</label>
            <input
              type="text"
              placeholder="موضوع نامه را وارد کنید"
              value={form.subject}
              onChange={e => setForm(f => ({ ...f, subject: e.target.value }))}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary-300"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">تاریخ نامه</label>
              <JalaliDatePicker
                value={form.jalali_date}
                onChange={v => setForm(f => ({ ...f, jalali_date: v }))}
                placeholder="تاریخ نامه"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">شماره نامه (اختیاری)</label>
              <div className="relative">
                <input
                  type="text"
                  placeholder={nextNumber ? `خودکار: ${nextNumber}` : 'خودکار شماره‌گذاری می‌شود'}
                  value={form.letter_number}
                  onChange={e => setForm(f => ({ ...f, letter_number: e.target.value }))}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary-300"
                  dir="ltr"
                />
                {nextNumber && !form.letter_number && (
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs text-gray-400 pointer-events-none">{nextNumber}</span>
                )}
              </div>
            </div>
          </div>

          {/* Workflow roles */}
          <div className="border border-gray-100 rounded-xl p-4 bg-gray-50 space-y-3">
            <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide">نقش‌های جریان کاری</p>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">درخواست‌دهنده</label>
                <select
                  value={form.requester_id}
                  onChange={e => setForm(f => ({ ...f, requester_id: e.target.value }))}
                  className="w-full border border-gray-300 rounded-lg px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary-300"
                >
                  <option value="">انتخاب کنید</option>
                  {composeUsers.map((u: any) => (
                    <option key={u.id} value={u.id}>{u.full_name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">اقدام‌کننده</label>
                <select
                  value={form.actor_id}
                  onChange={e => setForm(f => ({ ...f, actor_id: e.target.value }))}
                  className="w-full border border-gray-300 rounded-lg px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary-300"
                >
                  <option value="">انتخاب کنید</option>
                  {composeUsers.map((u: any) => (
                    <option key={u.id} value={u.id}>{u.full_name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">امضاکننده اول</label>
                <select
                  value={form.signer_id}
                  onChange={e => setForm(f => ({ ...f, signer_id: e.target.value }))}
                  className="w-full border border-gray-300 rounded-lg px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary-300"
                >
                  <option value="">انتخاب کنید</option>
                  {composeUsers.map((u: any) => (
                    <option key={u.id} value={u.id}>{u.full_name}</option>
                  ))}
                </select>
              </div>
              <div className="col-span-2">
                <label className="block text-xs font-medium text-gray-600 mb-1">امضاکنندگان اضافی (چند نفر)</label>
                <div className="border border-gray-300 rounded-lg p-2 space-y-1 max-h-28 overflow-y-auto">
                  {composeUsers.filter((u: any) => u.id !== form.signer_id).map((u: any) => (
                    <label key={u.id} className="flex items-center gap-2 text-sm cursor-pointer hover:bg-gray-50 px-1 rounded">
                      <input
                        type="checkbox"
                        checked={additionalSigners.includes(u.id)}
                        onChange={e => setAdditionalSigners(prev =>
                          e.target.checked ? [...prev, u.id] : prev.filter(id => id !== u.id)
                        )}
                        className="rounded"
                      />
                      <span>{u.full_name}</span>
                      {u.position && <span className="text-xs text-gray-400">({u.position})</span>}
                    </label>
                  ))}
                </div>
                {additionalSigners.length > 0 && (
                  <p className="text-xs text-primary-600 mt-1">{additionalSigners.length} نفر انتخاب شده</p>
                )}
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">ارسال‌کننده</label>
                <select
                  value={form.dispatcher_id}
                  onChange={e => setForm(f => ({ ...f, dispatcher_id: e.target.value }))}
                  className="w-full border border-gray-300 rounded-lg px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary-300"
                >
                  <option value="">انتخاب کنید</option>
                  {composeUsers.map((u: any) => (
                    <option key={u.id} value={u.id}>{u.full_name}</option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">متن نامه *</label>
            <LetterEditor value={form.body} onChange={v => setForm(f => ({ ...f, body: v }))} />
          </div>
        </div>

        <div className="flex items-center justify-between px-6 py-4 border-t border-gray-100 bg-gray-50 rounded-b-2xl">
          <button onClick={onClose} className="text-sm text-gray-500 hover:text-gray-700">
            انصراف
          </button>
          <div className="flex gap-2">
            {!isEdit && (
              <button
                onClick={() => save(false)}
                disabled={savingDraft}
                className="flex items-center gap-2 border border-gray-300 bg-white text-gray-700 px-4 py-2 rounded-lg text-sm hover:bg-gray-50 disabled:opacity-50"
              >
                {savingDraft ? <RefreshCw size={14} className="animate-spin" /> : <Edit2 size={14} />}
                {isRevision ? 'ذخیره بازنگری' : 'ذخیره پیش‌نویس'}
              </button>
            )}
            <button
              onClick={() => {
                if (!form.subject.trim() || !form.body.trim()) {
                  return toast.error('موضوع و متن نامه الزامی است')
                }
                setShowPreview(true)
              }}
              className="flex items-center gap-2 border border-primary-300 bg-primary-50 text-primary-700 px-4 py-2 rounded-lg text-sm hover:bg-primary-100"
            >
              <Eye size={14} />
              پیش‌نمایش
            </button>
            <button
              onClick={() => save(true)}
              disabled={saving}
              className="flex items-center gap-2 bg-primary-600 text-white px-4 py-2 rounded-lg text-sm hover:bg-primary-700 disabled:opacity-50"
            >
              {saving ? <RefreshCw size={14} className="animate-spin" /> : <Send size={14} />}
              {isEdit ? 'ذخیره و ارسال برای تأیید' : isRevision ? 'ارسال بازنگری برای تأیید' : 'ارسال برای تأیید'}
            </button>
          </div>
        </div>
      </div>

      {/* Full A4 Letter Preview */}
      {showPreview && (() => {
        const co = companies.find(c => c.id === selectedCompanyId)
        const signer = composeUsers.find((u: any) => u.id === form.signer_id)
        const previewLetter = {
          id: '',
          letter_number: form.letter_number || nextNumber,
          letter_type: form.letter_type,
          status: 'draft',
          priority: form.priority,
          subject: form.subject,
          body: form.body,
          jalali_date: form.jalali_date,
          letter_date: new Date().toISOString(),
          recipient_name: form.recipient_name,
          recipient_organization: '',
          recipient_department: '',
          sender_name: user?.full_name || '',
          sender_position: user?.position || '',
          sender_signature: null,
          signer_name: signer?.full_name || '',
          signer_position: signer?.position || '',
          signer_signature: null,
          signer_stamp: null,
          additional_signers: additionalSigners
            .map((id: string) => composeUsers.find((u: any) => u.id === id))
            .filter(Boolean)
            .map((u: any) => ({ id: u.id, full_name: u.full_name, position: u.position || '', signature: null, stamp: null })),
          is_stamped: false,
          stamped_by_name: '',
          archive_code: null,
        }
        const previewLetterhead = {
          org_name: co?.name || 'شرکت',
          org_name_en: co?.official_name || '',
          address: co?.address || '',
          phone: co?.phone || '',
          fax: '',
          postal_code: '',
          website: co?.website || '',
          email: '',
          reg_number: '',
          logo_data: null,
          stamp_data: null,
          footer_text: '',
          color: '#1e3a5f',
          secondary_color: '#2d6a9f',
          letterhead_header_data: co?.letterhead_header_data || null,
          letterhead_footer_data: co?.letterhead_footer_data || null,
        }
        return (
          <div className="z-[70] fixed inset-0">
            <LetterPrintView
              letter={previewLetter}
              letterhead={previewLetterhead}
              onClose={() => setShowPreview(false)}
              extraActions={
                <button
                  onClick={() => { setShowPreview(false); save(true) }}
                  disabled={saving}
                  className="flex items-center gap-2 bg-green-600 hover:bg-green-700 px-4 py-2 rounded-lg text-sm font-medium transition-colors disabled:opacity-50"
                >
                  {saving ? <RefreshCw size={14} className="animate-spin" /> : <Send size={14} />}
                  ارسال برای تأیید
                </button>
              }
            />
          </div>
        )
      })()}
    </div>
  )
}

export default function Letters() {
  const { user } = useAuthStore()
  const isManager = user?.role === 'super_admin' || user?.role === 'manager'

  const [tab, setTab] = useState<Tab>('all')
  const [letters, setLetters] = useState<Letter[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedLetter, setSelectedLetter] = useState<Letter | null>(null)
  const [showCompose, setShowCompose] = useState(false)
  const [editLetter, setEditLetter] = useState<any>(null)
  const [revisionOf, setRevisionOf] = useState<any>(null)
  const [filterType, setFilterType] = useState<LetterType | ''>('')

  const loadLetters = async () => {
    setLoading(true)
    try {
      let res
      if (tab === 'drafts') res = await lettersApi.drafts()
      else if (tab === 'pending') res = await lettersApi.pendingApproval()
      else if (tab === 'inbox') res = await lettersApi.inbox()
      else if (tab === 'outbox') res = await lettersApi.outbox()
      else res = await lettersApi.list(filterType ? { letter_type: filterType as LetterType } : {})
      setLetters(res.data)
    } catch {
      toast.error('خطا در دریافت نامه‌ها')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { loadLetters() }, [tab, filterType])

  const handleAction = async (action: string, letter: Letter) => {
    try {
      if (action === 'submit') {
        await lettersApi.submit(letter.id)
        toast.success('نامه برای تأیید ارسال شد')
      } else if (action === 'approve') {
        await lettersApi.approve(letter.id)
        toast.success('نامه تأیید و شماره‌گذاری شد')
      } else if (action === 'reject') {
        const reason = window.prompt('دلیل رد نامه را وارد کنید:')
        if (reason === null) return
        await lettersApi.reject(letter.id, reason)
        toast.success('نامه رد شد')
      } else if (action === 'send') {
        await lettersApi.send(letter.id)
        toast.success('نامه ارسال شد')
      } else if (action === 'archive') {
        await lettersApi.archive(letter.id)
        toast.success('نامه بایگانی شد')
      } else if (action === 'delete') {
        if (!confirm('آیا از حذف این نامه مطمئن هستید؟')) return
        await lettersApi.delete(letter.id)
        toast.success('نامه حذف شد')
        setSelectedLetter(null)
      }
      await loadLetters()
      if (action !== 'delete' && selectedLetter?.id === letter.id) {
        const updated = await lettersApi.get(letter.id)
        setSelectedLetter(updated.data)
      }
    } catch (e: any) {
      toast.error(e.response?.data?.detail || 'خطا در انجام عملیات')
    }
  }

  const tabs = [
    { key: 'all' as Tab, label: 'همه', icon: FileText },
    { key: 'drafts' as Tab, label: 'پیش‌نویس', icon: Clock },
    { key: 'inbox' as Tab, label: 'ورودی', icon: Inbox },
    { key: 'outbox' as Tab, label: 'خروجی', icon: Send },
    ...(isManager ? [{ key: 'pending' as Tab, label: 'تأیید', icon: AlertTriangle }] : []),
  ]

  return (
    <div className="flex h-full" dir="rtl">
      {/* Left panel: letter list */}
      <div className={clsx(
        'flex flex-col bg-white border-l border-gray-200 transition-all',
        selectedLetter ? 'w-96' : 'flex-1'
      )}>
        {/* Header */}
        <div className="p-4 border-b border-gray-200">
          <div className="flex items-center justify-between mb-3">
            <h1 className="text-lg font-bold text-gray-900 flex items-center gap-2">
              <FileText size={20} className="text-primary-600" />
              اتوماسیون اداری
            </h1>
            <button
              onClick={() => setShowCompose(true)}
              className="flex items-center gap-1.5 bg-primary-600 text-white px-3 py-1.5 rounded-lg text-sm hover:bg-primary-700 transition-colors"
            >
              <Plus size={15} />
              نامه جدید
            </button>
          </div>

          {/* Tabs */}
          <div className="flex gap-1 flex-wrap">
            {tabs.map(t => (
              <button key={t.key} onClick={() => setTab(t.key)}
                className={clsx(
                  'flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-medium transition-colors',
                  tab === t.key ? 'bg-primary-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                )}>
                <t.icon size={12} />{t.label}
              </button>
            ))}
          </div>

          {/* Type filter */}
          {tab === 'all' && (
            <div className="flex gap-1 mt-2">
              {(['', 'outgoing', 'incoming', 'internal'] as const).map(type => (
                <button key={type} onClick={() => setFilterType(type as any)}
                  className={clsx(
                    'px-2 py-0.5 rounded-full text-xs border transition-colors',
                    filterType === type
                      ? 'bg-primary-600 text-white border-primary-600'
                      : 'bg-white text-gray-500 border-gray-200 hover:border-primary-300'
                  )}>
                  {type === '' ? 'همه' : TYPE_LABELS[type as LetterType]}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* List */}
        <div className="flex-1 overflow-y-auto divide-y divide-gray-50">
          {loading ? (
            <div className="flex items-center justify-center py-16">
              <RefreshCw size={28} className="animate-spin text-primary-400" />
            </div>
          ) : letters.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-gray-400">
              <FileText size={48} className="mb-3 opacity-20" />
              <p className="text-sm">نامه‌ای یافت نشد</p>
            </div>
          ) : letters.map(letter => (
            <div
              key={letter.id}
              onClick={() => setSelectedLetter(letter)}
              className={clsx(
                'p-4 cursor-pointer hover:bg-gray-50 transition-colors',
                selectedLetter?.id === letter.id && 'bg-primary-50 border-r-2 border-primary-500'
              )}
            >
              <div className="flex items-start justify-between gap-2">
                <h3 className="font-medium text-gray-900 text-sm line-clamp-1 flex-1">
                  {letter.subject}
                </h3>
                <span className={clsx('text-xs px-1.5 py-0.5 rounded-full font-medium shrink-0', STATUS_COLORS[letter.status])}>
                  {STATUS_LABELS[letter.status]}
                </span>
              </div>
              <div className="flex items-center gap-2 mt-1.5">
                <span className={clsx('text-xs px-1.5 py-0.5 rounded', TYPE_COLORS[letter.letter_type])}>
                  {TYPE_LABELS[letter.letter_type]}
                </span>
                {letter.letter_number && (
                  <span className="text-xs text-gray-400 font-mono">{letter.letter_number}</span>
                )}
                {letter.is_referred && (
                  <span className="text-xs bg-orange-100 text-orange-600 px-1.5 py-0.5 rounded">
                    ارجاع شده
                  </span>
                )}
              </div>
              {letter.jalali_date && (
                <p className="text-xs text-gray-400 mt-1">{letter.jalali_date}</p>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Right panel: letter detail */}
      {selectedLetter && (
        <div className="flex-1 overflow-hidden flex flex-col border-r border-gray-200">
          <LetterDetail
            letter={selectedLetter}
            onClose={() => setSelectedLetter(null)}
            onAction={handleAction}
            onReload={loadLetters}
            onEdit={letter => { setEditLetter(letter); setSelectedLetter(null) }}
            onRevision={letter => { setRevisionOf(letter); setSelectedLetter(null) }}
          />
        </div>
      )}

      {(showCompose || editLetter || revisionOf) && (
        <LetterCompose
          onClose={() => { setShowCompose(false); setEditLetter(null); setRevisionOf(null) }}
          onSaved={async () => {
            setShowCompose(false); setEditLetter(null); setRevisionOf(null)
            await loadLetters()
          }}
          editLetter={editLetter || undefined}
          revisionOf={revisionOf || undefined}
        />
      )}
    </div>
  )
}
