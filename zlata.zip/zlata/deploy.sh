#!/usr/bin/env bash
# دیپلوی / آپدیت Zlata Management روی VPS با Docker Compose
set -euo pipefail

if [ -z "${DOMAIN:-}" ]; then
  echo "Error: DOMAIN env var not set. Example: export DOMAIN=zlata.example.com"
  exit 1
fi

if [ ! -f backend/.env ]; then
  echo "Error: backend/.env not found. Copy backend/.env.example to backend/.env and fill in real secrets first."
  exit 1
fi

echo "==> Pulling latest images / rebuilding..."
docker compose -f docker-compose.prod.yml build

echo "==> Starting stack for domain: $DOMAIN"
docker compose -f docker-compose.prod.yml up -d

echo "==> Status:"
docker compose -f docker-compose.prod.yml ps

echo "==> Done. Tail logs with: docker compose -f docker-compose.prod.yml logs -f"
