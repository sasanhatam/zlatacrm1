# Zlata Management — سیستم مدیریت پروژه و سازمان

سیستم جامع مدیریت پروژه، تسک، چت، نامه‌نگاری و اعلانات سازمانی با رابط کاربری فارسی RTL.

---

## ویژگی‌های کلیدی

| ماژول | قابلیت‌ها |
|-------|-----------|
| **احراز هویت** | JWT + Refresh Token، رمز bcrypt، RBAC چهار سطحی |
| **مدیریت تسک** | Kanban + لیست، زیرتسک، چک‌لیست، audit log، فایل پیوست، کامنت با منشن |
| **چت** | WebSocket، چت مستقیم و گروهی، ارسال فایل، read receipt |
| **اعلانات** | نوتیفیکیشن realtime، بنر اطلاعیه، Web Push روی موبایل |
| **نامه‌نگاری** | شماره‌گذاری خودکار جلالی، PDF با فونت فارسی، آرشیو |
| **داشبورد** | نمودار Recharts، عملکرد کاربر، خروجی Excel |
| **ریمایندر** | Celery Beat، ایمیل ۲۴h/1h پیش از ددلاین، تسک‌های معوق |
| **دفتر تلفن** | جستجو و فیلتر تیمی |
| **PWA** | نصب روی موبایل، کارکرد آفلاین، Web Push |

---

## راه‌اندازی سریع با Docker

### پیش‌نیازها
- Docker 24+
- Docker Compose 2+

### مراحل

```bash
# ۱. کلون مخزن
git clone <repo-url>
cd zlata-management

# ۲. تنظیم متغیرهای محیطی
cp backend/.env.example backend/.env
# فایل backend/.env را ویرایش کنید (مخصوصاً SMTP و SECRET_KEY)

# ۳. راه‌اندازی سرویس‌ها
docker compose up -d --build

# ۴. بارگذاری داده‌های نمونه (اولین بار)
docker compose exec api python scripts/seed_data.py

# ۵. دسترسی
#   Frontend:  http://localhost
#   API Docs:  http://localhost:8000/api/docs
#   Admin:     admin@zlata.ir / Admin@12345
```

### سرویس‌های Docker

| سرویس | پورت | توضیح |
|--------|------|-------|
| frontend | 80 | React PWA + Nginx |
| api | 8000 | FastAPI |
| mongo | 27017 | MongoDB |
| redis | 6379 | Redis |
| worker | — | Celery Worker |
| beat | — | Celery Beat |

---

## نصب روی سرور فیزیکی داخلی شرکت (شبکه داخلی / LAN، بدون نیاز به اینترنت)

این حالت برای وقتی است که می‌خواهید پروژه فقط روی شبکه داخلی شرکت در دسترس باشد — کاربران نیازی به نصب چیزی روی کامپیوتر خودشان ندارند، فقط با مرورگر به آدرس داخلی سرور وصل می‌شوند.

### پیش‌نیاز روی سرور ویندوزی
1. **Docker Desktop** را از [docker.com](https://www.docker.com/products/docker-desktop) نصب کنید (در ویندوز با WSL2 — نصب‌کننده خودش راهنمایی می‌کند).
2. Git برای ویندوز را نصب کنید: [git-scm.com](https://git-scm.com/download/win)
3. در PowerShell IP داخلی سرور را پیدا کنید تا بعداً برای کاربران بفرستید:
   ```powershell
   ipconfig
   # دنبال IPv4 Address زیر آداپتور شبکه (مثلاً 192.168.1.50) بگردید
   ```

### مراحل نصب (در PowerShell، روی همان سرور)

```powershell
git clone https://github.com/sasanhatam/zlataautomation.git
cd zlataautomation

copy backend\.env.example backend\.env
notepad backend\.env
```

داخل `backend\.env` این مقادیر را تنظیم کنید (به‌جای `192.168.1.50` آی‌پی واقعی سرور خودتان را بگذارید):

```env
DEBUG=false
SECRET_KEY=<یک رشته رندوم قوی — با دستور پایین بسازید>
JWT_SECRET_KEY=<یک رشته رندوم دیگر>
ALLOWED_ORIGINS=["http://192.168.1.50"]
SMTP_USERNAME=...   (اگر ایمیل می‌خواهید، در غیر این صورت دست نزنید)
```

برای ساخت رشته‌های رندوم امن (اگر Python نصب است):
```powershell
python -c "import secrets; print(secrets.token_urlsafe(48))"
```

سپس استک را بالا بیاورید:

```powershell
docker compose -f docker-compose.lan.yml up -d --build
docker compose -f docker-compose.lan.yml exec api python scripts/seed_data.py   # فقط بار اول، اختیاری
```

### دسترسی کاربران شبکه داخلی
به هر کاربر همین آدرس را بدهید (نیازی به نصب چیزی نیست، فقط مرورگر):
```
http://192.168.1.50
```
ورود پیش‌فرض ادمین: `admin@zlata.ir` / `Admin@12345`

> توجه: روی این حالت HTTPS نداریم (چون Let's Encrypt برای گرفتن گواهی به اینترنت نیاز دارد). برای شبکه داخلی امن این طبیعی و معمول است؛ وقتی به اینترنت وصل‌اش کنید (بخش بعدی) HTTPS خودکار فعال می‌شود.

### آپدیت بعدی
```powershell
git pull
docker compose -f docker-compose.lan.yml up -d --build
```

---

## مرحله بعد: بردن همین سرور به اینترنت (بدون خرید سرور جدا)

چون IP اینترنتی شرکت **ثابت** است و به روتر هم دسترسی دارید، نیازی به خرید VPS یا سرور جدا نیست — همین سرور فیزیکی را پشت یک دامنه روی اینترنت قابل دسترس می‌کنید. داده‌ها (Mongo، فایل‌ها) هم چون نام volume ها در `docker-compose.lan.yml` و `docker-compose.prod.yml` یکی است، حفظ می‌مانند.

### مراحل

1. **یک دامنه بخرید/داشته باشید** (مثل `app.yourcompany.com`) و در پنل DNS آن یک رکورد `A` به IP اینترنتی ثابت شرکت بسازید.
2. **روی روتر شرکت** پورت‌فورواردی بسازید که ترافیک ورودی پورت‌های `80` و `443` را به IP داخلی همین سرور (مثلاً `192.168.1.50`) هدایت کند.
3. روی سرور، استک LAN را متوقف کنید (چون پورت 80 را Caddy می‌خواهد) و استک production را با Caddy بالا بیاورید:
   ```powershell
   docker compose -f docker-compose.lan.yml down
   $env:DOMAIN = "app.yourcompany.com"
   docker compose -f docker-compose.prod.yml up -d --build
   ```
4. در `backend\.env`، `ALLOWED_ORIGINS` را به‌روزرسانی کنید:
   ```env
   ALLOWED_ORIGINS=["https://app.yourcompany.com"]
   ```
5. بعد از چند ثانیه Caddy خودش گواهی SSL رایگان از Let's Encrypt می‌گیرد و سایت روی `https://app.yourcompany.com` بالا می‌آید — هم از داخل شرکت و هم از هرجای دنیا.

> اگر بعداً خواستید دوباره برگردید به حالت فقط-داخلی، کافی‌ست `docker-compose.prod.yml` را `down` کنید و `docker-compose.lan.yml` را `up` کنید — داده‌ها همان‌جا هستند.

---

## دیپلوی Production روی VPS (در صورتی که از سرور داخلی استفاده نمی‌کنید)

این روش کل استک (frontend + backend + mongo + redis + celery) را پشت **Caddy** با HTTPS خودکار (Let's Encrypt) روی دامنه شما بالا می‌آورد.

### پیش‌نیازها
- یک VPS با Docker 24+ و Docker Compose 2+ نصب‌شده
- یک دامنه که `A record` آن به IP سرور اشاره کند (مثلاً `app.example.com`)
- پورت‌های 80 و 443 باز باشند

### مراحل

```bash
# ۱. کلون مخزن روی سرور
git clone <repo-url>
cd zlata-management

# ۲. تنظیم env بک‌اند با مقادیر واقعی production
cp backend/.env.example backend/.env
nano backend/.env
#   - SECRET_KEY / JWT_SECRET_KEY: مقادیر رندوم قوی بسازید
#     python3 -c "import secrets; print(secrets.token_urlsafe(48))"
#   - ALLOWED_ORIGINS: دامنه واقعی‌تان (مثل ["https://app.example.com"])
#   - SMTP_* : اطلاعات Gmail App Password
#   - DEBUG=false

# ۳. ست کردن دامنه برای Caddy و اجرا
export DOMAIN=app.example.com
./deploy.sh

# ۴. بارگذاری داده نمونه (فقط بار اول، اختیاری)
docker compose -f docker-compose.prod.yml exec api python scripts/seed_data.py
```

بعد از چند ثانیه، Caddy گواهی SSL را خودکار از Let's Encrypt می‌گیرد و سایت روی `https://app.example.com` بالا می‌آید.

### آپدیت بعدی (هر بار تغییر کد)

```bash
git pull
export DOMAIN=app.example.com
./deploy.sh
```

### نکات امنیتی این استک
- پورت‌های Mongo (27017) و Redis (6379) در `docker-compose.prod.yml` به هاست منتشر نمی‌شوند — فقط بین کانتینرها در دسترس‌اند.
- `api` با `--reload` اجرا نمی‌شود و حجم‌ کد را mount نمی‌کند (که فقط برای dev مناسب بود).
- تمام ترافیک HTTP به HTTPS ریدایرکت می‌شود (پیش‌فرض Caddy).

---

## دیپلوی فرانت‌اند روی Netlify (اختیاری — وقتی بک‌اند جای دیگری اجراست)

اگر ترجیح می‌دهید فقط فرانت روی Netlify باشد و بک‌اند را جدا (مثلاً همین VPS، بدون بخش frontend از کامپوز) اجرا کنید:

1. بک‌اند را طبق بخش بالا (بدون سرویس `frontend`) روی VPS بالا بیاورید و یک دامنه/ساب‌دامنه برای آن بگذارید (مثلاً `api.example.com`) — یا با `docker-compose.prod.yml` کامل بالا بیاورید و همان دامنه اصلی را برای API هم استفاده کنید.
2. مخزن را به Netlify وصل کنید؛ تنظیمات build از `netlify.toml` در ریشه پروژه خوانده می‌شود (base: `frontend`, publish: `frontend/dist`).
3. در Netlify → **Site settings → Environment variables** این متغیر را ست کنید:
   ```
   VITE_API_BASE_URL=https://api.example.com
   ```
4. در `backend/.env` سرور، دامنه Netlify را به `ALLOWED_ORIGINS` اضافه کنید:
   ```
   ALLOWED_ORIGINS=["https://your-site.netlify.app"]
   ```
5. Deploy کنید. فرانت روی Netlify مستقیماً (نه از طریق nginx پراکسی) به API و WebSocket روی دامنه بک‌اند وصل می‌شود — این رفتار را فایل [frontend/src/config.ts](frontend/src/config.ts) مدیریت می‌کند.

> توجه: Netlify نمی‌تواند FastAPI + MongoDB + Redis + Celery + WebSocket را میزبانی کند — فقط برای استاتیک/فرانت مناسب است؛ بک‌اند همیشه باید جای دیگری (VPS/Railway/Render) اجرا شود.

---

## تنظیم Gmail App Password

برای ارسال ایمیل از Gmail باید App Password بسازید:

1. به [Google Account](https://myaccount.google.com) بروید
2. **Security** → **2-Step Verification** را فعال کنید
3. **App Passwords** را باز کنید
4. نوع برنامه: **Mail** | دستگاه: **Other** → نام `Zlata`
5. رمز ۱۶ کاراکتری را در `backend/.env` قرار دهید:

```env
SMTP_USERNAME=youremail@gmail.com
SMTP_PASSWORD=xxxx xxxx xxxx xxxx
SMTP_FROM_EMAIL=youremail@gmail.com
```

---

## تنظیمات S3 (آروان/لیارا/MinIO)

```env
STORAGE_BACKEND=s3
S3_ENDPOINT_URL=https://s3.ir-thr-at1.arvanstorage.ir
S3_ACCESS_KEY=your-access-key
S3_SECRET_KEY=your-secret-key
S3_BUCKET_NAME=zlata-files
```

در محیط dev با `STORAGE_BACKEND=local` فایل‌ها در `/app/media` ذخیره می‌شوند.

---

## متغیرهای مهم `.env`

| متغیر | توضیح | پیش‌فرض |
|--------|--------|---------|
| `SECRET_KEY` | کلید رمزنگاری اپ — **تغییر الزامی** | — |
| `JWT_SECRET_KEY` | کلید JWT — **تغییر الزامی** | — |
| `MONGO_URL` | آدرس MongoDB | mongodb://mongo:27017 |
| `SMTP_USERNAME` | ایمیل Gmail سیستم | — |
| `SMTP_PASSWORD` | App Password جیمیل | — |
| `STORAGE_BACKEND` | `local` یا `s3` | local |
| `VAPID_PUBLIC_KEY` | کلید Web Push | — |

---

## اجرای تست‌ها

```bash
# نصب وابستگی‌ها
cd backend
pip install -r requirements.txt

# اجرای تست‌ها
pytest tests/ -v
```

---

## ساختار پروژه

```
zlata-management/
├── backend/          # FastAPI + Beanie + Celery
│   ├── app/
│   │   ├── models/   # Beanie Document models
│   │   ├── routers/  # FastAPI endpoints
│   │   ├── services/ # Business logic
│   │   ├── email/    # Email Provider pattern
│   │   ├── storage/  # S3/Local storage
│   │   └── workers/  # Celery tasks
│   └── tests/        # pytest
├── frontend/         # React + TypeScript + Vite + Tailwind
│   └── src/
│       ├── api/      # Axios API clients
│       ├── store/    # Zustand state
│       ├── pages/    # Page components
│       └── hooks/    # Custom React hooks
├── docker-compose.yml
└── nginx.conf
```

---

## نقش‌های کاربری

| نقش | دسترسی |
|-----|---------|
| `super_admin` | کنترل کامل + تنظیمات SMTP |
| `manager` | مدیریت تیم‌ها + داشبورد |
| `team_lead` | مدیریت تسک‌های تیم |
| `member` | تسک‌ها + چت + نامه |

---

## کاربران پیش‌فرض (Seed)

| ایمیل | رمز | نقش |
|-------|-----|-----|
| admin@zlata.ir | Admin@12345 | Super Admin |
| manager@zlata.ir | Pass@1234 | Manager |
| lead@zlata.ir | Pass@1234 | Team Lead |
| ali@zlata.ir | Pass@1234 | Member |
| sara@zlata.ir | Pass@1234 | Member |

---

## توسعه محلی (بدون Docker)

```bash
# Backend
cd backend
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000

# Redis (جداگانه)
redis-server

# Celery Worker
celery -A app.workers.celery_app worker --loglevel=info

# Frontend
cd frontend
npm install
npm run dev
```

---

**ساخته‌شده با:** FastAPI · MongoDB · React · Tailwind · Celery · WebSocket · PWA
