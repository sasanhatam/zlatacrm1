import jdatetime
from datetime import datetime, timezone
from typing import Optional


def to_jalali(dt: Optional[datetime]) -> str:
    if not dt:
        return ""
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    jdt = jdatetime.datetime.fromgregorian(datetime=dt)
    return jdt.strftime("%Y/%m/%d")


def to_jalali_full(dt: Optional[datetime]) -> str:
    if not dt:
        return ""
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    jdt = jdatetime.datetime.fromgregorian(datetime=dt)
    return jdt.strftime("%Y/%m/%d %H:%M")


def jalali_year() -> int:
    return jdatetime.date.today().year


def jalali_today() -> str:
    return jdatetime.date.today().strftime("%Y/%m/%d")
