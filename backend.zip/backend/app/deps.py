from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from app.core.security import decode_access_token
from app.core.exceptions import AuthenticationError

bearer_scheme = HTTPBearer(auto_error=False)


async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(bearer_scheme),
):
    if not credentials:
        raise AuthenticationError("توکن احراز هویت یافت نشد")

    payload = decode_access_token(credentials.credentials)
    if not payload:
        raise AuthenticationError("توکن نامعتبر یا منقضی شده است")

    user_id = payload.get("sub")
    if not user_id:
        raise AuthenticationError("توکن نامعتبر است")

    from app.models.user import User
    from beanie import PydanticObjectId
    try:
        user = await User.get(PydanticObjectId(user_id))
    except Exception:
        raise AuthenticationError("کاربر یافت نشد")

    if not user or not user.is_active:
        raise AuthenticationError("حساب کاربری غیرفعال یا یافت نشد")

    return user
