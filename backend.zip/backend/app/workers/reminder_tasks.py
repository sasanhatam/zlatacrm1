from beanie.operators import NotIn
import asyncio
from datetime import datetime, timezone, timedelta
from app.workers.celery_app import celery_app
import structlog

logger = structlog.get_logger()


def run_async(coro):
    loop = asyncio.new_event_loop()
    try:
        return loop.run_until_complete(coro)
    finally:
        loop.close()


async def _init_db():
    from app.database import connect_db
    await connect_db()


@celery_app.task(name="app.workers.reminder_tasks.check_deadline_reminders")
def check_deadline_reminders():
    async def _run():
        await _init_db()
        from app.models.task import Task, TaskStatus
        from app.models.user import User
        from app.email.email_service import send_deadline_reminder

        now = datetime.now(timezone.utc)
        window_24h_start = now + timedelta(hours=23)
        window_24h_end = now + timedelta(hours=25)
        window_1h_start = now + timedelta(minutes=55)
        window_1h_end = now + timedelta(minutes=65)

        # تسک‌هایی که ددلاین در بازه ۲۴ ساعت دارند
        for window_start, window_end, label in [
            (window_24h_start, window_24h_end, "24h"),
            (window_1h_start, window_1h_end, "1h"),
        ]:
            tasks = await Task.find(
                Task.due_date >= window_start,
                Task.due_date <= window_end,
                NotIn(Task.status, [TaskStatus.DONE, TaskStatus.BLOCKED]),
                Task.assignee_id != None,
            ).to_list()

            for task in tasks:
                assignee = await User.get(task.assignee_id)
                if not assignee:
                    continue
                if not assignee.email_notifications_enabled:
                    continue
                if not assignee.notification_preferences.get("deadline_reminder", True):
                    continue

                target_email = assignee.notification_email or assignee.email
                hours_left = (task.due_date.replace(tzinfo=timezone.utc) - now).total_seconds() / 3600

                await send_deadline_reminder(
                    user_email=target_email,
                    user_name=assignee.full_name,
                    task_title=task.title,
                    hours_left=hours_left,
                    task_id=str(task.id),
                )
                logger.info("deadline_reminder_sent", task=str(task.id), window=label)

    run_async(_run())


@celery_app.task(name="app.workers.reminder_tasks.check_overdue_tasks")
def check_overdue_tasks():
    async def _run():
        await _init_db()
        from app.models.task import Task, TaskStatus
        from app.models.user import User
        from app.email.email_service import send_overdue_alert

        now = datetime.now(timezone.utc)
        tasks = await Task.find(
            Task.due_date < now,
            NotIn(Task.status, [TaskStatus.DONE, TaskStatus.BLOCKED]),
            Task.assignee_id != None,
        ).to_list()

        for task in tasks:
            assignee = await User.get(task.assignee_id)
            if not assignee:
                continue
            if not assignee.email_notifications_enabled:
                continue
            if not assignee.notification_preferences.get("overdue_alert", True):
                continue

            target_email = assignee.notification_email or assignee.email
            delay_hours = (now - task.due_date.replace(tzinfo=timezone.utc)).total_seconds() / 3600

            await send_overdue_alert(
                user_email=target_email,
                user_name=assignee.full_name,
                task_title=task.title,
                delay_hours=delay_hours,
                task_id=str(task.id),
            )
            logger.info("overdue_alert_sent", task=str(task.id))

    run_async(_run())
