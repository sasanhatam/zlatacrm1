from celery import Celery
from celery.schedules import crontab
from app.config import settings

celery_app = Celery(
    "zlata",
    broker=settings.CELERY_BROKER_URL,
    backend=settings.CELERY_RESULT_BACKEND,
    include=[
        "app.workers.reminder_tasks",
        "app.workers.email_tasks",
        "app.workers.summary_tasks",
    ],
)

celery_app.conf.update(
    task_serializer="json",
    result_serializer="json",
    accept_content=["json"],
    timezone="Asia/Tehran",
    enable_utc=True,
    task_track_started=True,
    worker_prefetch_multiplier=1,
)

# Celery Beat schedule
celery_app.conf.beat_schedule = {
    # هر ساعت — بررسی ددلاین ۲۴ ساعته و ۱ ساعته
    "check-deadline-reminders": {
        "task": "app.workers.reminder_tasks.check_deadline_reminders",
        "schedule": crontab(minute=0),
    },
    # هر روز ساعت ۸ صبح — بررسی تسک‌های معوق
    "check-overdue-tasks": {
        "task": "app.workers.reminder_tasks.check_overdue_tasks",
        "schedule": crontab(hour=8, minute=0),
    },
    # هر روز ساعت ۷ صبح — خلاصه روزانه
    "send-daily-summary": {
        "task": "app.workers.summary_tasks.send_daily_summary_emails",
        "schedule": crontab(hour=7, minute=0),
    },
    # هر دوشنبه ساعت ۸ صبح — خلاصه هفتگی
    "send-weekly-summary": {
        "task": "app.workers.summary_tasks.send_weekly_summary_emails",
        "schedule": crontab(hour=8, minute=0, day_of_week=1),
    },
}
