from beanie.operators import NotIn
import asyncio
import jdatetime
from app.workers.celery_app import celery_app


def run_async(coro):
    loop = asyncio.new_event_loop()
    try:
        return loop.run_until_complete(coro)
    finally:
        loop.close()


PRIORITY_LABELS = {"low": "کم", "medium": "متوسط", "high": "زیاد", "urgent": "فوری"}
STATUS_LABELS = {"todo": "در انتظار", "in_progress": "در حال انجام",
                 "in_review": "در بررسی", "done": "انجام شده", "blocked": "مسدود"}


@celery_app.task(name="app.workers.summary_tasks.send_daily_summary_emails")
def send_daily_summary_emails():
    async def _run():
        from app.database import connect_db
        await connect_db()
        from app.models.user import User
        from app.models.task import Task, TaskStatus
        from app.email.email_service import send_daily_summary
        from datetime import datetime, timezone, timedelta

        now = datetime.now(timezone.utc)
        users = await User.find(User.is_active == True).to_list()

        for user in users:
            if not user.email_notifications_enabled:
                continue
            if not user.notification_preferences.get("daily_summary", False):
                continue

            target_email = user.notification_email or user.email
            tasks = await Task.find(
                Task.assignee_id == user.id,
                NotIn(Task.status, [TaskStatus.DONE]),
            ).sort("-priority").limit(10).to_list()

            task_data = []
            for t in tasks:
                due_jalali = ""
                if t.due_date:
                    jdt = jdatetime.datetime.fromgregorian(datetime=t.due_date)
                    due_jalali = jdt.strftime("%Y/%m/%d")
                task_data.append({
                    "title": t.title,
                    "status_label": STATUS_LABELS.get(t.status, t.status),
                    "priority": t.priority,
                    "priority_label": PRIORITY_LABELS.get(t.priority, t.priority),
                    "due_date_jalali": due_jalali,
                })

            await send_daily_summary(
                user_email=target_email,
                user_name=user.full_name,
                tasks=task_data,
            )

    run_async(_run())


@celery_app.task(name="app.workers.summary_tasks.send_weekly_summary_emails")
def send_weekly_summary_emails():
    # مشابه daily اما با تسک‌های هفته گذشته و آینده
    send_daily_summary_emails.delay()
