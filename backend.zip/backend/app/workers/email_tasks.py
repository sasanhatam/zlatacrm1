from app.workers.celery_app import celery_app
import asyncio


def run_async(coro):
    loop = asyncio.new_event_loop()
    try:
        return loop.run_until_complete(coro)
    finally:
        loop.close()


@celery_app.task(name="app.workers.email_tasks.send_email_task")
def send_email_task(to: list, subject: str, template_name: str, context: dict):
    async def _run():
        from app.email.email_service import send_email
        await send_email(to=to, subject=subject, template_name=template_name, context=context)
    run_async(_run())


@celery_app.task(name="app.workers.email_tasks.send_mention_email")
def send_mention_email(user_email: str, user_name: str, mentioned_by: str,
                        task_title: str, comment_content: str, task_id: str):
    async def _run():
        from app.email.email_service import send_mention_notification
        await send_mention_notification(
            user_email=user_email, user_name=user_name,
            mentioned_by=mentioned_by, task_title=task_title,
            comment_content=comment_content, task_id=task_id,
        )
    run_async(_run())
