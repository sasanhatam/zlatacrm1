from fastapi import FastAPI, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from contextlib import asynccontextmanager
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded
from app.config import settings
from app.database import connect_db, disconnect_db
from app.core.logging import setup_logging
import structlog

setup_logging(debug=settings.DEBUG)
logger = structlog.get_logger()

limiter = Limiter(key_func=get_remote_address, default_limits=[f"{settings.RATE_LIMIT_PER_MINUTE}/minute"])


async def auto_seed():
    import os
    if os.environ.get("USE_MONGOMOCK", "false").lower() != "true":
        return
    from app.models.user import User, Team, Organization
    from app.models.task import Task, TaskStatus, TaskPriority
    from app.models.system import SystemSettings
    from app.core.security import hash_password
    from datetime import datetime, timezone, timedelta

    if await User.count() > 0:
        return

    now = datetime.now(timezone.utc)

    # Seed two companies
    zlata = Organization(name="زلاطا", official_name="شرکت زلاطا", address="تهران، ایران")
    await zlata.insert()
    damon = Organization(name="دامون سرویس", official_name="شرکت دامون سرویس", address="تهران، ایران")
    await damon.insert()

    # admin and sasan → both companies
    admin = User(email="admin@zlata.ir", hashed_password=hash_password("159Mahsan315%"),
                 full_name="مدیر سیستم", role="super_admin", position="مدیرعامل",
                 mobile="09124442042",
                 notification_email="admin@zlata.ir", is_active=True,
                 organization_ids=[zlata.id, damon.id])
    await admin.insert()

    sasan = User(email="sasan@zlata.ir", hashed_password=hash_password("159Mahsan315%"),
                 full_name="سسان", role="super_admin", position="مدیر کل",
                 mobile="09000000002",
                 notification_email="sasan@zlata.ir", is_active=True,
                 organization_ids=[zlata.id, damon.id])
    await sasan.insert()

    users_raw = [
        ("manager@zlata.ir", "مدیر پروژه", "manager", "مدیر پروژه", [zlata.id], "09100000001"),
        ("lead@zlata.ir", "سرتیم فنی", "team_lead", "سرتیم", [zlata.id], "09100000002"),
        ("ali@zlata.ir", "علی احمدی", "member", "برنامه‌نویس", [zlata.id], "09100000003"),
        ("sara@zlata.ir", "سارا محمدی", "member", "طراح UI", [damon.id], "09100000004"),
        ("reza@zlata.ir", "رضا کریمی", "member", "تست‌نویس", [damon.id], "09100000005"),
    ]
    user_objs = {}
    for email, name, role, pos, org_ids, mobile in users_raw:
        u = User(email=email, hashed_password=hash_password("Pass@1234"),
                 full_name=name, role=role, position=pos, notification_email=email,
                 mobile=mobile, organization_ids=org_ids)
        await u.insert()
        user_objs[role] = u

    team = Team(name="تیم فنی", description="توسعه‌دهندگان",
                manager_id=user_objs["manager"].id, lead_id=user_objs["team_lead"].id,
                member_ids=[user_objs["manager"].id, user_objs["team_lead"].id, user_objs["member"].id])
    await team.insert()

    tasks_seed = [
        ("راه‌اندازی محیط توسعه", TaskPriority.HIGH, TaskStatus.DONE, -2),
        ("طراحی دیتابیس", TaskPriority.URGENT, TaskStatus.IN_PROGRESS, 1),
        ("پیاده‌سازی API احراز هویت", TaskPriority.HIGH, TaskStatus.TODO, 3),
        ("طراحی رابط کاربری داشبورد", TaskPriority.MEDIUM, TaskStatus.TODO, 5),
        ("بررسی تسک‌های معوق", TaskPriority.LOW, TaskStatus.BLOCKED, -10),
    ]
    for title, prio, status, days in tasks_seed:
        t = Task(title=title, team_id=team.id, assignee_id=user_objs["member"].id,
                 created_by=admin.id, priority=prio, status=status,
                 due_date=now + timedelta(days=days), tags=["نمونه"])
        if status == TaskStatus.DONE:
            t.completed_at = now - timedelta(hours=2)
            t.delay_hours = -2.0
        await t.insert()

    await SystemSettings(org_name="Zlata Management", org_address="تهران، ایران", stale_task_days=7).insert()
    logger.info("auto_seed_done")


@asynccontextmanager
async def lifespan(app: FastAPI):
    await connect_db()
    await auto_seed()
    logger.info("app_started", version=settings.APP_VERSION)
    yield
    await disconnect_db()
    logger.info("app_stopped")


app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    docs_url="/api/docs",
    redoc_url="/api/redoc",
    openapi_url="/api/openapi.json",
    lifespan=lifespan,
)

app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    logger.error("unhandled_exception", error=str(exc), path=request.url.path)
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={"detail": "خطای داخلی سرور"},
    )


# Register routers
from app.routers import auth, users, teams, tasks, chat, notifications, letters, dashboard, files, phonebook, admin
from app.routers import meetings, leaves
from app.routers import companies, kartabl
from app.routers import seo
from app.routers import activity_logs
from app.routers import attendance

app.include_router(auth.router, prefix="/api")
app.include_router(users.router, prefix="/api")
app.include_router(teams.router, prefix="/api")
app.include_router(tasks.router, prefix="/api")
app.include_router(chat.router, prefix="/api")
app.include_router(notifications.router, prefix="/api")
app.include_router(letters.router)
app.include_router(meetings.router)
app.include_router(leaves.router)
app.include_router(dashboard.router, prefix="/api")
app.include_router(files.router, prefix="/api")
app.include_router(phonebook.router, prefix="/api")
app.include_router(admin.router, prefix="/api")
app.include_router(companies.router)
app.include_router(kartabl.router)
app.include_router(seo.router)
app.include_router(activity_logs.router, prefix="/api")
app.include_router(attendance.router, prefix="/api")


@app.get("/api/health")
async def health():
    return {"status": "ok", "version": settings.APP_VERSION}
