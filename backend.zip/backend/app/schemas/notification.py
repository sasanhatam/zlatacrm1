from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime
from app.models.notification import NotificationType, NotificationPriority


class NotificationResponse(BaseModel):
    id: str
    type: NotificationType
    priority: NotificationPriority
    title: str
    body: str
    link: Optional[str] = None
    is_read: bool
    metadata: dict = {}
    created_at: datetime

    model_config = {"from_attributes": True}


class AnnouncementCreate(BaseModel):
    title: str
    body: str
    priority: NotificationPriority = NotificationPriority.NORMAL
    target_team_ids: Optional[List[str]] = None
    expires_at: Optional[datetime] = None


class AnnouncementResponse(BaseModel):
    id: str
    title: str
    body: str
    priority: NotificationPriority
    author_id: str
    target_team_ids: Optional[List[str]] = None
    is_active: bool
    expires_at: Optional[datetime] = None
    created_at: datetime

    model_config = {"from_attributes": True}


class PushSubscriptionCreate(BaseModel):
    endpoint: str
    p256dh: str
    auth: str
