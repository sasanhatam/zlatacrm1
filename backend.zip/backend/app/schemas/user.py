from pydantic import BaseModel, EmailStr, field_validator
from typing import Optional, List
from datetime import datetime
from beanie import PydanticObjectId
from app.models.user import UserRole


class UserCreate(BaseModel):
    email: EmailStr
    password: str
    full_name: str
    role: UserRole = UserRole.MEMBER
    position: Optional[str] = None
    team_ids: List[str] = []
    extension_number: Optional[str] = None
    mobile: Optional[str] = None
    notification_email: Optional[EmailStr] = None

    @field_validator("password")
    @classmethod
    def password_min_length(cls, v: str) -> str:
        if len(v) < 8:
            raise ValueError("رمز عبور باید حداقل ۸ کاراکتر باشد")
        return v


class UserUpdate(BaseModel):
    full_name: Optional[str] = None
    position: Optional[str] = None
    team_ids: Optional[List[str]] = None
    organization_ids: Optional[List[str]] = None
    extension_number: Optional[str] = None
    mobile: Optional[str] = None
    notification_email: Optional[EmailStr] = None
    email_notifications_enabled: Optional[bool] = None
    notification_preferences: Optional[dict] = None
    role: Optional[UserRole] = None
    is_active: Optional[bool] = None


class UserProfileUpdate(BaseModel):
    full_name: Optional[str] = None
    position: Optional[str] = None
    mobile: Optional[str] = None
    extension_number: Optional[str] = None
    notification_email: Optional[EmailStr] = None
    email_notifications_enabled: Optional[bool] = None
    notification_preferences: Optional[dict] = None


class UserResponse(BaseModel):
    id: str
    email: str
    full_name: str
    role: UserRole
    position: Optional[str] = None
    team_ids: List[str] = []
    avatar_url: Optional[str] = None
    extension_number: Optional[str] = None
    mobile: Optional[str] = None
    notification_email: Optional[str] = None
    email_notifications_enabled: bool
    notification_preferences: dict
    is_active: bool
    last_login: Optional[datetime] = None
    created_at: datetime

    model_config = {"from_attributes": True}


class TeamCreate(BaseModel):
    name: str
    description: Optional[str] = None
    manager_id: Optional[str] = None
    lead_id: Optional[str] = None
    member_ids: List[str] = []


class TeamUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    manager_id: Optional[str] = None
    lead_id: Optional[str] = None
    member_ids: Optional[List[str]] = None
    is_active: Optional[bool] = None


class TeamResponse(BaseModel):
    id: str
    name: str
    description: Optional[str] = None
    manager_id: Optional[str] = None
    lead_id: Optional[str] = None
    member_ids: List[str] = []
    is_active: bool
    created_at: datetime

    model_config = {"from_attributes": True}
