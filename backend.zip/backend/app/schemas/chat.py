from pydantic import BaseModel
from typing import Optional, List, Dict
from datetime import datetime
from app.models.chat import RoomType, MessageType


class RoomCreate(BaseModel):
    name: Optional[str] = None
    type: RoomType = RoomType.DIRECT
    member_ids: List[str]


class RoomResponse(BaseModel):
    id: str
    name: Optional[str] = None
    type: RoomType
    member_ids: List[str]
    admin_ids: List[str]
    last_message_at: Optional[datetime] = None
    last_message_preview: Optional[str] = None
    created_at: datetime

    model_config = {"from_attributes": True}


class MessageCreate(BaseModel):
    content: Optional[str] = None
    file_id: Optional[str] = None
    mentioned_user_ids: List[str] = []


class MessageResponse(BaseModel):
    id: str
    room_id: str
    sender_id: str
    type: MessageType
    content: Optional[str] = None
    file_id: Optional[str] = None
    mentioned_user_ids: List[str] = []
    read_by: Dict[str, datetime] = {}
    is_deleted: bool
    created_at: datetime

    model_config = {"from_attributes": True}
