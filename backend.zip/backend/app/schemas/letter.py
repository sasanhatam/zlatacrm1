from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime
from app.models.letter import LetterType


class LetterCreate(BaseModel):
    letter_type: LetterType = LetterType.OUTGOING
    subject: str
    body: str
    recipient_name: str
    recipient_organization: Optional[str] = None
    recipient_email: Optional[str] = None
    signature_name: Optional[str] = None
    signature_position: Optional[str] = None
    file_ids: List[str] = []


class LetterUpdate(BaseModel):
    subject: Optional[str] = None
    body: Optional[str] = None
    recipient_name: Optional[str] = None
    recipient_organization: Optional[str] = None
    recipient_email: Optional[str] = None
    signature_name: Optional[str] = None
    signature_position: Optional[str] = None


class LetterResponse(BaseModel):
    id: str
    letter_number: str
    letter_type: LetterType
    subject: str
    body: str
    recipient_name: str
    recipient_organization: Optional[str] = None
    recipient_email: Optional[str] = None
    sender_id: str
    signature_name: Optional[str] = None
    signature_position: Optional[str] = None
    file_ids: List[str] = []
    pdf_key: Optional[str] = None
    jalali_date: str
    created_at: datetime

    model_config = {"from_attributes": True}
