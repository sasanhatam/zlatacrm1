from pydantic import BaseModel
from typing import Optional, List, Any, Dict
from datetime import datetime
from app.models.task import TaskStatus, TaskPriority


class ChecklistItemSchema(BaseModel):
    text: str
    is_done: bool = False


class TaskCreate(BaseModel):
    title: str
    description: Optional[str] = None
    team_id: Optional[str] = None
    assignee_id: Optional[str] = None
    priority: TaskPriority = TaskPriority.MEDIUM
    tags: List[str] = []
    start_date: Optional[datetime] = None
    due_date: Optional[datetime] = None
    checklist: List[ChecklistItemSchema] = []
    watcher_ids: List[str] = []


class TaskUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    team_id: Optional[str] = None
    assignee_id: Optional[str] = None
    priority: Optional[TaskPriority] = None
    status: Optional[TaskStatus] = None
    tags: Optional[List[str]] = None
    start_date: Optional[datetime] = None
    due_date: Optional[datetime] = None
    checklist: Optional[List[ChecklistItemSchema]] = None
    watcher_ids: Optional[List[str]] = None


class TaskResponse(BaseModel):
    id: str
    title: str
    description: Optional[str] = None
    team_id: str
    assignee_id: Optional[str] = None
    created_by: str
    priority: TaskPriority
    status: TaskStatus
    tags: List[str] = []
    start_date: Optional[datetime] = None
    due_date: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    delay_hours: Optional[float] = None
    checklist: List[Dict[str, Any]] = []
    file_ids: List[str] = []
    watcher_ids: List[str] = []
    last_activity_at: datetime
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class SubTaskCreate(BaseModel):
    title: str
    description: Optional[str] = None
    assignee_id: Optional[str] = None
    due_date: Optional[datetime] = None


class SubTaskUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    assignee_id: Optional[str] = None
    status: Optional[TaskStatus] = None
    due_date: Optional[datetime] = None
    is_done: Optional[bool] = None


class CommentCreate(BaseModel):
    content: str
    mentioned_user_ids: List[str] = []


class CommentResponse(BaseModel):
    id: str
    task_id: str
    author_id: str
    content: str
    mentioned_user_ids: List[str] = []
    file_ids: List[str] = []
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class AuditLogResponse(BaseModel):
    id: str
    task_id: str
    user_id: str
    action: str
    field: Optional[str] = None
    old_value: Optional[Any] = None
    new_value: Optional[Any] = None
    description: Optional[str] = None
    created_at: datetime

    model_config = {"from_attributes": True}


class TaskFilterParams(BaseModel):
    team_id: Optional[str] = None
    assignee_id: Optional[str] = None
    status: Optional[TaskStatus] = None
    priority: Optional[TaskPriority] = None
    tags: Optional[List[str]] = None
    from_date: Optional[datetime] = None
    to_date: Optional[datetime] = None
    search: Optional[str] = None
    page: int = 1
    page_size: int = 20
