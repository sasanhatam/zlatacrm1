from pydantic import BaseModel
from typing import Optional, List, Dict, Any
from datetime import datetime


class TaskStats(BaseModel):
    total: int = 0
    todo: int = 0
    in_progress: int = 0
    in_review: int = 0
    done: int = 0
    blocked: int = 0
    overdue: int = 0


class UserPerformance(BaseModel):
    user_id: str
    full_name: str
    total_assigned: int = 0
    completed: int = 0
    on_time: int = 0
    overdue: int = 0
    avg_delay_hours: Optional[float] = None
    completion_rate: float = 0.0


class TeamStats(BaseModel):
    team_id: str
    team_name: str
    task_stats: TaskStats
    member_count: int = 0


class DashboardOverview(BaseModel):
    task_stats: TaskStats
    team_stats: List[TeamStats] = []
    stale_tasks_count: int = 0
    overdue_tasks_count: int = 0


class DashboardFilters(BaseModel):
    team_id: Optional[str] = None
    user_id: Optional[str] = None
    from_date: Optional[datetime] = None
    to_date: Optional[datetime] = None
