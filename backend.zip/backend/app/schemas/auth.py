from pydantic import BaseModel, field_validator
from typing import Optional
import re


class LoginRequest(BaseModel):
    mobile: str
    password: str

    @field_validator("mobile")
    @classmethod
    def normalize_mobile(cls, v: str) -> str:
        v = v.strip().replace(" ", "").replace("-", "")
        if not re.match(r"^0?9\d{9}$", v):
            raise ValueError("شماره موبایل معتبر نیست")
        if not v.startswith("0"):
            v = "0" + v
        return v


class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int   # seconds


class RefreshRequest(BaseModel):
    refresh_token: str


class PasswordChangeRequest(BaseModel):
    current_password: str
    new_password: str

    @field_validator("new_password")
    @classmethod
    def password_strength(cls, v: str) -> str:
        if len(v) < 8:
            raise ValueError("رمز عبور باید حداقل ۸ کاراکتر باشد")
        return v


class RegistrationRequestCreate(BaseModel):
    full_name: str
    mobile: str
    password: str
    organization_ids: list[str] = []

    @field_validator("mobile")
    @classmethod
    def normalize_mobile(cls, v: str) -> str:
        v = v.strip().replace(" ", "").replace("-", "")
        if not re.match(r"^0?9\d{9}$", v):
            raise ValueError("شماره موبایل معتبر نیست")
        if not v.startswith("0"):
            v = "0" + v
        return v

    @field_validator("password")
    @classmethod
    def password_strength(cls, v: str) -> str:
        if len(v) < 8:
            raise ValueError("رمز عبور باید حداقل ۸ کاراکتر باشد")
        return v


class RegistrationRequestReject(BaseModel):
    reason: Optional[str] = None
