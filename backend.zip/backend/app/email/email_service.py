from typing import List, Optional
from jinja2 import Environment, FileSystemLoader, select_autoescape
from pathlib import Path
from app.email.base import EmailProvider
from app.config import settings
import structlog

logger = structlog.get_logger()

_template_dir = Path(__file__).parent / "templates"
_jinja_env = Environment(
    loader=FileSystemLoader(str(_template_dir)),
    autoescape=select_autoescape(["html"]),
)


def _get_provider() -> EmailProvider:
    """Always reads current SMTP config (allows admin changes without restart)."""
    from app.email.smtp_provider import SmtpEmailProvider
    return SmtpEmailProvider(
        host=settings.SMTP_HOST,
        port=settings.SMTP_PORT,
        username=settings.SMTP_USERNAME,
        password=settings.SMTP_PASSWORD,
        from_email=settings.SMTP_FROM_EMAIL or settings.SMTP_USERNAME,
        from_name=settings.SMTP_FROM_NAME,
        use_tls=settings.SMTP_USE_TLS,
    )


async def send_email(to: List[str], subject: str, template_name: str, context: dict) -> bool:
    if not settings.SMTP_USERNAME:
        logger.warning("smtp_not_configured_skipping_email")
        return False
    try:
        template = _jinja_env.get_template(template_name)
        html_body = template.render(**context)
        provider = _get_provider()
        return await provider.send(to=to, subject=subject, html_body=html_body)
    except Exception as e:
        logger.error("email_service_error", error=str(e))
        return False


async def send_deadline_reminder(user_email: str, user_name: str,
                                  task_title: str, hours_left: float,
                                  task_id: str) -> bool:
    return await send_email(
        to=[user_email],
        subject=f"یادآوری ددلاین: {task_title}",
        template_name="deadline_reminder.html",
        context={"user_name": user_name, "task_title": task_title,
                 "hours_left": hours_left, "task_id": task_id},
    )


async def send_overdue_alert(user_email: str, user_name: str,
                              task_title: str, delay_hours: float,
                              task_id: str) -> bool:
    return await send_email(
        to=[user_email],
        subject=f"تسک معوق: {task_title}",
        template_name="overdue.html",
        context={"user_name": user_name, "task_title": task_title,
                 "delay_hours": delay_hours, "task_id": task_id},
    )


async def send_daily_summary(user_email: str, user_name: str, tasks: list) -> bool:
    return await send_email(
        to=[user_email],
        subject="خلاصه روزانه تسک‌های شما",
        template_name="daily_summary.html",
        context={"user_name": user_name, "tasks": tasks},
    )


async def send_mention_notification(user_email: str, user_name: str,
                                     mentioned_by: str, task_title: str,
                                     comment_content: str, task_id: str) -> bool:
    return await send_email(
        to=[user_email],
        subject=f"منشن در تسک: {task_title}",
        template_name="mention.html",
        context={"user_name": user_name, "mentioned_by": mentioned_by,
                 "task_title": task_title, "comment_content": comment_content,
                 "task_id": task_id},
    )
