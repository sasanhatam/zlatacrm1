import aiosmtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from typing import List, Optional
from app.email.base import EmailProvider
import structlog

logger = structlog.get_logger()


class SmtpEmailProvider(EmailProvider):
    def __init__(self, host: str, port: int, username: str, password: str,
                 from_email: str, from_name: str, use_tls: bool = True):
        self.host = host
        self.port = port
        self.username = username
        self.password = password
        self.from_email = from_email
        self.from_name = from_name
        self.use_tls = use_tls

    async def send(self, to: List[str], subject: str, html_body: str,
                   text_body: Optional[str] = None) -> bool:
        msg = MIMEMultipart("alternative")
        msg["Subject"] = subject
        msg["From"] = f"{self.from_name} <{self.from_email}>"
        msg["To"] = ", ".join(to)

        if text_body:
            msg.attach(MIMEText(text_body, "plain", "utf-8"))
        msg.attach(MIMEText(html_body, "html", "utf-8"))

        try:
            await aiosmtplib.send(
                msg,
                hostname=self.host,
                port=self.port,
                username=self.username,
                password=self.password,
                start_tls=self.use_tls,
            )
            logger.info("email_sent", to=to, subject=subject)
            return True
        except Exception as e:
            logger.error("email_send_failed", error=str(e), to=to)
            return False
