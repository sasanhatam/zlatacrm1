from abc import ABC, abstractmethod
from typing import List, Optional


class EmailProvider(ABC):
    @abstractmethod
    async def send(
        self,
        to: List[str],
        subject: str,
        html_body: str,
        text_body: Optional[str] = None,
    ) -> bool:
        ...
