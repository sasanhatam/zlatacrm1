from enum import Enum
from fastapi import Depends
from app.deps import get_current_user
from app.models.user import User, UserRole
from app.core.exceptions import AuthorizationError


class Role(str, Enum):
    SUPER_ADMIN = "super_admin"
    MANAGER = "manager"
    TEAM_LEAD = "team_lead"
    MEMBER = "member"


ROLE_HIERARCHY = {
    Role.SUPER_ADMIN: 4,
    Role.MANAGER: 3,
    Role.TEAM_LEAD: 2,
    Role.MEMBER: 1,
}


def require_role(*roles: Role):
    """Dependency factory: requires user to have one of the specified roles."""
    async def checker(current_user: User = Depends(get_current_user)) -> User:
        if not current_user.is_active:
            raise AuthorizationError("حساب کاربری غیرفعال است")
        if current_user.role not in [r.value for r in roles]:
            raise AuthorizationError("سطح دسترسی کافی نیست")
        return current_user
    return checker


def require_min_role(min_role: Role):
    """Requires user role to be at or above the minimum level."""
    async def checker(current_user: User = Depends(get_current_user)) -> User:
        if not current_user.is_active:
            raise AuthorizationError("حساب کاربری غیرفعال است")
        user_level = ROLE_HIERARCHY.get(Role(current_user.role), 0)
        required_level = ROLE_HIERARCHY.get(min_role, 999)
        if user_level < required_level:
            raise AuthorizationError("سطح دسترسی کافی نیست")
        return current_user
    return checker


require_super_admin = require_role(Role.SUPER_ADMIN)
require_manager = require_min_role(Role.MANAGER)
require_team_lead = require_min_role(Role.TEAM_LEAD)
require_member = require_min_role(Role.MEMBER)
