"""Activity logging utility — call log_activity() from any router."""
from datetime import datetime, timezone
from typing import Optional, Dict, Any
import structlog

logger = structlog.get_logger()

PERSIAN_DIGITS = "۰۱۲۳۴۵۶۷۸۹"


def _to_persian_digits(s: str) -> str:
    return s.translate(str.maketrans("0123456789", PERSIAN_DIGITS))


def _jalali_now() -> str:
    try:
        import jdatetime
        from zoneinfo import ZoneInfo
        tehran = ZoneInfo("Asia/Tehran")
        now_tehran = datetime.now(tehran)
        jdt = jdatetime.datetime.fromgregorian(datetime=now_tehran)
        s = jdt.strftime("%Y/%m/%d %H:%M:%S")
        return _to_persian_digits(s)
    except Exception:
        return datetime.now(timezone.utc).isoformat()


async def log_activity(
    action: str,
    resource_type: str = "",
    resource_id: str = "",
    resource_title: str = "",
    details: Optional[Dict[str, Any]] = None,
    user=None,
    ip_address: str = "",
):
    try:
        from app.models.activity_log import ActivityLog

        user_id = None
        user_name = ""
        user_mobile = ""
        if user is not None:
            user_id = user.id
            user_name = getattr(user, "full_name", "") or ""
            user_mobile = getattr(user, "mobile", "") or ""

        log = ActivityLog(
            user_id=user_id,
            user_name=user_name,
            user_mobile=user_mobile,
            action=action,
            resource_type=resource_type,
            resource_id=resource_id,
            resource_title=resource_title,
            details=details or {},
            ip_address=ip_address,
            jalali_datetime=_jalali_now(),
        )
        await log.insert()
    except Exception as exc:
        logger.warning("activity_log_failed", error=str(exc), action=action)
