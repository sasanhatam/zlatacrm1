from fastapi import HTTPException, status


class AuthenticationError(HTTPException):
    def __init__(self, detail: str = "احراز هویت ناموفق"):
        super().__init__(status_code=status.HTTP_401_UNAUTHORIZED, detail=detail,
                         headers={"WWW-Authenticate": "Bearer"})


class AuthorizationError(HTTPException):
    def __init__(self, detail: str = "دسترسی مجاز نیست"):
        super().__init__(status_code=status.HTTP_403_FORBIDDEN, detail=detail)


class NotFoundError(HTTPException):
    def __init__(self, detail: str = "مورد یافت نشد"):
        super().__init__(status_code=status.HTTP_404_NOT_FOUND, detail=detail)


class ValidationError(HTTPException):
    def __init__(self, detail: str = "داده‌های ارسالی نامعتبر است"):
        super().__init__(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=detail)


class ConflictError(HTTPException):
    def __init__(self, detail: str = "تعارض داده"):
        super().__init__(status_code=status.HTTP_409_CONFLICT, detail=detail)


class FileTooLargeError(HTTPException):
    def __init__(self, max_mb: int = 50):
        super().__init__(status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
                         detail=f"حجم فایل بیش از {max_mb} مگابایت مجاز نیست")


class UnsupportedFileTypeError(HTTPException):
    def __init__(self):
        super().__init__(status_code=status.HTTP_415_UNSUPPORTED_MEDIA_TYPE,
                         detail="نوع فایل پشتیبانی نمی‌شود")
