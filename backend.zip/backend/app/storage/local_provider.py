import os
import aiofiles
from pathlib import Path
from app.storage.base import StorageProvider
from app.config import settings


class LocalStorageProvider(StorageProvider):
    def __init__(self, base_path: str = None):
        self.base_path = Path(base_path or settings.LOCAL_STORAGE_PATH)
        self.base_path.mkdir(parents=True, exist_ok=True)

    async def upload(self, key: str, data: bytes, content_type: str) -> str:
        file_path = self.base_path / key
        file_path.parent.mkdir(parents=True, exist_ok=True)
        async with aiofiles.open(file_path, "wb") as f:
            await f.write(data)
        return key

    async def download_url(self, key: str, expires: int = 3600) -> str:
        # In dev, return a local API endpoint path
        return f"/api/files/download/{key}"

    async def delete(self, key: str) -> None:
        file_path = self.base_path / key
        if file_path.exists():
            file_path.unlink()

    async def exists(self, key: str) -> bool:
        return (self.base_path / key).exists()

    def get_local_path(self, key: str) -> Path:
        return self.base_path / key
