from app.config import settings
from app.storage.base import StorageProvider


def get_storage() -> StorageProvider:
    if settings.STORAGE_BACKEND == "s3" and settings.S3_ACCESS_KEY:
        from app.storage.s3_provider import S3StorageProvider
        return S3StorageProvider()
    from app.storage.local_provider import LocalStorageProvider
    return LocalStorageProvider()


storage: StorageProvider = get_storage()
