from abc import ABC, abstractmethod
from typing import Tuple, Optional


class StorageProvider(ABC):
    @abstractmethod
    async def upload(self, key: str, data: bytes, content_type: str) -> str:
        """Upload file and return the storage key."""
        ...

    @abstractmethod
    async def download_url(self, key: str, expires: int = 3600) -> str:
        """Return a pre-signed or direct URL for the file."""
        ...

    @abstractmethod
    async def delete(self, key: str) -> None:
        ...

    @abstractmethod
    async def exists(self, key: str) -> bool:
        ...
