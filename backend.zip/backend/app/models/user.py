from beanie import Document, PydanticObjectId, Indexed
from pydantic import EmailStr, Field
from typing import Optional, List
from datetime import datetime, timezone
from enum import Enum


class UserRole(str, Enum):
    SUPER_ADMIN = "super_admin"
    MANAGER = "manager"
    TEAM_LEAD = "team_lead"
    MEMBER = "member"


class NotificationPreferences(Document):
    deadline_reminder: bool = True
    overdue_alert: bool = True
    daily_summary: bool = False
    weekly_summary: bool = True
    mention_alert: bool = True
    task_assigned: bool = True


class User(Document):
    email: Indexed(EmailStr, unique=True)
    hashed_password: str
    full_name: str
    role: UserRole = UserRole.MEMBER
    position: Optional[str] = None               # سمت سازمانی
    team_ids: List[PydanticObjectId] = []
    organization_ids: List[PydanticObjectId] = []  # شرکت‌های کاربر
    avatar_key: Optional[str] = None             # S3/local key
    extension_number: Optional[str] = None       # شماره داخلی
    mobile: Optional[str] = None
    notification_email: Optional[EmailStr] = None
    email_notifications_enabled: bool = True
    notification_preferences: dict = Field(default_factory=lambda: {
        "deadline_reminder": True,
        "overdue_alert": True,
        "daily_summary": False,
        "weekly_summary": True,
        "mention_alert": True,
        "task_assigned": True,
    })
    # امضای الکترونیک (base64 یا کلید S3)
    signature_data: Optional[str] = None         # base64 تصویر امضا
    signature_key: Optional[str] = None          # S3/local key
    stamp_data: Optional[str] = None             # base64 — مهر شخصی (فقط مدیران)

    is_active: bool = True
    last_login: Optional[datetime] = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    class Settings:
        name = "users"
        indexes = [["email"], ["team_ids"]]


class Team(Document):
    name: str
    description: Optional[str] = None
    organization_id: Optional[PydanticObjectId] = None
    manager_id: Optional[PydanticObjectId] = None   # User with MANAGER role
    lead_id: Optional[PydanticObjectId] = None       # User with TEAM_LEAD role
    member_ids: List[PydanticObjectId] = []
    is_active: bool = True
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    class Settings:
        name = "teams"


class RegistrationRequestStatus(str, Enum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"


class RegistrationRequest(Document):
    """درخواست افتتاح حساب از طرف کاربر — منتظر تایید مدیر"""
    full_name: str
    mobile: str
    hashed_password: str
    requested_org_ids: List[PydanticObjectId] = []
    status: RegistrationRequestStatus = RegistrationRequestStatus.PENDING
    rejection_reason: Optional[str] = None
    reviewed_by: Optional[PydanticObjectId] = None
    reviewed_at: Optional[datetime] = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    class Settings:
        name = "registration_requests"
        indexes = [["mobile"], ["status"]]


class Organization(Document):
    name: str
    logo_key: Optional[str] = None
    address: Optional[str] = None
    phone: Optional[str] = None
    website: Optional[str] = None
    official_name: Optional[str] = None          # برای سربرگ نامه
    letterhead_header_data: Optional[str] = None  # base64 header image (full-width)
    letterhead_footer_data: Optional[str] = None  # base64 footer image (full-width)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    class Settings:
        name = "organizations"
