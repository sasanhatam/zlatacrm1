from beanie import Document, PydanticObjectId
from pydantic import Field
from typing import Optional, List, Dict, Any
from datetime import datetime, timezone
from enum import Enum


class MeetingStatus(str, Enum):
    SCHEDULED = "scheduled"   # برنامه‌ریزی شده
    IN_PROGRESS = "in_progress"  # در حال برگزاری
    COMPLETED = "completed"   # برگزار شده
    CANCELLED = "cancelled"   # لغو شده


class MeetingType(str, Enum):
    IN_PERSON = "in_person"   # حضوری
    ONLINE = "online"          # آنلاین
    HYBRID = "hybrid"          # ترکیبی


class AttendeeStatus(str, Enum):
    PENDING = "pending"        # در انتظار پاسخ
    ACCEPTED = "accepted"      # پذیرفته
    DECLINED = "declined"      # رد کرده
    TENTATIVE = "tentative"   # احتمالی


class MeetingMinutes(Document):
    """صورت‌جلسه"""
    meeting_id: PydanticObjectId
    content: str
    written_by: PydanticObjectId
    action_items: List[Dict[str, Any]] = []  # [{"task": str, "responsible": user_id, "deadline": date}]
    approved_by: Optional[PydanticObjectId] = None
    approved_at: Optional[datetime] = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    class Settings:
        name = "meeting_minutes"
        indexes = [["meeting_id"]]


class Meeting(Document):
    title: str
    description: Optional[str] = None
    meeting_type: MeetingType = MeetingType.IN_PERSON
    status: MeetingStatus = MeetingStatus.SCHEDULED

    organizer_id: PydanticObjectId
    team_id: Optional[PydanticObjectId] = None       # اگر مخصوص یک تیم باشد
    is_all_org: bool = False                          # برای کل سازمان

    attendees: List[Dict[str, Any]] = []             # [{"user_id": id, "status": AttendeeStatus}]
    proposed_times: List[Dict[str, Any]] = []        # [{"user_id": str, "start_time": datetime, "end_time": datetime, "note": str, "proposed_at": datetime}]

    start_time: datetime
    end_time: datetime
    location: Optional[str] = None
    online_link: Optional[str] = None

    agenda: Optional[str] = None                     # دستور جلسه
    minutes_id: Optional[PydanticObjectId] = None    # صورت‌جلسه

    reminder_sent: bool = False
    file_ids: List[PydanticObjectId] = []

    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    class Settings:
        name = "meetings"
        indexes = [["organizer_id"], ["team_id"], ["start_time"], ["status"]]
