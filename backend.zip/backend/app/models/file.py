from beanie import Document, PydanticObjectId
from pydantic import Field
from typing import Optional
from datetime import datetime, timezone


class FileMetadata(Document):
    original_name: str
    sanitized_name: str
    storage_key: str               # S3 key or local path
    content_type: str
    size_bytes: int
    uploaded_by: PydanticObjectId
    storage_backend: str = "local"  # "s3" or "local"
    is_image: bool = False
    thumbnail_key: Optional[str] = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    class Settings:
        name = "files"
        indexes = [["uploaded_by"], ["storage_key"]]
