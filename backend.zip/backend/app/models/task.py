from beanie import Document, PydanticObjectId
from pydantic import Field
from typing import Optional, List, Dict, Any
from datetime import datetime, timezone
from enum import Enum


class TaskStatus(str, Enum):
    TODO = "todo"
    IN_PROGRESS = "in_progress"
    IN_REVIEW = "in_review"
    DONE = "done"
    BLOCKED = "blocked"


class TaskPriority(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    URGENT = "urgent"


class ChecklistItem(Document):
    text: str
    is_done: bool = False

    class Settings:
        name = "checklist_items"


class SubTask(Document):
    parent_task_id: PydanticObjectId
    title: str
    description: Optional[str] = None
    assignee_id: Optional[PydanticObjectId] = None
    status: TaskStatus = TaskStatus.TODO
    due_date: Optional[datetime] = None
    is_done: bool = False
    created_by: PydanticObjectId
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    class Settings:
        name = "subtasks"
        indexes = [["parent_task_id"]]


class TaskComment(Document):
    task_id: PydanticObjectId
    author_id: PydanticObjectId
    content: str
    mentioned_user_ids: List[PydanticObjectId] = []
    file_ids: List[PydanticObjectId] = []
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    is_deleted: bool = False

    class Settings:
        name = "task_comments"
        indexes = [["task_id"]]


class TaskAssignmentType(str, Enum):
    INDIVIDUAL = "individual"    # فرد مشخص
    TEAM = "team"                # تیم (مدیر تصمیم می‌گیرد چه کسی انجام دهد)
    TEAM_MEMBER = "team_member"  # عضو مشخص از یک تیم


class TaskReferral(Document):
    """ارجاع/واگذاری تسک"""
    task_id: PydanticObjectId
    from_user_id: PydanticObjectId
    to_user_id: Optional[PydanticObjectId] = None
    to_team_id: Optional[PydanticObjectId] = None
    note: Optional[str] = None
    deadline: Optional[datetime] = None
    file_ids: List[str] = []   # IDs of attached files
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    class Settings:
        name = "task_referrals"
        indexes = [["task_id"], ["to_user_id"]]


class Task(Document):
    title: str
    description: Optional[str] = None
    team_id: Optional[PydanticObjectId] = None
    # نوع انتساب
    assignment_type: TaskAssignmentType = TaskAssignmentType.INDIVIDUAL
    assignee_id: Optional[PydanticObjectId] = None         # فرد اصلی
    assignee_ids: List[PydanticObjectId] = []               # چند نفر (تیمی)
    created_by: PydanticObjectId
    priority: TaskPriority = TaskPriority.MEDIUM
    status: TaskStatus = TaskStatus.TODO
    tags: List[str] = []
    start_date: Optional[datetime] = None
    due_date: Optional[datetime] = None
    completed_at: Optional[datetime] = None

    # ارجاع - زنجیره ارجاع‌ها
    referral_chain: List[Dict[str, Any]] = []  # [{"from": id, "to": id, "note": str, "at": datetime}]

    # محاسبه تاخیر: مثبت = دیرتر از موعد (ساعت)، منفی = زودتر از موعد
    delay_hours: Optional[float] = None
    is_overdue: bool = False

    checklist: List[Dict[str, Any]] = []      # [{"text": str, "is_done": bool}]
    file_ids: List[PydanticObjectId] = []
    watcher_ids: List[PydanticObjectId] = []

    # آخرین فعالیت (برای شناسایی تسک‌های راکد)
    last_activity_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    class Settings:
        name = "tasks"
        indexes = [["team_id"], ["assignee_id"], ["assignee_ids"], ["status"], ["due_date"],
                   ["created_by"], ["is_overdue"]]


class TaskAuditLog(Document):
    task_id: PydanticObjectId
    user_id: PydanticObjectId
    action: str                           # "created", "status_changed", "assigned", etc.
    field: Optional[str] = None
    old_value: Optional[Any] = None
    new_value: Optional[Any] = None
    description: Optional[str] = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    class Settings:
        name = "task_audit_logs"
        indexes = [["task_id"], ["user_id"]]
