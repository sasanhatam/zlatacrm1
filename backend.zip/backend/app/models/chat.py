from beanie import Document, PydanticObjectId
from pydantic import Field
from typing import Optional, List, Dict
from datetime import datetime, timezone
from enum import Enum


class RoomType(str, Enum):
    DIRECT = "direct"
    GROUP = "group"


class MessageType(str, Enum):
    TEXT = "text"
    FILE = "file"
    IMAGE = "image"
    SYSTEM = "system"


class ChatRoom(Document):
    name: Optional[str] = None           # برای گروه‌ها
    type: RoomType = RoomType.DIRECT
    member_ids: List[PydanticObjectId] = []
    admin_ids: List[PydanticObjectId] = []
    avatar_key: Optional[str] = None
    last_message_at: Optional[datetime] = None
    last_message_preview: Optional[str] = None
    created_by: PydanticObjectId
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    is_active: bool = True

    class Settings:
        name = "chat_rooms"
        indexes = [["member_ids"]]


class Message(Document):
    room_id: PydanticObjectId
    sender_id: PydanticObjectId
    type: MessageType = MessageType.TEXT
    content: Optional[str] = None
    file_id: Optional[PydanticObjectId] = None  # FileMetadata id
    mentioned_user_ids: List[PydanticObjectId] = []
    # read_by: {user_id_str: datetime}
    read_by: Dict[str, datetime] = {}
    is_deleted: bool = False
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    edited_at: Optional[datetime] = None

    class Settings:
        name = "messages"
        indexes = [["room_id"], ["sender_id"], ["created_at"]]
