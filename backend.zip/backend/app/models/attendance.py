from beanie import Document, PydanticObjectId
from pydantic import Field
from typing import Optional
from datetime import datetime, timezone


class AttendanceRecord(Document):
    user_id: PydanticObjectId
    work_date: str          # "2024-01-15" — calendar date in Tehran timezone
    jalali_date: str        # "۱۴۰۲/۱۰/۲۵" — for display
    clock_in: datetime
    clock_out: Optional[datetime] = None
    duration_minutes: Optional[int] = None  # filled on clock-out
    note: Optional[str] = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    class Settings:
        name = "attendance_records"
        indexes = [
            ["user_id"],
            ["work_date"],
            [("user_id", 1), ("work_date", 1)],
        ]
