from beanie import Document, PydanticObjectId
from pydantic import Field
from typing import Optional, List, Any
from datetime import datetime, timezone
from enum import Enum


class LetterType(str, Enum):
    OUTGOING = "outgoing"    # صادره - از سازمان به خارج
    INCOMING = "incoming"    # وارده - از خارج به سازمان
    INTERNAL = "internal"   # داخلی - بین بخش‌های سازمان


class LetterStatus(str, Enum):
    DRAFT = "draft"                    # پیش‌نویس
    PENDING_APPROVAL = "pending"       # در انتظار تأیید
    APPROVED = "approved"              # تأیید شده
    SENT = "sent"                      # ارسال شده
    ARCHIVED = "archived"              # بایگانی
    REJECTED = "rejected"              # رد شده


class LetterPriority(str, Enum):
    NORMAL = "normal"       # عادی
    URGENT = "urgent"       # فوری
    VERY_URGENT = "very_urgent"  # خیلی فوری
    CONFIDENTIAL = "confidential"  # محرمانه


class ReferralAction(str, Enum):
    FOR_ACTION = "for_action"        # جهت اقدام
    FOR_INFO = "for_info"            # جهت اطلاع
    FOR_RESPONSE = "for_response"    # جهت پاسخ
    FOR_REVIEW = "for_review"        # جهت بررسی
    FOR_ARCHIVE = "for_archive"      # جهت بایگانی


class LetterReferral(Document):
    """ارجاع نامه"""
    letter_id: PydanticObjectId
    from_user_id: PydanticObjectId
    to_user_id: PydanticObjectId
    action: ReferralAction = ReferralAction.FOR_ACTION
    note: Optional[str] = None
    deadline: Optional[datetime] = None
    is_read: bool = False
    read_at: Optional[datetime] = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    class Settings:
        name = "letter_referrals"
        indexes = [["letter_id"], ["to_user_id"], ["from_user_id"]]


class LetterComment(Document):
    """یادداشت روی نامه"""
    letter_id: PydanticObjectId
    author_id: PydanticObjectId
    content: str
    is_private: bool = False  # یادداشت خصوصی
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    class Settings:
        name = "letter_comments"
        indexes = [["letter_id"]]


class OfficialLetter(Document):
    """نامه رسمی"""
    letter_number: str = ""                       # شماره نامه (خودکار)
    letter_type: LetterType = LetterType.OUTGOING
    status: LetterStatus = LetterStatus.DRAFT
    priority: LetterPriority = LetterPriority.NORMAL

    subject: str                                  # موضوع
    body: str                                     # متن نامه

    # فرستنده
    sender_id: PydanticObjectId
    sender_department: Optional[str] = None       # واحد فرستنده

    # گیرنده
    recipient_name: str = ""                      # نام گیرنده
    recipient_organization: Optional[str] = None  # سازمان گیرنده
    recipient_department: Optional[str] = None    # واحد گیرنده
    recipient_user_id: Optional[PydanticObjectId] = None  # گیرنده داخلی

    # رونوشت
    cc_user_ids: List[PydanticObjectId] = []      # رونوشت داخلی
    cc_external: List[str] = []                   # رونوشت خارجی

    # امضا
    signer_id: Optional[PydanticObjectId] = None  # امضاکننده
    additional_signer_ids: List[PydanticObjectId] = []  # امضاکنندگان اضافی
    signed_at: Optional[datetime] = None

    # تأیید
    approved_by: Optional[PydanticObjectId] = None
    approved_at: Optional[datetime] = None
    rejection_reason: Optional[str] = None

    # پاسخ به
    reply_to_id: Optional[PydanticObjectId] = None

    # پیوست‌ها
    file_ids: List[PydanticObjectId] = []

    # تاریخ‌ها
    jalali_date: str = ""                         # تاریخ جلالی
    letter_date: Optional[datetime] = None        # تاریخ نامه

    # PDF
    pdf_key: Optional[str] = None

    # مهر و امضا
    is_stamped: bool = False
    stamped_by: Optional[PydanticObjectId] = None
    stamped_at: Optional[datetime] = None
    stamp_note: Optional[str] = None

    # امضای دیجیتال روی نامه
    signature_applied: bool = False
    signature_applied_by: Optional[PydanticObjectId] = None
    signature_applied_at: Optional[datetime] = None

    # ارجاعات (خلاصه)
    referral_ids: List[PydanticObjectId] = []

    # نقش‌های نامه (workflow roles)
    requester_id: Optional[PydanticObjectId] = None    # درخواست‌دهنده
    actor_id: Optional[PydanticObjectId] = None        # اقدام‌کننده/اجراکننده
    dispatcher_id: Optional[PydanticObjectId] = None   # ارسال‌کننده
    organization_id: Optional[PydanticObjectId] = None # شرکت مربوطه

    # بایگانی
    archive_code: Optional[str] = None

    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    class Settings:
        name = "official_letters"
        indexes = [["letter_number"], ["letter_type"], ["status"], ["sender_id"],
                   ["recipient_user_id"], ["created_at"]]


class LetterCounter(Document):
    year: int
    outgoing_count: int = 0
    incoming_count: int = 0
    internal_count: int = 0

    class Settings:
        name = "letter_counters"
        indexes = [["year"]]
