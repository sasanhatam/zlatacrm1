from beanie import Document, PydanticObjectId
from pydantic import Field
from typing import Optional, List
from datetime import datetime, timezone
from enum import Enum


class NotificationType(str, Enum):
    TASK_ASSIGNED = "task_assigned"
    TASK_COMPLETED = "task_completed"
    TASK_OVERDUE = "task_overdue"
    DEADLINE_REMINDER = "deadline_reminder"
    MENTION = "mention"
    ANNOUNCEMENT = "announcement"
    CHAT_MESSAGE = "chat_message"
    SYSTEM = "system"


class NotificationPriority(str, Enum):
    NORMAL = "normal"
    IMPORTANT = "important"
    URGENT = "urgent"


class Notification(Document):
    recipient_id: PydanticObjectId
    type: NotificationType
    priority: NotificationPriority = NotificationPriority.NORMAL
    title: str
    body: str
    link: Optional[str] = None        # link to task/chat/etc.
    is_read: bool = False
    metadata: dict = {}               # extra data (task_id, room_id, etc.)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    class Settings:
        name = "notifications"
        indexes = [["recipient_id"], ["is_read"], ["created_at"]]


class Announcement(Document):
    title: str
    body: str
    priority: NotificationPriority = NotificationPriority.NORMAL
    author_id: PydanticObjectId
    # None = همه سازمان؛ list = تیم‌های خاص
    target_team_ids: Optional[List[PydanticObjectId]] = None
    is_active: bool = True
    expires_at: Optional[datetime] = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    class Settings:
        name = "announcements"
        indexes = [["is_active"], ["created_at"]]
