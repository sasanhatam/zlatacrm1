from beanie import Document, PydanticObjectId
from pydantic import Field
from typing import Optional
from datetime import datetime, timezone


class SystemSettings(Document):
    """Singleton document — always one record."""
    smtp_host: str = "smtp.gmail.com"
    smtp_port: int = 587
    smtp_username: str = ""
    smtp_password: str = ""
    smtp_from_email: str = ""
    smtp_from_name: str = "Zlata Management"
    smtp_use_tls: bool = True

    org_name: str = "Zlata Management"
    org_logo_key: Optional[str] = None
    org_address: Optional[str] = None
    org_phone: Optional[str] = None
    org_website: Optional[str] = None

    stale_task_days: int = 7          # روز بدون فالو‌آپ = راکد

    # ── سربرگ رسمی نامه ──────────────────────────────────────────────
    letterhead_org_name: str = ""           # نام رسمی سازمان (روی سربرگ)
    letterhead_org_name_en: str = ""        # نام انگلیسی
    letterhead_address: str = ""            # آدرس روی سربرگ
    letterhead_phone: str = ""              # تلفن روی سربرگ
    letterhead_fax: str = ""               # فکس
    letterhead_postal_code: str = ""        # کد پستی
    letterhead_website: str = ""            # وبسایت روی سربرگ
    letterhead_email: str = ""             # ایمیل روی سربرگ
    letterhead_reg_number: str = ""         # شماره ثبت / کد ملی
    letterhead_logo_data: Optional[str] = None   # base64 لوگو
    letterhead_stamp_data: Optional[str] = None  # base64 مهر سازمانی
    letterhead_footer_text: str = ""        # متن پاورقی سربرگ
    letterhead_color: str = "#1e3a5f"       # رنگ اصلی سربرگ
    letterhead_secondary_color: str = "#2d6a9f"  # رنگ ثانوی
    # تصویر سربرگ کامل (هدر و فوتر) — پیش‌فرض سیستم
    letterhead_header_data: Optional[str] = None  # base64 — تصویر هدر عرض کامل
    letterhead_footer_data: Optional[str] = None  # base64 — تصویر فوتر عرض کامل

    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    class Settings:
        name = "system_settings"


class PushSubscription(Document):
    user_id: PydanticObjectId
    endpoint: str
    p256dh: str
    auth: str
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    class Settings:
        name = "push_subscriptions"
        indexes = [["user_id"]]


class RefreshToken(Document):
    user_id: PydanticObjectId
    token: str
    expires_at: datetime
    is_revoked: bool = False
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    class Settings:
        name = "refresh_tokens"
        indexes = [["token"], ["user_id"]]
