from beanie import Document, PydanticObjectId
from pydantic import Field
from typing import Optional, Dict, Any
from datetime import datetime, timezone


class ActivityLog(Document):
    user_id: Optional[PydanticObjectId] = None
    user_name: str = ""
    user_mobile: str = ""
    action: str  # e.g. "login", "logout", "task_create", "letter_send", ...
    resource_type: str = ""  # e.g. "task", "letter", "user", "auth"
    resource_id: str = ""
    resource_title: str = ""
    details: Dict[str, Any] = {}
    ip_address: str = ""
    jalali_datetime: str = ""  # e.g. "۱۴۰۳/۱۰/۱۵ ۱۴:۳۲:۰۵"
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    class Settings:
        name = "activity_logs"
        indexes = [["user_id"], ["action"], ["resource_type"], ["created_at"]]
