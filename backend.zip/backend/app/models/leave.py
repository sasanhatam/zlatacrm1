from beanie import Document, PydanticObjectId
from pydantic import Field
from typing import Optional, List
from datetime import datetime, date, timezone
from enum import Enum


class LeaveType(str, Enum):
    ANNUAL = "annual"          # مرخصی سالیانه
    SICK = "sick"              # مرخصی استعلاجی
    MATERNITY = "maternity"    # مرخصی زایمان
    EMERGENCY = "emergency"    # مرخصی اضطراری
    UNPAID = "unpaid"          # مرخصی بدون حقوق
    HOURLY = "hourly"          # مرخصی ساعتی


class LeaveStatus(str, Enum):
    PENDING = "pending"        # در انتظار تأیید
    APPROVED = "approved"      # تأیید شده
    REJECTED = "rejected"      # رد شده
    CANCELLED = "cancelled"    # لغو شده


class LeaveBalance(Document):
    """موجودی مرخصی کارمند"""
    user_id: PydanticObjectId
    year: int
    annual_total: float = 30.0       # کل روز مرخصی سالیانه
    annual_used: float = 0.0         # مرخصی استفاده شده
    sick_used: float = 0.0
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    class Settings:
        name = "leave_balances"
        indexes = [["user_id", "year"]]


class LeaveRequest(Document):
    user_id: PydanticObjectId
    leave_type: LeaveType = LeaveType.ANNUAL
    status: LeaveStatus = LeaveStatus.PENDING

    start_date: datetime
    end_date: datetime
    days_count: float = 1.0           # تعداد روز

    reason: Optional[str] = None
    manager_note: Optional[str] = None

    reviewed_by: Optional[PydanticObjectId] = None
    reviewed_at: Optional[datetime] = None

    # اطلاع‌رسانی به اعضای تیم
    notified_team: bool = False

    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    class Settings:
        name = "leave_requests"
        indexes = [["user_id"], ["status"], ["start_date"]]
