from beanie import Document, PydanticObjectId
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime, timezone
from enum import Enum


class SEOStatus(str, Enum):
    DRAFT = "draft"
    IN_PROGRESS = "in_progress"
    REVIEW = "review"
    PUBLISHED = "published"


class SEOContent(Document):
    title: str
    keyword: str = ""
    url: str = ""
    anchor_text: str = ""
    body_html: str = ""
    seo_title: str = ""
    meta_description: str = ""
    internal_link_text: str = ""
    status: SEOStatus = SEOStatus.DRAFT
    assignee_id: Optional[PydanticObjectId] = None
    created_by: PydanticObjectId
    publish_date: Optional[datetime] = None
    featured_image_data: Optional[str] = None   # base64
    extra_image_data: List[str] = []            # base64 list
    schema_code: str = ""                        # JSON-LD structured data
    created_at: datetime = datetime.now(timezone.utc)
    updated_at: datetime = datetime.now(timezone.utc)

    class Settings:
        name = "seo_contents"
        indexes = [["created_by"], ["assignee_id"], ["status"]]
