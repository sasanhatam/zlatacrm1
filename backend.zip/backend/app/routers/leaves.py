from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime, timezone
from beanie import PydanticObjectId

from app.models.leave import LeaveRequest, LeaveBalance, LeaveType, LeaveStatus
from app.models.user import User, UserRole, Team
from app.core.deps import get_current_user

router = APIRouter(prefix="/api/leaves", tags=["leaves"])


class LeaveCreate(BaseModel):
    leave_type: LeaveType = LeaveType.ANNUAL
    start_date: datetime
    end_date: datetime
    days_count: float = 1.0
    reason: Optional[str] = None


class LeaveReview(BaseModel):
    approved: bool
    note: Optional[str] = None


def _leave_to_dict(l: LeaveRequest) -> dict:
    d = l.model_dump()
    d["id"] = str(l.id)
    d["user_id"] = str(l.user_id)
    if l.reviewed_by:
        d["reviewed_by"] = str(l.reviewed_by)
    return d


@router.post("")
async def request_leave(body: LeaveCreate, me: User = Depends(get_current_user)):
    if body.end_date < body.start_date:
        raise HTTPException(400, "تاریخ پایان باید بعد از تاریخ شروع باشد")

    leave = LeaveRequest(
        user_id=me.id,
        leave_type=body.leave_type,
        start_date=body.start_date,
        end_date=body.end_date,
        days_count=body.days_count,
        reason=body.reason,
    )
    await leave.insert()
    return _leave_to_dict(leave)


@router.get("")
async def list_leaves(
    user_id: Optional[str] = None,
    status: Optional[LeaveStatus] = None,
    me: User = Depends(get_current_user)
):
    conditions = []

    if me.role in (UserRole.SUPER_ADMIN, UserRole.MANAGER):
        if user_id:
            conditions.append({"user_id": PydanticObjectId(user_id)})
    else:
        conditions.append({"user_id": me.id})

    if status:
        conditions.append({"status": status})

    query = {"$and": conditions} if conditions else {}
    leaves = await LeaveRequest.find(query).sort(-LeaveRequest.created_at).to_list()
    result = []
    for l in leaves:
        d = _leave_to_dict(l)
        user = await User.get(l.user_id)
        d["user_name"] = user.full_name if user else ""
        result.append(d)
    return result


@router.get("/team")
async def get_team_leaves(me: User = Depends(get_current_user)):
    """مرخصی‌های اعضای تیم (برای مدیر)"""
    if me.role not in (UserRole.SUPER_ADMIN, UserRole.MANAGER, UserRole.TEAM_LEAD):
        raise HTTPException(403, "دسترسی ندارید")

    my_teams = await Team.find({"$or": [
        {"manager_id": me.id},
        {"lead_id": me.id},
    ]}).to_list()

    all_member_ids = set()
    for t in my_teams:
        all_member_ids.update([str(x) for x in t.member_ids])

    leaves = await LeaveRequest.find(
        {"user_id": {"$in": [PydanticObjectId(x) for x in all_member_ids]}}
    ).sort(-LeaveRequest.start_date).to_list()

    result = []
    for l in leaves:
        d = _leave_to_dict(l)
        user = await User.get(l.user_id)
        d["user_name"] = user.full_name if user else ""
        result.append(d)
    return result


@router.get("/balance")
async def get_my_balance(me: User = Depends(get_current_user)):
    """موجودی مرخصی من"""
    year = datetime.now(timezone.utc).year
    balance = await LeaveBalance.find_one(
        {"user_id": me.id, "year": year}
    )
    if not balance:
        balance = LeaveBalance(user_id=me.id, year=year)
        await balance.insert()
    d = balance.model_dump()
    d["id"] = str(balance.id)
    d["user_id"] = str(balance.user_id)
    d["remaining"] = balance.annual_total - balance.annual_used
    return d


@router.get("/{leave_id}")
async def get_leave(leave_id: str, me: User = Depends(get_current_user)):
    leave = await LeaveRequest.get(leave_id)
    if not leave:
        raise HTTPException(404, "درخواست مرخصی یافت نشد")
    if str(leave.user_id) != str(me.id) and me.role not in (UserRole.SUPER_ADMIN, UserRole.MANAGER):
        raise HTTPException(403, "دسترسی ندارید")
    return _leave_to_dict(leave)


@router.post("/{leave_id}/review")
async def review_leave(leave_id: str, body: LeaveReview, me: User = Depends(get_current_user)):
    """تأیید یا رد درخواست مرخصی"""
    if me.role not in (UserRole.SUPER_ADMIN, UserRole.MANAGER, UserRole.TEAM_LEAD):
        raise HTTPException(403, "دسترسی ندارید")

    leave = await LeaveRequest.get(leave_id)
    if not leave:
        raise HTTPException(404, "درخواست مرخصی یافت نشد")
    if leave.status != LeaveStatus.PENDING:
        raise HTTPException(400, "این درخواست قبلاً بررسی شده")

    leave.status = LeaveStatus.APPROVED if body.approved else LeaveStatus.REJECTED
    leave.manager_note = body.note
    leave.reviewed_by = me.id
    leave.reviewed_at = datetime.now(timezone.utc)
    leave.updated_at = datetime.now(timezone.utc)
    await leave.save()

    # به‌روزرسانی موجودی مرخصی
    if body.approved and leave.leave_type == LeaveType.ANNUAL:
        year = leave.start_date.year
        balance = await LeaveBalance.find_one({"user_id": leave.user_id, "year": year})
        if not balance:
            balance = LeaveBalance(user_id=leave.user_id, year=year)
            await balance.insert()
        balance.annual_used += leave.days_count
        balance.updated_at = datetime.now(timezone.utc)
        await balance.save()

    return _leave_to_dict(leave)


@router.delete("/{leave_id}")
async def cancel_leave(leave_id: str, me: User = Depends(get_current_user)):
    """لغو درخواست مرخصی"""
    leave = await LeaveRequest.get(leave_id)
    if not leave:
        raise HTTPException(404, "درخواست مرخصی یافت نشد")
    if str(leave.user_id) != str(me.id):
        raise HTTPException(403, "دسترسی ندارید")
    if leave.status not in (LeaveStatus.PENDING,):
        raise HTTPException(400, "فقط درخواست‌های در انتظار قابل لغو هستند")
    leave.status = LeaveStatus.CANCELLED
    leave.updated_at = datetime.now(timezone.utc)
    await leave.save()
    return {"ok": True}
