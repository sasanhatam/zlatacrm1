from fastapi import APIRouter, Depends, Query
from typing import Optional
from datetime import datetime, timezone
from app.models.activity_log import ActivityLog
from app.core.permissions import require_manager
from app.deps import get_current_user
from app.models.user import User

router = APIRouter(prefix="/activity-logs", tags=["activity-logs"])


@router.get("")
async def list_activity_logs(
    action: Optional[str] = Query(None),
    resource_type: Optional[str] = Query(None),
    user_id: Optional[str] = Query(None),
    from_date: Optional[str] = Query(None, description="ISO date, e.g. 2024-01-01"),
    to_date: Optional[str] = Query(None, description="ISO date, e.g. 2024-01-31"),
    page: int = Query(1, ge=1),
    limit: int = Query(50, ge=1, le=200),
    current_user: User = Depends(require_manager),
):
    filters = []
    if action:
        filters.append(ActivityLog.action == action)
    if resource_type:
        filters.append(ActivityLog.resource_type == resource_type)
    if user_id:
        from beanie import PydanticObjectId
        filters.append(ActivityLog.user_id == PydanticObjectId(user_id))
    if from_date:
        try:
            dt = datetime.fromisoformat(from_date).replace(tzinfo=timezone.utc)
            filters.append(ActivityLog.created_at >= dt)
        except ValueError:
            pass
    if to_date:
        try:
            # include all of to_date by going to end of day
            dt = datetime.fromisoformat(to_date).replace(hour=23, minute=59, second=59, tzinfo=timezone.utc)
            filters.append(ActivityLog.created_at <= dt)
        except ValueError:
            pass

    skip = (page - 1) * limit
    query = ActivityLog.find(*filters).sort(-ActivityLog.created_at)
    total = await query.count()
    logs = await query.skip(skip).limit(limit).to_list()

    return {
        "total": total,
        "page": page,
        "limit": limit,
        "items": [
            {
                "id": str(log.id),
                "user_id": str(log.user_id) if log.user_id else None,
                "user_name": log.user_name,
                "user_mobile": log.user_mobile,
                "action": log.action,
                "resource_type": log.resource_type,
                "resource_id": log.resource_id,
                "resource_title": log.resource_title,
                "details": log.details,
                "ip_address": log.ip_address,
                "jalali_datetime": log.jalali_datetime,
                "created_at": log.created_at.isoformat(),
            }
            for log in logs
        ],
    }


@router.get("/users")
async def list_users_for_filter(current_user: User = Depends(require_manager)):
    """لیست کاربران برای فیلتر لاگ"""
    users = await User.find(User.is_active == True).sort(User.full_name).to_list()
    return [{"id": str(u.id), "full_name": u.full_name, "mobile": u.mobile} for u in users]
