from fastapi import APIRouter, Depends, Request
from datetime import datetime, timezone, timedelta
from beanie import PydanticObjectId
from app.schemas.auth import (
    LoginRequest, TokenResponse, RefreshRequest, PasswordChangeRequest,
    RegistrationRequestCreate, RegistrationRequestReject,
)
from app.models.user import User, RegistrationRequest, RegistrationRequestStatus
from app.models.system import RefreshToken
from app.core.security import (
    verify_password, create_access_token, create_refresh_token, hash_password
)
from app.core.exceptions import AuthenticationError, NotFoundError, ConflictError
from app.core.permissions import require_manager
from app.deps import get_current_user
from app.config import settings
from app.core.activity import log_activity
import structlog

logger = structlog.get_logger()
router = APIRouter(prefix="/auth", tags=["auth"])


@router.post("/login", response_model=TokenResponse)
async def login(data: LoginRequest, request: Request):
    user = await User.find_one(User.mobile == data.mobile)
    if not user or not verify_password(data.password, user.hashed_password):
        logger.warning("login_failed", mobile=data.mobile, ip=request.client.host)
        raise AuthenticationError("شماره موبایل یا رمز عبور اشتباه است")
    if not user.is_active:
        raise AuthenticationError("حساب کاربری غیرفعال است")

    access_token = create_access_token({"sub": str(user.id), "role": user.role})
    refresh_token_str = create_refresh_token()

    rt = RefreshToken(
        user_id=user.id,
        token=refresh_token_str,
        expires_at=datetime.now(timezone.utc) + timedelta(days=settings.REFRESH_TOKEN_EXPIRE_DAYS),
    )
    await rt.insert()

    user.last_login = datetime.now(timezone.utc)
    await user.save()

    await log_activity("login", resource_type="auth", resource_title=user.full_name,
                       details={"mobile": user.mobile, "role": user.role},
                       user=user, ip_address=request.client.host if request.client else "")

    logger.info("login_success", user_id=str(user.id))
    return TokenResponse(
        access_token=access_token,
        refresh_token=refresh_token_str,
        expires_in=settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
    )


@router.post("/refresh", response_model=TokenResponse)
async def refresh_token(data: RefreshRequest):
    rt = await RefreshToken.find_one(
        RefreshToken.token == data.refresh_token,
        RefreshToken.is_revoked == False,
    )
    if not rt or rt.expires_at.replace(tzinfo=timezone.utc) < datetime.now(timezone.utc):
        raise AuthenticationError("توکن رفرش نامعتبر یا منقضی است")

    user = await User.get(rt.user_id)
    if not user or not user.is_active:
        raise AuthenticationError("کاربر یافت نشد")

    rt.is_revoked = True
    await rt.save()

    new_refresh = create_refresh_token()
    new_rt = RefreshToken(
        user_id=user.id,
        token=new_refresh,
        expires_at=datetime.now(timezone.utc) + timedelta(days=settings.REFRESH_TOKEN_EXPIRE_DAYS),
    )
    await new_rt.insert()

    access_token = create_access_token({"sub": str(user.id), "role": user.role})
    return TokenResponse(
        access_token=access_token,
        refresh_token=new_refresh,
        expires_in=settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
    )


@router.post("/logout")
async def logout(data: RefreshRequest, current_user: User = Depends(get_current_user)):
    rt = await RefreshToken.find_one(
        RefreshToken.token == data.refresh_token,
        RefreshToken.user_id == current_user.id,
    )
    if rt:
        rt.is_revoked = True
        await rt.save()
    await log_activity("logout", resource_type="auth", resource_title=current_user.full_name,
                       user=current_user)
    return {"message": "با موفقیت خارج شدید"}


@router.post("/change-password")
async def change_password(
    data: PasswordChangeRequest,
    current_user: User = Depends(get_current_user),
):
    if not verify_password(data.current_password, current_user.hashed_password):
        raise AuthenticationError("رمز عبور فعلی اشتباه است")
    current_user.hashed_password = hash_password(data.new_password)
    await current_user.save()
    await log_activity("change_password", resource_type="auth", resource_title=current_user.full_name,
                       user=current_user)
    return {"message": "رمز عبور با موفقیت تغییر کرد"}


@router.get("/me")
async def get_me(current_user: User = Depends(get_current_user)):
    return {
        "id": str(current_user.id),
        "email": current_user.email,
        "full_name": current_user.full_name,
        "role": current_user.role,
        "position": current_user.position,
        "team_ids": [str(t) for t in current_user.team_ids],
        "mobile": current_user.mobile,
        "extension_number": current_user.extension_number,
        "notification_email": current_user.notification_email,
        "email_notifications_enabled": current_user.email_notifications_enabled,
        "notification_preferences": current_user.notification_preferences,
        "is_active": current_user.is_active,
        "organization_ids": [str(o) for o in current_user.organization_ids],
        "signature_data": current_user.signature_data,
        "stamp_data": current_user.stamp_data,
    }


# ─── Registration Requests ────────────────────────────────────────────────────

@router.post("/register-request", status_code=201)
async def submit_registration_request(data: RegistrationRequestCreate):
    """کاربر جدید درخواست افتتاح حساب می‌دهد — بدون نیاز به احراز هویت"""
    existing_user = await User.find_one(User.mobile == data.mobile)
    if existing_user:
        raise ConflictError("این شماره موبایل قبلاً ثبت شده است")

    existing_req = await RegistrationRequest.find_one(
        RegistrationRequest.mobile == data.mobile,
        RegistrationRequest.status == RegistrationRequestStatus.PENDING,
    )
    if existing_req:
        raise ConflictError("یک درخواست در انتظار بررسی برای این شماره وجود دارد")

    from app.models.user import Organization
    org_ids = [PydanticObjectId(o) for o in data.organization_ids if o]

    req = RegistrationRequest(
        full_name=data.full_name,
        mobile=data.mobile,
        hashed_password=hash_password(data.password),
        requested_org_ids=org_ids,
    )
    await req.insert()
    await log_activity("register_request_submit", resource_type="registration",
                       resource_id=str(req.id), resource_title=data.full_name,
                       details={"mobile": data.mobile, "org_count": len(org_ids)})
    return {"message": "درخواست شما ثبت شد و پس از تایید مدیر حساب شما فعال می‌شود", "id": str(req.id)}


@router.get("/register-requests", dependencies=[Depends(require_manager)])
async def list_registration_requests(status: str = "pending"):
    allowed = {"pending", "approved", "rejected"}
    if status not in allowed:
        status = "pending"
    requests = await RegistrationRequest.find(
        RegistrationRequest.status == RegistrationRequestStatus(status)
    ).sort(-RegistrationRequest.created_at).to_list()

    return [
        {
            "id": str(r.id),
            "full_name": r.full_name,
            "mobile": r.mobile,
            "status": r.status,
            "rejection_reason": r.rejection_reason,
            "requested_org_ids": [str(o) for o in r.requested_org_ids],
            "created_at": r.created_at.isoformat(),
            "reviewed_at": r.reviewed_at.isoformat() if r.reviewed_at else None,
        }
        for r in requests
    ]


@router.post("/register-requests/{req_id}/approve", dependencies=[Depends(require_manager)])
async def approve_registration_request(
    req_id: str,
    current_user: User = Depends(get_current_user),
):
    req = await RegistrationRequest.get(PydanticObjectId(req_id))
    if not req:
        raise NotFoundError("درخواست یافت نشد")
    if req.status != RegistrationRequestStatus.PENDING:
        raise ConflictError("این درخواست قبلاً بررسی شده است")

    existing = await User.find_one(User.mobile == req.mobile)
    if existing:
        req.status = RegistrationRequestStatus.APPROVED
        req.reviewed_by = current_user.id
        req.reviewed_at = datetime.now(timezone.utc)
        await req.save()
        raise ConflictError("این شماره موبایل قبلاً ثبت شده است")

    new_user = User(
        email=f"{req.mobile}@zlata.local",   # placeholder email
        hashed_password=req.hashed_password,
        full_name=req.full_name,
        mobile=req.mobile,
        role="member",
        is_active=True,
        organization_ids=req.requested_org_ids,
    )
    await new_user.insert()

    req.status = RegistrationRequestStatus.APPROVED
    req.reviewed_by = current_user.id
    req.reviewed_at = datetime.now(timezone.utc)
    await req.save()

    await log_activity("register_request_approve", resource_type="registration",
                       resource_id=str(req.id), resource_title=req.full_name,
                       details={"mobile": req.mobile, "new_user_id": str(new_user.id)},
                       user=current_user)
    return {"message": f"حساب کاربری برای {req.full_name} ایجاد شد", "user_id": str(new_user.id)}


@router.post("/register-requests/{req_id}/reject", dependencies=[Depends(require_manager)])
async def reject_registration_request(
    req_id: str,
    data: RegistrationRequestReject,
    current_user: User = Depends(get_current_user),
):
    req = await RegistrationRequest.get(PydanticObjectId(req_id))
    if not req:
        raise NotFoundError("درخواست یافت نشد")
    if req.status != RegistrationRequestStatus.PENDING:
        raise ConflictError("این درخواست قبلاً بررسی شده است")

    req.status = RegistrationRequestStatus.REJECTED
    req.rejection_reason = data.reason
    req.reviewed_by = current_user.id
    req.reviewed_at = datetime.now(timezone.utc)
    await req.save()
    await log_activity("register_request_reject", resource_type="registration",
                       resource_id=str(req.id), resource_title=req.full_name,
                       details={"mobile": req.mobile, "reason": data.reason},
                       user=current_user)
    return {"message": "درخواست رد شد"}


@router.get("/companies-public")
async def list_companies_public():
    """لیست شرکت‌ها برای فرم ثبت‌نام — بدون نیاز به احراز هویت"""
    from app.models.user import Organization
    orgs = await Organization.find_all().to_list()
    return [{"id": str(o.id), "name": o.name} for o in orgs]
