from fastapi import APIRouter, Depends, WebSocket, WebSocketDisconnect, Query
from typing import List, Optional
from beanie import PydanticObjectId
from app.schemas.notification import (
    NotificationResponse, AnnouncementCreate, AnnouncementResponse, PushSubscriptionCreate
)
from app.models.notification import Notification, Announcement, NotificationPriority
from app.models.system import PushSubscription
from app.models.user import User
from app.core.permissions import require_member, require_super_admin, require_manager
from app.core.security import decode_access_token
from app.deps import get_current_user
from app.websocket.manager import manager
import structlog

logger = structlog.get_logger()
router = APIRouter(prefix="/notifications", tags=["notifications"])


@router.get("", dependencies=[Depends(require_member)])
async def list_notifications(
    is_read: Optional[bool] = Query(None),
    limit: int = Query(50, le=100),
    current_user: User = Depends(get_current_user),
):
    filters = [Notification.recipient_id == current_user.id]
    if is_read is not None:
        filters.append(Notification.is_read == is_read)
    notifs = await Notification.find(*filters).sort("-created_at").limit(limit).to_list()
    return [{
        "id": str(n.id), "type": n.type, "priority": n.priority,
        "title": n.title, "body": n.body, "link": n.link,
        "is_read": n.is_read, "metadata": n.metadata, "created_at": n.created_at,
    } for n in notifs]


@router.get("/unread-count", dependencies=[Depends(require_member)])
async def unread_count(current_user: User = Depends(get_current_user)):
    count = await Notification.find(
        Notification.recipient_id == current_user.id,
        Notification.is_read == False,
    ).count()
    return {"count": count}


@router.post("/mark-read/{notif_id}", dependencies=[Depends(require_member)])
async def mark_read(notif_id: str, current_user: User = Depends(get_current_user)):
    notif = await Notification.get(PydanticObjectId(notif_id))
    if notif and notif.recipient_id == current_user.id:
        notif.is_read = True
        await notif.save()
    return {"ok": True}


@router.post("/mark-all-read", dependencies=[Depends(require_member)])
async def mark_all_read(current_user: User = Depends(get_current_user)):
    notifs = await Notification.find(
        Notification.recipient_id == current_user.id,
        Notification.is_read == False,
    ).to_list()
    for n in notifs:
        n.is_read = True
        await n.save()
    return {"marked": len(notifs)}


# ─── Announcements ────────────────────────────────────────────────────────────

@router.get("/announcements", dependencies=[Depends(require_member)])
async def list_announcements(current_user: User = Depends(get_current_user)):
    from datetime import datetime, timezone
    now = datetime.now(timezone.utc)
    all_ann = await Announcement.find(
        Announcement.is_active == True,
    ).sort("-created_at").to_list()

    result = []
    for ann in all_ann:
        if ann.expires_at and ann.expires_at.replace(tzinfo=timezone.utc) < now:
            continue
        # بررسی هدف
        if ann.target_team_ids is None:
            result.append(ann)
        else:
            if any(tid in current_user.team_ids for tid in ann.target_team_ids):
                result.append(ann)
    return [{
        "id": str(a.id), "title": a.title, "body": a.body, "priority": a.priority,
        "author_id": str(a.author_id), "is_active": a.is_active,
        "expires_at": a.expires_at, "created_at": a.created_at,
    } for a in result]


@router.post("/announcements", dependencies=[Depends(require_manager)])
async def create_announcement(data: AnnouncementCreate, current_user: User = Depends(get_current_user)):
    ann = Announcement(
        title=data.title,
        body=data.body,
        priority=data.priority,
        author_id=current_user.id,
        target_team_ids=[PydanticObjectId(t) for t in data.target_team_ids] if data.target_team_ids else None,
        expires_at=data.expires_at,
    )
    await ann.insert()

    # ارسال نوتیف realtime به همه کاربران هدف
    from app.models.user import User as UserModel
    users = await UserModel.find(UserModel.is_active == True).to_list()
    for user in users:
        if ann.target_team_ids is None or any(tid in user.team_ids for tid in ann.target_team_ids):
            notif = Notification(
                recipient_id=user.id,
                type="announcement",
                priority=data.priority,
                title=data.title,
                body=data.body[:200],
                metadata={"announcement_id": str(ann.id)},
            )
            await notif.insert()
            await manager.send_to_user(str(user.id), {
                "type": "announcement",
                "data": {"title": data.title, "body": data.body, "priority": data.priority},
            })

    return {"id": str(ann.id), "title": ann.title}


@router.delete("/announcements/{ann_id}", dependencies=[Depends(require_manager)])
async def delete_announcement(ann_id: str):
    ann = await Announcement.get(PydanticObjectId(ann_id))
    if ann:
        ann.is_active = False
        await ann.save()
    return {"ok": True}


# ─── Push Subscriptions ───────────────────────────────────────────────────────

@router.post("/push/subscribe", dependencies=[Depends(require_member)])
async def subscribe_push(data: PushSubscriptionCreate, current_user: User = Depends(get_current_user)):
    existing = await PushSubscription.find_one(PushSubscription.endpoint == data.endpoint)
    if not existing:
        sub = PushSubscription(
            user_id=current_user.id,
            endpoint=data.endpoint,
            p256dh=data.p256dh,
            auth=data.auth,
        )
        await sub.insert()
    return {"ok": True}


@router.delete("/push/unsubscribe", dependencies=[Depends(require_member)])
async def unsubscribe_push(endpoint: str, current_user: User = Depends(get_current_user)):
    sub = await PushSubscription.find_one(
        PushSubscription.endpoint == endpoint,
        PushSubscription.user_id == current_user.id,
    )
    if sub:
        await sub.delete()
    return {"ok": True}


# ─── Notification WebSocket (personal) ───────────────────────────────────────

@router.websocket("/ws")
async def notification_ws(websocket: WebSocket, token: str = Query(...)):
    payload = decode_access_token(token)
    if not payload:
        await websocket.close(code=4001)
        return
    user = await User.get(PydanticObjectId(payload["sub"]))
    if not user:
        await websocket.close(code=4001)
        return

    await manager.connect_user(websocket, str(user.id))
    try:
        while True:
            await websocket.receive_text()  # keep alive
    except WebSocketDisconnect:
        manager.disconnect_user(websocket, str(user.id))
