from fastapi import APIRouter, HTTPException, Depends, Query
from pydantic import BaseModel
from typing import Optional, List, Any
from datetime import datetime, timezone
from beanie import PydanticObjectId

from app.models.letter import (
    OfficialLetter, LetterReferral, LetterComment, LetterCounter,
    LetterType, LetterStatus, LetterPriority, ReferralAction
)
from app.models.user import User, UserRole
from app.core.deps import get_current_user
from app.core.activity import log_activity

router = APIRouter(prefix="/api/letters", tags=["letters"])


# ─── Schemas ──────────────────────────────────────────────────────────────────

class LetterCreate(BaseModel):
    letter_type: LetterType = LetterType.OUTGOING
    subject: str
    body: str
    priority: LetterPriority = LetterPriority.NORMAL
    recipient_name: str = ""
    recipient_organization: Optional[str] = None
    recipient_department: Optional[str] = None
    recipient_user_id: Optional[str] = None
    cc_user_ids: List[str] = []
    reply_to_id: Optional[str] = None
    letter_date: Optional[datetime] = None
    jalali_date: str = ""
    letter_number: Optional[str] = ""  # اختیاری — شماره دستی نامه
    requester_id: Optional[str] = None
    actor_id: Optional[str] = None
    dispatcher_id: Optional[str] = None
    organization_id: Optional[str] = None
    additional_signer_ids: List[str] = []


class LetterUpdate(BaseModel):
    subject: Optional[str] = None
    body: Optional[str] = None
    priority: Optional[LetterPriority] = None
    recipient_name: Optional[str] = None
    recipient_organization: Optional[str] = None
    recipient_department: Optional[str] = None
    recipient_user_id: Optional[str] = None
    jalali_date: Optional[str] = None


class ReferralCreate(BaseModel):
    to_user_id: str
    action: ReferralAction = ReferralAction.FOR_ACTION
    note: Optional[str] = None
    deadline: Optional[datetime] = None


class CommentCreate(BaseModel):
    content: str
    is_private: bool = False


class ApproveRejectBody(BaseModel):
    reason: Optional[str] = None


# ─── Helper ───────────────────────────────────────────────────────────────────

async def _peek_letter_number(letter_type: LetterType) -> str:
    """Returns what the next number WOULD be without incrementing."""
    year = datetime.now(timezone.utc).year
    counter = await LetterCounter.find_one(LetterCounter.year == year)
    prefix_map = {
        LetterType.OUTGOING: ("ص", "outgoing_count"),
        LetterType.INCOMING: ("و", "incoming_count"),
        LetterType.INTERNAL: ("د", "internal_count"),
    }
    prefix, field = prefix_map[letter_type]
    count = (getattr(counter, field) if counter else 0) + 1
    return f"{prefix}/{year}/{count:04d}"


async def _get_letter_number(letter_type: LetterType) -> str:
    year = datetime.now(timezone.utc).year
    counter = await LetterCounter.find_one(LetterCounter.year == year)
    if not counter:
        counter = LetterCounter(year=year)
        await counter.insert()

    prefix_map = {
        LetterType.OUTGOING: ("ص", "outgoing_count"),
        LetterType.INCOMING: ("و", "incoming_count"),
        LetterType.INTERNAL: ("د", "internal_count"),
    }
    prefix, field = prefix_map[letter_type]
    count = getattr(counter, field) + 1
    setattr(counter, field, count)
    await counter.save()
    return f"{prefix}/{year}/{count:04d}"


def _letter_to_dict(letter: OfficialLetter) -> dict:
    d = letter.model_dump()
    d["id"] = str(letter.id)
    if letter.sender_id:
        d["sender_id"] = str(letter.sender_id)
    if letter.recipient_user_id:
        d["recipient_user_id"] = str(letter.recipient_user_id)
    d["cc_user_ids"] = [str(x) for x in letter.cc_user_ids]
    d["file_ids"] = [str(x) for x in letter.file_ids]
    d["referral_ids"] = [str(x) for x in letter.referral_ids]
    if letter.signer_id:
        d["signer_id"] = str(letter.signer_id)
    d["additional_signer_ids"] = [str(x) for x in letter.additional_signer_ids]
    if letter.approved_by:
        d["approved_by"] = str(letter.approved_by)
    if letter.reply_to_id:
        d["reply_to_id"] = str(letter.reply_to_id)
    if letter.stamped_by:
        d["stamped_by"] = str(letter.stamped_by)
    if letter.requester_id:
        d["requester_id"] = str(letter.requester_id)
    if letter.actor_id:
        d["actor_id"] = str(letter.actor_id)
    if letter.dispatcher_id:
        d["dispatcher_id"] = str(letter.dispatcher_id)
    if letter.organization_id:
        d["organization_id"] = str(letter.organization_id)
    return d


# ─── CRUD ─────────────────────────────────────────────────────────────────────

@router.get("/next-number")
async def get_next_letter_number(
    letter_type: LetterType = Query(LetterType.OUTGOING),
    _: User = Depends(get_current_user),
):
    """Preview the next auto-assigned number without consuming it."""
    return {"number": await _peek_letter_number(letter_type)}


@router.post("")
async def create_letter(body: LetterCreate, me: User = Depends(get_current_user)):
    letter = OfficialLetter(
        letter_type=body.letter_type,
        subject=body.subject,
        body=body.body,
        priority=body.priority,
        status=LetterStatus.DRAFT,
        sender_id=me.id,
        recipient_name=body.recipient_name,
        recipient_organization=body.recipient_organization,
        recipient_department=body.recipient_department,
        recipient_user_id=PydanticObjectId(body.recipient_user_id) if body.recipient_user_id else None,
        cc_user_ids=[PydanticObjectId(x) for x in body.cc_user_ids],
        reply_to_id=PydanticObjectId(body.reply_to_id) if body.reply_to_id else None,
        letter_date=body.letter_date or datetime.now(timezone.utc),
        jalali_date=body.jalali_date,
        letter_number=body.letter_number or "",
        requester_id=PydanticObjectId(body.requester_id) if body.requester_id else None,
        actor_id=PydanticObjectId(body.actor_id) if body.actor_id else None,
        dispatcher_id=PydanticObjectId(body.dispatcher_id) if body.dispatcher_id else None,
        organization_id=PydanticObjectId(body.organization_id) if body.organization_id else None,
        additional_signer_ids=[PydanticObjectId(x) for x in body.additional_signer_ids],
    )
    await letter.insert()
    await log_activity("letter_create", resource_type="letter", resource_id=str(letter.id),
                       resource_title=letter.subject,
                       details={"type": letter.letter_type, "recipient": letter.recipient_name},
                       user=me)
    return _letter_to_dict(letter)


@router.get("")
async def list_letters(
    letter_type: Optional[LetterType] = None,
    status: Optional[LetterStatus] = None,
    skip: int = 0,
    limit: int = 20,
    me: User = Depends(get_current_user)
):
    conditions = []
    if letter_type:
        conditions.append({"letter_type": letter_type})
    if status:
        conditions.append({"status": status})

    if me.role not in (UserRole.SUPER_ADMIN, UserRole.MANAGER):
        conditions.append({"$or": [
            {"sender_id": me.id},
            {"recipient_user_id": me.id},
            {"cc_user_ids": me.id},
        ]})

    query = {"$and": conditions} if conditions else {}
    all_letters = await OfficialLetter.find(query).sort(-OfficialLetter.created_at).skip(skip).limit(limit).to_list()
    return [_letter_to_dict(l) for l in all_letters]


@router.get("/inbox")
async def get_inbox(skip: int = 0, limit: int = 20, me: User = Depends(get_current_user)):
    """کارتابل ورودی"""
    received = await OfficialLetter.find({
        "$or": [
            {"recipient_user_id": me.id},
            {"cc_user_ids": me.id},
        ],
        "status": {"$nin": [LetterStatus.DRAFT]}
    }).sort(-OfficialLetter.created_at).to_list()

    referrals = await LetterReferral.find(
        LetterReferral.to_user_id == me.id
    ).sort(-LetterReferral.created_at).to_list()

    referral_letter_ids = [r.letter_id for r in referrals]
    referred_letters = []
    if referral_letter_ids:
        referred_letters = await OfficialLetter.find(
            {"_id": {"$in": referral_letter_ids}}
        ).to_list()

    all_ids = {str(l.id) for l in received}
    result = [_letter_to_dict(l) for l in received]
    for l in referred_letters:
        if str(l.id) not in all_ids:
            d = _letter_to_dict(l)
            d["is_referred"] = True
            result.append(d)

    return sorted(result, key=lambda x: x.get("created_at", ""), reverse=True)


@router.get("/outbox")
async def get_outbox(skip: int = 0, limit: int = 20, me: User = Depends(get_current_user)):
    """کارتابل خروجی"""
    letters = await OfficialLetter.find({
        "sender_id": me.id,
        "status": {"$in": [LetterStatus.SENT, LetterStatus.APPROVED, LetterStatus.ARCHIVED]}
    }).sort(-OfficialLetter.created_at).to_list()
    return [_letter_to_dict(l) for l in letters]


@router.get("/drafts")
async def get_drafts(me: User = Depends(get_current_user)):
    """پیش‌نویس‌های من"""
    letters = await OfficialLetter.find({
        "sender_id": me.id,
        "status": LetterStatus.DRAFT
    }).sort(-OfficialLetter.created_at).to_list()
    return [_letter_to_dict(l) for l in letters]


@router.get("/pending-approval")
async def get_pending_approval(me: User = Depends(get_current_user)):
    """نامه‌های در انتظار تأیید (فقط مدیر)"""
    if me.role not in (UserRole.SUPER_ADMIN, UserRole.MANAGER):
        raise HTTPException(403, "دسترسی ندارید")
    letters = await OfficialLetter.find(
        OfficialLetter.status == LetterStatus.PENDING_APPROVAL
    ).sort(-OfficialLetter.created_at).to_list()
    return [_letter_to_dict(l) for l in letters]


@router.get("/{letter_id}")
async def get_letter(letter_id: str, me: User = Depends(get_current_user)):
    letter = await OfficialLetter.get(letter_id)
    if not letter:
        raise HTTPException(404, "نامه یافت نشد")
    d = _letter_to_dict(letter)
    sender = await User.get(letter.sender_id) if letter.sender_id else None
    signer = await User.get(letter.signer_id) if letter.signer_id else None
    approved_by = await User.get(letter.approved_by) if letter.approved_by else None
    requester = await User.get(letter.requester_id) if letter.requester_id else None
    actor = await User.get(letter.actor_id) if letter.actor_id else None
    dispatcher = await User.get(letter.dispatcher_id) if letter.dispatcher_id else None
    d["sender_name"] = sender.full_name if sender else ""
    d["sender_position"] = sender.position if sender else ""
    d["signer_name"] = signer.full_name if signer else ""
    d["signer_position"] = signer.position if signer else ""
    d["approved_by_name"] = approved_by.full_name if approved_by else ""
    d["approved_by_position"] = approved_by.position if approved_by else ""
    d["requester_name"] = requester.full_name if requester else ""
    d["actor_name"] = actor.full_name if actor else ""
    d["dispatcher_name"] = dispatcher.full_name if dispatcher else ""
    return d


@router.put("/{letter_id}")
async def update_letter(letter_id: str, body: LetterUpdate, me: User = Depends(get_current_user)):
    letter = await OfficialLetter.get(letter_id)
    if not letter:
        raise HTTPException(404, "نامه یافت نشد")
    if str(letter.sender_id) != str(me.id):
        raise HTTPException(403, "فقط نویسنده نامه می‌تواند ویرایش کند")
    if letter.status not in (LetterStatus.DRAFT, LetterStatus.REJECTED):
        raise HTTPException(400, "نامه‌های تأیید شده یا ارسال شده قابل ویرایش نیستند")

    update_data = body.model_dump(exclude_none=True)
    if "recipient_user_id" in update_data and update_data["recipient_user_id"]:
        update_data["recipient_user_id"] = PydanticObjectId(update_data["recipient_user_id"])

    for k, v in update_data.items():
        setattr(letter, k, v)
    letter.updated_at = datetime.now(timezone.utc)
    await letter.save()
    return _letter_to_dict(letter)


@router.delete("/{letter_id}")
async def delete_letter(letter_id: str, me: User = Depends(get_current_user)):
    letter = await OfficialLetter.get(letter_id)
    if not letter:
        raise HTTPException(404, "نامه یافت نشد")
    if str(letter.sender_id) != str(me.id) and me.role != UserRole.SUPER_ADMIN:
        raise HTTPException(403, "دسترسی ندارید")
    if letter.status not in (LetterStatus.DRAFT, LetterStatus.REJECTED):
        raise HTTPException(400, "فقط پیش‌نویس یا نامه‌های رد شده قابل حذف هستند")
    await letter.delete()
    return {"ok": True}


# ─── Workflow ─────────────────────────────────────────────────────────────────

@router.post("/{letter_id}/submit")
async def submit_for_approval(letter_id: str, me: User = Depends(get_current_user)):
    """ارسال برای تأیید"""
    letter = await OfficialLetter.get(letter_id)
    if not letter:
        raise HTTPException(404, "نامه یافت نشد")
    if str(letter.sender_id) != str(me.id):
        raise HTTPException(403, "دسترسی ندارید")
    if letter.status != LetterStatus.DRAFT:
        raise HTTPException(400, "فقط پیش‌نویس قابل ارسال برای تأیید است")

    letter.status = LetterStatus.PENDING_APPROVAL
    letter.updated_at = datetime.now(timezone.utc)
    await letter.save()
    await log_activity("letter_submit_approval", resource_type="letter", resource_id=str(letter.id),
                       resource_title=letter.subject, user=me)
    return _letter_to_dict(letter)


@router.post("/{letter_id}/approve")
async def approve_letter(letter_id: str, me: User = Depends(get_current_user)):
    """تأیید نامه"""
    if me.role not in (UserRole.SUPER_ADMIN, UserRole.MANAGER):
        raise HTTPException(403, "دسترسی ندارید")
    letter = await OfficialLetter.get(letter_id)
    if not letter:
        raise HTTPException(404, "نامه یافت نشد")
    if letter.status != LetterStatus.PENDING_APPROVAL:
        raise HTTPException(400, "این نامه در انتظار تأیید نیست")

    if letter.letter_number:
        # شماره دستی — بررسی تکراری نبودن
        existing = await OfficialLetter.find_one({
            "letter_number": letter.letter_number,
            "_id": {"$ne": letter.id}
        })
        if existing:
            raise HTTPException(400, f"شماره نامه '{letter.letter_number}' قبلاً استفاده شده است")
    else:
        letter.letter_number = await _get_letter_number(letter.letter_type)

    letter.status = LetterStatus.APPROVED
    letter.approved_by = me.id
    letter.approved_at = datetime.now(timezone.utc)
    letter.signer_id = me.id
    letter.signed_at = datetime.now(timezone.utc)
    letter.updated_at = datetime.now(timezone.utc)
    await letter.save()
    await log_activity("letter_approve", resource_type="letter", resource_id=str(letter.id),
                       resource_title=letter.subject,
                       details={"number": letter.letter_number}, user=me)
    return _letter_to_dict(letter)


@router.post("/{letter_id}/reject")
async def reject_letter(letter_id: str, body: ApproveRejectBody, me: User = Depends(get_current_user)):
    """رد نامه"""
    if me.role not in (UserRole.SUPER_ADMIN, UserRole.MANAGER):
        raise HTTPException(403, "دسترسی ندارید")
    letter = await OfficialLetter.get(letter_id)
    if not letter:
        raise HTTPException(404, "نامه یافت نشد")
    if letter.status != LetterStatus.PENDING_APPROVAL:
        raise HTTPException(400, "این نامه در انتظار تأیید نیست")

    letter.status = LetterStatus.REJECTED
    letter.rejection_reason = body.reason
    letter.updated_at = datetime.now(timezone.utc)
    await letter.save()
    await log_activity("letter_reject", resource_type="letter", resource_id=str(letter.id),
                       resource_title=letter.subject,
                       details={"reason": body.reason}, user=me)
    return _letter_to_dict(letter)


@router.post("/{letter_id}/send")
async def send_letter(letter_id: str, me: User = Depends(get_current_user)):
    """ارسال نهایی نامه"""
    letter = await OfficialLetter.get(letter_id)
    if not letter:
        raise HTTPException(404, "نامه یافت نشد")
    if str(letter.sender_id) != str(me.id) and me.role not in (UserRole.SUPER_ADMIN, UserRole.MANAGER):
        raise HTTPException(403, "دسترسی ندارید")
    if letter.status != LetterStatus.APPROVED:
        raise HTTPException(400, "فقط نامه‌های تأیید شده قابل ارسال هستند")

    letter.status = LetterStatus.SENT
    letter.updated_at = datetime.now(timezone.utc)
    await letter.save()
    await log_activity("letter_send", resource_type="letter", resource_id=str(letter.id),
                       resource_title=letter.subject, user=me)
    return _letter_to_dict(letter)


@router.post("/{letter_id}/archive")
async def archive_letter(letter_id: str, me: User = Depends(get_current_user)):
    """بایگانی نامه"""
    letter = await OfficialLetter.get(letter_id)
    if not letter:
        raise HTTPException(404, "نامه یافت نشد")
    if letter.status not in (LetterStatus.SENT, LetterStatus.APPROVED):
        raise HTTPException(400, "فقط نامه‌های ارسال/تأیید شده قابل بایگانی هستند")

    letter.status = LetterStatus.ARCHIVED
    letter.updated_at = datetime.now(timezone.utc)
    await letter.save()
    return _letter_to_dict(letter)


# ─── Referral ─────────────────────────────────────────────────────────────────

@router.post("/{letter_id}/refer")
async def refer_letter(letter_id: str, body: ReferralCreate, me: User = Depends(get_current_user)):
    """ارجاع نامه"""
    letter = await OfficialLetter.get(letter_id)
    if not letter:
        raise HTTPException(404, "نامه یافت نشد")

    to_user = await User.get(body.to_user_id)
    if not to_user:
        raise HTTPException(404, "کاربر مقصد یافت نشد")

    referral = LetterReferral(
        letter_id=letter.id,
        from_user_id=me.id,
        to_user_id=PydanticObjectId(body.to_user_id),
        action=body.action,
        note=body.note,
        deadline=body.deadline,
    )
    await referral.insert()

    letter.referral_ids.append(referral.id)
    letter.updated_at = datetime.now(timezone.utc)
    await letter.save()

    await log_activity("letter_refer", resource_type="letter", resource_id=str(letter.id),
                       resource_title=letter.subject,
                       details={"to_user": to_user.full_name, "action": body.action}, user=me)
    return {"ok": True, "referral_id": str(referral.id)}


@router.get("/{letter_id}/referrals")
async def get_referrals(letter_id: str, me: User = Depends(get_current_user)):
    """زنجیره ارجاعات نامه"""
    referrals = await LetterReferral.find(
        LetterReferral.letter_id == PydanticObjectId(letter_id)
    ).sort(LetterReferral.created_at).to_list()

    result = []
    for r in referrals:
        d = r.model_dump()
        d["id"] = str(r.id)
        d["letter_id"] = str(r.letter_id)
        d["from_user_id"] = str(r.from_user_id)
        d["to_user_id"] = str(r.to_user_id)
        from_user = await User.get(r.from_user_id)
        to_user = await User.get(r.to_user_id)
        d["from_user_name"] = from_user.full_name if from_user else ""
        d["to_user_name"] = to_user.full_name if to_user else ""
        result.append(d)
    return result


@router.post("/{letter_id}/referrals/{referral_id}/read")
async def mark_referral_read(letter_id: str, referral_id: str, me: User = Depends(get_current_user)):
    referral = await LetterReferral.get(referral_id)
    if not referral:
        raise HTTPException(404, "ارجاع یافت نشد")
    if str(referral.to_user_id) != str(me.id):
        raise HTTPException(403, "دسترسی ندارید")
    referral.is_read = True
    referral.read_at = datetime.now(timezone.utc)
    await referral.save()
    return {"ok": True}


# ─── Comments ─────────────────────────────────────────────────────────────────

@router.get("/{letter_id}/comments")
async def get_comments(letter_id: str, me: User = Depends(get_current_user)):
    comments = await LetterComment.find(
        LetterComment.letter_id == PydanticObjectId(letter_id)
    ).sort(LetterComment.created_at).to_list()

    result = []
    for c in comments:
        if c.is_private and str(c.author_id) != str(me.id):
            continue
        d = c.model_dump()
        d["id"] = str(c.id)
        d["letter_id"] = str(c.letter_id)
        d["author_id"] = str(c.author_id)
        author = await User.get(c.author_id)
        d["author_name"] = author.full_name if author else ""
        result.append(d)
    return result


@router.post("/{letter_id}/comments")
async def add_comment(letter_id: str, body: CommentCreate, me: User = Depends(get_current_user)):
    letter = await OfficialLetter.get(letter_id)
    if not letter:
        raise HTTPException(404, "نامه یافت نشد")

    comment = LetterComment(
        letter_id=letter.id,
        author_id=me.id,
        content=body.content,
        is_private=body.is_private,
    )
    await comment.insert()
    return {"ok": True, "id": str(comment.id)}


# ─── Reply ────────────────────────────────────────────────────────────────────

@router.post("/{letter_id}/stamp")
async def stamp_letter(letter_id: str, me: User = Depends(get_current_user)):
    """مهر زدن نامه توسط مدیر کل یا مدیر"""
    if me.role not in (UserRole.SUPER_ADMIN, UserRole.MANAGER):
        raise HTTPException(403, "فقط مدیران مجاز به مهر زدن هستند")
    letter = await OfficialLetter.get(letter_id)
    if not letter:
        raise HTTPException(404, "نامه یافت نشد")
    if letter.status not in (LetterStatus.APPROVED, LetterStatus.SENT):
        raise HTTPException(400, "فقط نامه‌های تأیید یا ارسال شده قابل مهر هستند")

    letter.is_stamped = True
    letter.stamped_by = me.id
    letter.stamped_at = datetime.now(timezone.utc)
    letter.updated_at = datetime.now(timezone.utc)
    await letter.save()
    return _letter_to_dict(letter)


@router.post("/{letter_id}/sign-and-stamp")
async def sign_and_stamp_letter(letter_id: str, me: User = Depends(get_current_user)):
    """مهر و امضا همزمان توسط مدیر کل یا مدیر"""
    if me.role not in (UserRole.SUPER_ADMIN, UserRole.MANAGER):
        raise HTTPException(403, "فقط مدیران مجاز هستند")
    letter = await OfficialLetter.get(letter_id)
    if not letter:
        raise HTTPException(404, "نامه یافت نشد")
    if letter.status not in (LetterStatus.APPROVED, LetterStatus.SENT):
        raise HTTPException(400, "فقط نامه‌های تأیید یا ارسال شده قابل مهر و امضا هستند")

    letter.is_stamped = True
    letter.stamped_by = me.id
    letter.stamped_at = datetime.now(timezone.utc)
    letter.signature_applied = True
    letter.signature_applied_by = me.id
    letter.signature_applied_at = datetime.now(timezone.utc)
    letter.updated_at = datetime.now(timezone.utc)
    await letter.save()
    return _letter_to_dict(letter)


@router.delete("/{letter_id}/stamp")
async def remove_stamp(letter_id: str, me: User = Depends(get_current_user)):
    """برداشتن مهر"""
    if me.role not in (UserRole.SUPER_ADMIN, UserRole.MANAGER):
        raise HTTPException(403, "فقط مدیران مجاز هستند")
    letter = await OfficialLetter.get(letter_id)
    if not letter:
        raise HTTPException(404, "نامه یافت نشد")
    letter.is_stamped = False
    letter.stamped_by = None
    letter.stamped_at = None
    letter.updated_at = datetime.now(timezone.utc)
    await letter.save()
    return _letter_to_dict(letter)


@router.get("/{letter_id}/print-data")
async def get_letter_print_data(letter_id: str, me: User = Depends(get_current_user)):
    """داده‌های کامل نامه + سربرگ برای پرینت"""
    letter = await OfficialLetter.get(letter_id)
    if not letter:
        raise HTTPException(404, "نامه یافت نشد")

    from app.models.system import SystemSettings
    settings = await SystemSettings.find_one()

    sender = await User.get(letter.sender_id)
    signer = await User.get(letter.signer_id) if letter.signer_id else None

    stamped_by_user = None
    if letter.stamped_by:
        stamped_by_user = await User.get(letter.stamped_by)

    letter_dict = _letter_to_dict(letter)
    letter_dict["sender_name"] = sender.full_name if sender else ""
    letter_dict["sender_position"] = sender.position if sender else ""
    letter_dict["sender_signature"] = sender.signature_data if sender else None
    letter_dict["signer_name"] = signer.full_name if signer else ""
    letter_dict["signer_position"] = signer.position if signer else ""
    letter_dict["signer_signature"] = signer.signature_data if signer else None
    letter_dict["signer_stamp"] = signer.stamp_data if signer else None
    letter_dict["stamped_by_name"] = stamped_by_user.full_name if stamped_by_user else ""

    # Enrich additional signers
    additional_signers = []
    for sid in letter.additional_signer_ids:
        u = await User.get(sid)
        if u:
            additional_signers.append({
                "id": str(u.id),
                "full_name": u.full_name,
                "position": u.position or "",
                "signature": u.signature_data,
                "stamp": u.stamp_data if hasattr(u, "stamp_data") else None,
            })
    letter_dict["additional_signers"] = additional_signers

    letterhead = {}
    if settings:
        letterhead = {
            "org_name": settings.letterhead_org_name or settings.org_name,
            "org_name_en": settings.letterhead_org_name_en,
            "address": settings.letterhead_address or settings.org_address or "",
            "phone": settings.letterhead_phone or settings.org_phone or "",
            "fax": settings.letterhead_fax,
            "postal_code": settings.letterhead_postal_code,
            "website": settings.letterhead_website or settings.org_website or "",
            "email": settings.letterhead_email,
            "reg_number": settings.letterhead_reg_number,
            "logo_data": settings.letterhead_logo_data,
            "stamp_data": settings.letterhead_stamp_data,
            "footer_text": settings.letterhead_footer_text,
            "color": settings.letterhead_color,
            "secondary_color": settings.letterhead_secondary_color,
            # System-level image letterhead (fallback)
            "letterhead_header_data": getattr(settings, "letterhead_header_data", None),
            "letterhead_footer_data": getattr(settings, "letterhead_footer_data", None),
        }

    # Company-specific letterhead: use letter.organization_id, then sender's first org
    from app.models.user import Organization
    org_id = letter.organization_id or (sender.organization_ids[0] if sender and sender.organization_ids else None)
    if org_id:
        org = await Organization.get(org_id)
        if org:
            if org.letterhead_header_data:
                letterhead["letterhead_header_data"] = org.letterhead_header_data
            if org.letterhead_footer_data:
                letterhead["letterhead_footer_data"] = org.letterhead_footer_data
            if org.name:
                letterhead["org_name"] = letterhead.get("org_name") or org.official_name or org.name

    return {"letter": letter_dict, "letterhead": letterhead}


@router.post("/{letter_id}/reply")
async def reply_to_letter(letter_id: str, body: LetterCreate, me: User = Depends(get_current_user)):
    """پاسخ به نامه"""
    original = await OfficialLetter.get(letter_id)
    if not original:
        raise HTTPException(404, "نامه اصلی یافت نشد")

    subject = body.subject or f"پاسخ: {original.subject}"
    reply = OfficialLetter(
        letter_type=body.letter_type,
        subject=subject,
        body=body.body,
        priority=body.priority,
        status=LetterStatus.DRAFT,
        sender_id=me.id,
        recipient_user_id=original.sender_id,
        recipient_name="",
        reply_to_id=original.id,
        jalali_date=body.jalali_date,
        letter_date=datetime.now(timezone.utc),
    )
    await reply.insert()
    return _letter_to_dict(reply)
