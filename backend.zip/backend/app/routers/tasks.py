from fastapi import APIRouter, Depends, Query, UploadFile, File
from typing import Optional, List
from datetime import datetime, timezone
from beanie import PydanticObjectId
from app.schemas.task import (
    TaskCreate, TaskUpdate, TaskResponse, SubTaskCreate, SubTaskUpdate,
    CommentCreate, CommentResponse, AuditLogResponse, TaskFilterParams,
)
from app.models.task import Task, TaskStatus, TaskPriority, SubTask, TaskComment, TaskAuditLog, TaskReferral, TaskAssignmentType
from app.models.user import User
from app.models.notification import Notification, NotificationType, NotificationPriority
from app.core.permissions import require_member, require_team_lead
from app.core.exceptions import NotFoundError, AuthorizationError
from app.deps import get_current_user
from app.services.file_service import upload_file
from app.websocket.manager import manager
from app.core.activity import log_activity
import structlog

logger = structlog.get_logger()
router = APIRouter(prefix="/tasks", tags=["tasks"])


async def _log_audit(task_id, user_id, action: str, field=None, old_val=None, new_val=None, desc=None):
    log = TaskAuditLog(
        task_id=task_id, user_id=user_id, action=action,
        field=field, old_value=str(old_val) if old_val else None,
        new_value=str(new_val) if new_val else None, description=desc,
    )
    await log.insert()


async def _notify_user(recipient_id, notif_type, title, body, link=None, meta=None):
    notif = Notification(
        recipient_id=recipient_id, type=notif_type,
        title=title, body=body, link=link or "", metadata=meta or {},
    )
    await notif.insert()
    await manager.send_to_user(str(recipient_id), {
        "type": "notification", "data": {
            "id": str(notif.id), "title": title, "body": body,
            "notification_type": notif_type, "link": link,
        }
    })


def _task_dict(task: Task) -> dict:
    return {
        "id": str(task.id),
        "title": task.title,
        "description": task.description,
        "team_id": str(task.team_id) if task.team_id else None,
        "assignment_type": task.assignment_type if hasattr(task, "assignment_type") else "individual",
        "assignee_id": str(task.assignee_id) if task.assignee_id else None,
        "assignee_ids": [str(x) for x in (task.assignee_ids if hasattr(task, "assignee_ids") else [])],
        "created_by": str(task.created_by),
        "priority": task.priority,
        "status": task.status,
        "tags": task.tags,
        "start_date": task.start_date,
        "due_date": task.due_date,
        "completed_at": task.completed_at,
        "delay_hours": task.delay_hours,
        "is_overdue": task.is_overdue if hasattr(task, "is_overdue") else False,
        "referral_chain": task.referral_chain if hasattr(task, "referral_chain") else [],
        "checklist": task.checklist,
        "file_ids": [str(f) for f in task.file_ids],
        "watcher_ids": [str(w) for w in task.watcher_ids],
        "last_activity_at": task.last_activity_at,
        "created_at": task.created_at,
        "updated_at": task.updated_at,
    }


@router.get("", dependencies=[Depends(require_member)])
async def list_tasks(
    team_id: Optional[str] = Query(None),
    assignee_id: Optional[str] = Query(None),
    status: Optional[TaskStatus] = Query(None),
    priority: Optional[TaskPriority] = Query(None),
    search: Optional[str] = Query(None),
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    current_user: User = Depends(get_current_user),
):
    filters = []
    if team_id:
        filters.append(Task.team_id == PydanticObjectId(team_id))
    if assignee_id:
        filters.append(Task.assignee_id == PydanticObjectId(assignee_id))
    if status:
        filters.append(Task.status == status)
    if priority:
        filters.append(Task.priority == priority)

    query = Task.find(*filters) if filters else Task.find()
    tasks = await query.sort("-created_at").skip((page - 1) * page_size).limit(page_size).to_list()

    if search:
        s = search.lower()
        tasks = [t for t in tasks if s in t.title.lower() or (t.description and s in t.description.lower())]

    return {"items": [_task_dict(t) for t in tasks], "page": page, "page_size": page_size}


@router.post("", dependencies=[Depends(require_member)])
async def create_task(data: TaskCreate, current_user: User = Depends(get_current_user)):
    task = Task(
        title=data.title,
        description=data.description,
        team_id=PydanticObjectId(data.team_id) if data.team_id else None,
        assignee_id=PydanticObjectId(data.assignee_id) if data.assignee_id else None,
        created_by=current_user.id,
        priority=data.priority,
        tags=data.tags,
        start_date=data.start_date,
        due_date=data.due_date,
        checklist=[c.model_dump() for c in data.checklist],
        watcher_ids=[PydanticObjectId(w) for w in data.watcher_ids],
    )
    await task.insert()
    await _log_audit(task.id, current_user.id, "created", desc=f"تسک '{task.title}' ایجاد شد")
    await log_activity("task_create", resource_type="task", resource_id=str(task.id),
                       resource_title=task.title,
                       details={"priority": task.priority, "assignee_id": str(task.assignee_id) if task.assignee_id else ""},
                       user=current_user)

    if task.assignee_id and task.assignee_id != current_user.id:
        await _notify_user(
            task.assignee_id, NotificationType.TASK_ASSIGNED,
            "تسک جدید به شما محول شد", task.title,
            link=f"/tasks/{task.id}",
            meta={"task_id": str(task.id)},
        )
    return _task_dict(task)


@router.get("/{task_id}", dependencies=[Depends(require_member)])
async def get_task(task_id: str):
    task = await Task.get(PydanticObjectId(task_id))
    if not task:
        raise NotFoundError("تسک یافت نشد")
    return _task_dict(task)


@router.put("/{task_id}", dependencies=[Depends(require_member)])
async def update_task(task_id: str, data: TaskUpdate, current_user: User = Depends(get_current_user)):
    task = await Task.get(PydanticObjectId(task_id))
    if not task:
        raise NotFoundError("تسک یافت نشد")

    update_data = data.model_dump(exclude_none=True)
    now = datetime.now(timezone.utc)

    for field, new_val in update_data.items():
        old_val = getattr(task, field, None)
        if old_val == new_val:
            continue

        if field == "status":
            if new_val == TaskStatus.DONE and task.due_date:
                task.completed_at = now
                due = task.due_date.replace(tzinfo=timezone.utc) if task.due_date.tzinfo is None else task.due_date
                delay = (now - due).total_seconds() / 3600
                task.delay_hours = round(delay, 2)
            elif new_val != TaskStatus.DONE:
                task.completed_at = None
                task.delay_hours = None

        if field == "assignee_id" and new_val:
            new_val = PydanticObjectId(new_val)
            if new_val != current_user.id:
                await _notify_user(
                    new_val, NotificationType.TASK_ASSIGNED,
                    "تسک به شما محول شد", task.title,
                    link=f"/tasks/{task.id}", meta={"task_id": str(task.id)},
                )

        if field == "team_id" and new_val:
            new_val = PydanticObjectId(new_val)

        if field == "watcher_ids" and new_val:
            new_val = [PydanticObjectId(w) for w in new_val]

        await _log_audit(task.id, current_user.id, "updated", field=field,
                         old_val=old_val, new_val=new_val)
        setattr(task, field, new_val)

    task.updated_at = now
    task.last_activity_at = now
    await task.save()
    await log_activity("task_update", resource_type="task", resource_id=str(task.id),
                       resource_title=task.title,
                       details={k: str(v) for k, v in update_data.items()},
                       user=current_user)
    return _task_dict(task)


@router.delete("/{task_id}", dependencies=[Depends(require_team_lead)])
async def delete_task(task_id: str, current_user: User = Depends(get_current_user)):
    task = await Task.get(PydanticObjectId(task_id))
    if not task:
        raise NotFoundError("تسک یافت نشد")
    await _log_audit(task.id, current_user.id, "deleted", desc=f"تسک '{task.title}' حذف شد")
    await log_activity("task_delete", resource_type="task", resource_id=str(task.id),
                       resource_title=task.title, user=current_user)
    await task.delete()
    return {"message": "تسک حذف شد"}


# ─── Subtasks ────────────────────────────────────────────────────────────────

@router.get("/{task_id}/subtasks", dependencies=[Depends(require_member)])
async def list_subtasks(task_id: str):
    subtasks = await SubTask.find(SubTask.parent_task_id == PydanticObjectId(task_id)).to_list()
    return [{
        "id": str(s.id), "title": s.title, "description": s.description,
        "assignee_id": str(s.assignee_id) if s.assignee_id else None,
        "status": s.status, "due_date": s.due_date, "is_done": s.is_done,
    } for s in subtasks]


@router.post("/{task_id}/subtasks", dependencies=[Depends(require_member)])
async def create_subtask(task_id: str, data: SubTaskCreate, current_user: User = Depends(get_current_user)):
    task = await Task.get(PydanticObjectId(task_id))
    if not task:
        raise NotFoundError("تسک یافت نشد")
    sub = SubTask(
        parent_task_id=task.id,
        title=data.title,
        description=data.description,
        assignee_id=PydanticObjectId(data.assignee_id) if data.assignee_id else None,
        due_date=data.due_date,
        created_by=current_user.id,
    )
    await sub.insert()
    task.last_activity_at = datetime.now(timezone.utc)
    await task.save()
    return {"id": str(sub.id), "title": sub.title, "status": sub.status}


@router.put("/{task_id}/subtasks/{sub_id}", dependencies=[Depends(require_member)])
async def update_subtask(task_id: str, sub_id: str, data: SubTaskUpdate, current_user: User = Depends(get_current_user)):
    sub = await SubTask.get(PydanticObjectId(sub_id))
    if not sub:
        raise NotFoundError("زیرتسک یافت نشد")
    for k, v in data.model_dump(exclude_none=True).items():
        setattr(sub, k, v)
    await sub.save()
    task = await Task.get(PydanticObjectId(task_id))
    if task:
        task.last_activity_at = datetime.now(timezone.utc)
        await task.save()
    return {"id": str(sub.id), "title": sub.title, "status": sub.status, "is_done": sub.is_done}


# ─── Comments ────────────────────────────────────────────────────────────────

@router.get("/{task_id}/comments", dependencies=[Depends(require_member)])
async def list_comments(task_id: str):
    comments = await TaskComment.find(
        TaskComment.task_id == PydanticObjectId(task_id),
        TaskComment.is_deleted == False,
    ).sort("created_at").to_list()
    return [{
        "id": str(c.id), "task_id": str(c.task_id), "author_id": str(c.author_id),
        "content": c.content, "mentioned_user_ids": [str(m) for m in c.mentioned_user_ids],
        "file_ids": [str(f) for f in c.file_ids],
        "created_at": c.created_at, "updated_at": c.updated_at,
    } for c in comments]


@router.post("/{task_id}/comments", dependencies=[Depends(require_member)])
async def add_comment(task_id: str, data: CommentCreate, current_user: User = Depends(get_current_user)):
    task = await Task.get(PydanticObjectId(task_id))
    if not task:
        raise NotFoundError("تسک یافت نشد")

    mentioned_ids = [PydanticObjectId(u) for u in data.mentioned_user_ids]
    comment = TaskComment(
        task_id=task.id,
        author_id=current_user.id,
        content=data.content,
        mentioned_user_ids=mentioned_ids,
    )
    await comment.insert()

    task.last_activity_at = datetime.now(timezone.utc)
    await task.save()

    # ارسال نوتیفیکیشن به منشن‌شده‌ها
    for uid in mentioned_ids:
        if uid != current_user.id:
            await _notify_user(
                uid, NotificationType.MENTION,
                f"شما در تسک '{task.title}' منشن شدید",
                data.content[:100],
                link=f"/tasks/{task.id}",
                meta={"task_id": str(task.id), "comment_id": str(comment.id)},
            )
            # ارسال ایمیل async
            mentioned_user = await User.get(uid)
            if mentioned_user and mentioned_user.email_notifications_enabled:
                if mentioned_user.notification_preferences.get("mention_alert", True):
                    target_email = mentioned_user.notification_email or mentioned_user.email
                    from app.workers.email_tasks import send_mention_email
                    send_mention_email.delay(
                        user_email=target_email,
                        user_name=mentioned_user.full_name,
                        mentioned_by=current_user.full_name,
                        task_title=task.title,
                        comment_content=data.content,
                        task_id=str(task.id),
                    )

    return {
        "id": str(comment.id), "content": comment.content,
        "author_id": str(comment.author_id), "created_at": comment.created_at,
    }


# ─── File Attachments ─────────────────────────────────────────────────────────

@router.post("/{task_id}/files", dependencies=[Depends(require_member)])
async def attach_file_to_task(
    task_id: str,
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user),
):
    task = await Task.get(PydanticObjectId(task_id))
    if not task:
        raise NotFoundError("تسک یافت نشد")
    meta = await upload_file(file, current_user, folder=f"tasks/{task_id}")
    task.file_ids.append(meta.id)
    task.last_activity_at = datetime.now(timezone.utc)
    await task.save()
    return {"file_id": str(meta.id), "name": meta.original_name, "size": meta.size_bytes}


# ─── Audit Log ────────────────────────────────────────────────────────────────

@router.get("/{task_id}/audit-log", dependencies=[Depends(require_member)])
async def get_audit_log(task_id: str):
    logs = await TaskAuditLog.find(
        TaskAuditLog.task_id == PydanticObjectId(task_id)
    ).sort("created_at").to_list()
    return [{
        "id": str(l.id), "user_id": str(l.user_id), "action": l.action,
        "field": l.field, "old_value": l.old_value, "new_value": l.new_value,
        "description": l.description, "created_at": l.created_at,
    } for l in logs]


# ─── Checklist Update ─────────────────────────────────────────────────────────

@router.patch("/{task_id}/checklist", dependencies=[Depends(require_member)])
async def update_checklist(task_id: str, checklist: list, current_user: User = Depends(get_current_user)):
    task = await Task.get(PydanticObjectId(task_id))
    if not task:
        raise NotFoundError("تسک یافت نشد")
    task.checklist = checklist
    task.last_activity_at = datetime.now(timezone.utc)
    await task.save()
    return {"checklist": task.checklist}


# ─── Task Referral ────────────────────────────────────────────────────────────

from pydantic import BaseModel as PydanticBaseModel


class TaskReferralCreate(PydanticBaseModel):
    to_user_id: Optional[str] = None
    to_team_id: Optional[str] = None
    to_manager: bool = False        # ارجاع به مدیر تیم جاری
    note: Optional[str] = None
    due_date: Optional[datetime] = None
    file_ids: List[str] = []        # فایل‌های پیوست


@router.post("/{task_id}/refer", dependencies=[Depends(require_member)])
async def refer_task(task_id: str, data: TaskReferralCreate, current_user: User = Depends(get_current_user)):
    """ارجاع تسک به کاربر / مدیر / تیم"""
    from app.models.user import Team
    task = await Task.get(PydanticObjectId(task_id))
    if not task:
        raise NotFoundError("تسک یافت نشد")

    to_user = None
    to_team = None
    target_name = ""

    if data.to_manager:
        # پیدا کردن مدیر تیم جاری کاربر
        if current_user.team_ids:
            team = await Team.get(current_user.team_ids[0])
            if team and team.manager_id:
                to_user = await User.get(team.manager_id)
        if not to_user:
            raise NotFoundError("مدیری برای تیم شما یافت نشد")
        target_name = to_user.full_name

    elif data.to_team_id:
        to_team = await Team.get(PydanticObjectId(data.to_team_id))
        if not to_team:
            raise NotFoundError("تیم یافت نشد")
        target_name = to_team.name

    elif data.to_user_id:
        to_user = await User.get(PydanticObjectId(data.to_user_id))
        if not to_user:
            raise NotFoundError("کاربر مقصد یافت نشد")
        target_name = to_user.full_name

    else:
        raise NotFoundError("مقصد ارجاع مشخص نشده")

    referral = TaskReferral(
        task_id=task.id,
        from_user_id=current_user.id,
        to_user_id=to_user.id if to_user else None,
        to_team_id=PydanticObjectId(data.to_team_id) if data.to_team_id else None,
        note=data.note,
        deadline=data.due_date,
        file_ids=data.file_ids,
    )
    await referral.insert()

    # ثبت در زنجیره ارجاع
    chain_entry = {
        "referral_id": str(referral.id),
        "from": str(current_user.id),
        "from_name": current_user.full_name,
        "to": str(to_user.id) if to_user else None,
        "to_name": to_user.full_name if to_user else None,
        "to_team": str(data.to_team_id) if data.to_team_id else None,
        "to_team_name": to_team.name if to_team else None,
        "note": data.note,
        "file_ids": data.file_ids,
        "at": datetime.now(timezone.utc).isoformat(),
    }
    task.referral_chain.append(chain_entry)

    # تغییر مسئول تسک
    if to_user:
        task.assignee_id = to_user.id
        task.team_id = None
    elif to_team:
        task.team_id = to_team.id
        task.assignee_id = None

    task.last_activity_at = datetime.now(timezone.utc)
    task.updated_at = datetime.now(timezone.utc)
    await task.save()

    await _log_audit(task.id, current_user.id, "referred",
                     desc=f"تسک به {target_name} ارجاع داده شد")

    if to_user:
        await _notify_user(
            to_user.id, NotificationType.TASK_ASSIGNED,
            "تسک به شما ارجاع داده شد",
            f"'{task.title}' از طرف {current_user.full_name}",
            link=f"/tasks/{task.id}",
            meta={"task_id": str(task.id)},
        )
    elif to_team and to_team.manager_id:
        await _notify_user(
            to_team.manager_id, NotificationType.TASK_ASSIGNED,
            "تسک به تیم شما ارجاع داده شد",
            f"'{task.title}' از طرف {current_user.full_name}",
            link=f"/tasks/{task.id}",
            meta={"task_id": str(task.id)},
        )

    return _task_dict(task)


@router.get("/{task_id}/referrals", dependencies=[Depends(require_member)])
async def get_task_referrals(task_id: str):
    """تاریخچه زنجیره ارجاعات تسک"""
    task = await Task.get(PydanticObjectId(task_id))
    if not task:
        raise NotFoundError("تسک یافت نشد")
    return task.referral_chain if hasattr(task, "referral_chain") else []


# ─── Overdue Tasks (for managers) ─────────────────────────────────────────────

@router.get("/overdue/summary", dependencies=[Depends(require_member)])
async def get_overdue_tasks(current_user: User = Depends(get_current_user)):
    """تسک‌های عقب‌افتاده برای مدیر"""
    from app.models.user import UserRole, Team
    now = datetime.now(timezone.utc)

    if current_user.role == UserRole.SUPER_ADMIN:
        overdue = await Task.find({
            "due_date": {"$lt": now},
            "status": {"$nin": [TaskStatus.DONE]},
        }).sort("-due_date").limit(50).to_list()
    elif current_user.role == UserRole.MANAGER:
        my_teams = await Team.find({"manager_id": current_user.id}).to_list()
        team_ids = [t.id for t in my_teams]
        overdue = await Task.find({
            "team_id": {"$in": team_ids},
            "due_date": {"$lt": now},
            "status": {"$nin": [TaskStatus.DONE]},
        }).sort("-due_date").limit(50).to_list()
    else:
        overdue = await Task.find({
            "assignee_id": current_user.id,
            "due_date": {"$lt": now},
            "status": {"$nin": [TaskStatus.DONE]},
        }).to_list()

    result = []
    for t in overdue:
        d = _task_dict(t)
        if t.due_date:
            d["overdue_hours"] = round((now - t.due_date.replace(tzinfo=timezone.utc) if t.due_date.tzinfo is None else now - t.due_date).total_seconds() / 3600, 1)
        result.append(d)
    return result
