from fastapi import APIRouter, Depends, UploadFile, File
from app.models.system import SystemSettings
from app.core.permissions import require_super_admin
from app.deps import get_current_user
from app.models.user import User
from datetime import datetime, timezone
from pydantic import BaseModel, EmailStr
from typing import Optional
import base64

router = APIRouter(prefix="/admin", tags=["admin"])


class SmtpSettingsUpdate(BaseModel):
    smtp_host: Optional[str] = None
    smtp_port: Optional[int] = None
    smtp_username: Optional[str] = None
    smtp_password: Optional[str] = None
    smtp_from_email: Optional[EmailStr] = None
    smtp_from_name: Optional[str] = None
    smtp_use_tls: Optional[bool] = None


class OrgSettingsUpdate(BaseModel):
    org_name: Optional[str] = None
    org_address: Optional[str] = None
    org_phone: Optional[str] = None
    org_website: Optional[str] = None
    stale_task_days: Optional[int] = None


class LetterheadSettingsUpdate(BaseModel):
    letterhead_org_name: Optional[str] = None
    letterhead_org_name_en: Optional[str] = None
    letterhead_address: Optional[str] = None
    letterhead_phone: Optional[str] = None
    letterhead_fax: Optional[str] = None
    letterhead_postal_code: Optional[str] = None
    letterhead_website: Optional[str] = None
    letterhead_email: Optional[str] = None
    letterhead_reg_number: Optional[str] = None
    letterhead_footer_text: Optional[str] = None
    letterhead_color: Optional[str] = None
    letterhead_secondary_color: Optional[str] = None


async def _get_or_create_settings() -> SystemSettings:
    settings_doc = await SystemSettings.find_one()
    if not settings_doc:
        settings_doc = SystemSettings()
        await settings_doc.insert()
    return settings_doc


@router.get("/settings", dependencies=[Depends(require_super_admin)])
async def get_settings():
    doc = await _get_or_create_settings()
    return {
        "smtp_host": doc.smtp_host,
        "smtp_port": doc.smtp_port,
        "smtp_username": doc.smtp_username,
        "smtp_from_email": doc.smtp_from_email,
        "smtp_from_name": doc.smtp_from_name,
        "smtp_use_tls": doc.smtp_use_tls,
        "org_name": doc.org_name,
        "org_address": doc.org_address,
        "org_phone": doc.org_phone,
        "org_website": doc.org_website,
        "stale_task_days": doc.stale_task_days,
    }


@router.put("/settings/smtp", dependencies=[Depends(require_super_admin)])
async def update_smtp(data: SmtpSettingsUpdate):
    doc = await _get_or_create_settings()
    for k, v in data.model_dump(exclude_none=True).items():
        setattr(doc, k, v)
    doc.updated_at = datetime.now(timezone.utc)
    await doc.save()

    # Reflect to runtime settings
    from app.config import settings as app_settings
    for k, v in data.model_dump(exclude_none=True).items():
        upper_k = k.upper()
        if hasattr(app_settings, upper_k):
            setattr(app_settings, upper_k, v)

    return {"message": "تنظیمات SMTP به‌روز شد"}


@router.put("/settings/org", dependencies=[Depends(require_super_admin)])
async def update_org(data: OrgSettingsUpdate):
    doc = await _get_or_create_settings()
    for k, v in data.model_dump(exclude_none=True).items():
        setattr(doc, k, v)
    doc.updated_at = datetime.now(timezone.utc)
    await doc.save()
    return {"message": "اطلاعات سازمان به‌روز شد"}


@router.get("/settings/letterhead", dependencies=[Depends(require_super_admin)])
async def get_letterhead_settings():
    doc = await _get_or_create_settings()
    return {
        "letterhead_org_name": doc.letterhead_org_name,
        "letterhead_org_name_en": doc.letterhead_org_name_en,
        "letterhead_address": doc.letterhead_address,
        "letterhead_phone": doc.letterhead_phone,
        "letterhead_fax": doc.letterhead_fax,
        "letterhead_postal_code": doc.letterhead_postal_code,
        "letterhead_website": doc.letterhead_website,
        "letterhead_email": doc.letterhead_email,
        "letterhead_reg_number": doc.letterhead_reg_number,
        "letterhead_footer_text": doc.letterhead_footer_text,
        "letterhead_color": doc.letterhead_color,
        "letterhead_secondary_color": doc.letterhead_secondary_color,
        "has_logo": bool(doc.letterhead_logo_data),
        "has_stamp": bool(doc.letterhead_stamp_data),
        "letterhead_logo_data": doc.letterhead_logo_data,
        "letterhead_stamp_data": doc.letterhead_stamp_data,
        "letterhead_header_data": doc.letterhead_header_data if hasattr(doc, "letterhead_header_data") else None,
        "letterhead_footer_data": doc.letterhead_footer_data if hasattr(doc, "letterhead_footer_data") else None,
    }


@router.put("/settings/letterhead", dependencies=[Depends(require_super_admin)])
async def update_letterhead_settings(data: LetterheadSettingsUpdate):
    doc = await _get_or_create_settings()
    for k, v in data.model_dump(exclude_none=True).items():
        setattr(doc, k, v)
    doc.updated_at = datetime.now(timezone.utc)
    await doc.save()
    return {"message": "تنظیمات سربرگ به‌روز شد"}


@router.post("/settings/letterhead/logo", dependencies=[Depends(require_super_admin)])
async def upload_letterhead_logo(file: UploadFile = File(...)):
    content = await file.read()
    if len(content) > 2 * 1024 * 1024:
        from fastapi import HTTPException
        raise HTTPException(400, "حجم فایل بیش از ۲ مگابایت است")
    mime = file.content_type or "image/png"
    b64 = base64.b64encode(content).decode()
    data_url = f"data:{mime};base64,{b64}"
    doc = await _get_or_create_settings()
    doc.letterhead_logo_data = data_url
    doc.updated_at = datetime.now(timezone.utc)
    await doc.save()
    return {"message": "لوگو آپلود شد", "logo_data": data_url}


@router.post("/settings/letterhead/stamp", dependencies=[Depends(require_super_admin)])
async def upload_letterhead_stamp(file: UploadFile = File(...)):
    content = await file.read()
    if len(content) > 2 * 1024 * 1024:
        from fastapi import HTTPException
        raise HTTPException(400, "حجم فایل بیش از ۲ مگابایت است")
    mime = file.content_type or "image/png"
    b64 = base64.b64encode(content).decode()
    data_url = f"data:{mime};base64,{b64}"
    doc = await _get_or_create_settings()
    doc.letterhead_stamp_data = data_url
    doc.updated_at = datetime.now(timezone.utc)
    await doc.save()
    return {"message": "مهر سازمانی آپلود شد", "stamp_data": data_url}


@router.post("/settings/letterhead/header", dependencies=[Depends(require_super_admin)])
async def upload_letterhead_header(file: UploadFile = File(...)):
    content = await file.read()
    mime = file.content_type or "image/jpeg"
    b64 = base64.b64encode(content).decode()
    data_url = f"data:{mime};base64,{b64}"
    doc = await _get_or_create_settings()
    doc.letterhead_header_data = data_url
    doc.updated_at = datetime.now(timezone.utc)
    await doc.save()
    return {"message": "تصویر هدر سربرگ آپلود شد", "header_data": data_url}


@router.post("/settings/letterhead/footer", dependencies=[Depends(require_super_admin)])
async def upload_letterhead_footer(file: UploadFile = File(...)):
    content = await file.read()
    mime = file.content_type or "image/jpeg"
    b64 = base64.b64encode(content).decode()
    data_url = f"data:{mime};base64,{b64}"
    doc = await _get_or_create_settings()
    doc.letterhead_footer_data = data_url
    doc.updated_at = datetime.now(timezone.utc)
    await doc.save()
    return {"message": "تصویر فوتر سربرگ آپلود شد", "footer_data": data_url}


@router.delete("/settings/letterhead/header", dependencies=[Depends(require_super_admin)])
async def delete_letterhead_header():
    doc = await _get_or_create_settings()
    doc.letterhead_header_data = None
    doc.updated_at = datetime.now(timezone.utc)
    await doc.save()
    return {"message": "هدر سربرگ حذف شد"}


@router.delete("/settings/letterhead/footer", dependencies=[Depends(require_super_admin)])
async def delete_letterhead_footer():
    doc = await _get_or_create_settings()
    doc.letterhead_footer_data = None
    doc.updated_at = datetime.now(timezone.utc)
    await doc.save()
    return {"message": "فوتر سربرگ حذف شد"}


@router.post("/settings/smtp/test", dependencies=[Depends(require_super_admin)])
async def test_smtp(current_user: User = Depends(get_current_user)):
    doc = await _get_or_create_settings()
    from app.email.smtp_provider import SmtpEmailProvider
    provider = SmtpEmailProvider(
        host=doc.smtp_host, port=doc.smtp_port,
        username=doc.smtp_username, password=doc.smtp_password,
        from_email=doc.smtp_from_email or doc.smtp_username,
        from_name=doc.smtp_from_name, use_tls=doc.smtp_use_tls,
    )
    target_email = current_user.notification_email or current_user.email
    ok = await provider.send(
        to=[target_email],
        subject="تست ایمیل — Zlata Management",
        html_body="<p>اتصال SMTP با موفقیت برقرار شد.</p>",
    )
    return {"success": ok, "sent_to": target_email}
