from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
from datetime import datetime, timezone
from beanie import PydanticObjectId

from app.models.meeting import Meeting, MeetingMinutes, MeetingStatus, MeetingType, AttendeeStatus
from app.models.user import User, UserRole
from app.core.deps import get_current_user

router = APIRouter(prefix="/api/meetings", tags=["meetings"])


class MeetingCreate(BaseModel):
    title: str
    description: Optional[str] = None
    meeting_type: MeetingType = MeetingType.IN_PERSON
    team_id: Optional[str] = None
    is_all_org: bool = False
    attendee_ids: List[str] = []
    start_time: datetime
    end_time: datetime
    location: Optional[str] = None
    online_link: Optional[str] = None
    agenda: Optional[str] = None


class MeetingUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None
    location: Optional[str] = None
    online_link: Optional[str] = None
    agenda: Optional[str] = None
    status: Optional[MeetingStatus] = None


class MinutesCreate(BaseModel):
    content: str
    action_items: List[Dict[str, Any]] = []


def _meeting_to_dict(m: Meeting) -> dict:
    d = m.model_dump()
    d["id"] = str(m.id)
    d["organizer_id"] = str(m.organizer_id)
    if m.team_id:
        d["team_id"] = str(m.team_id)
    if m.minutes_id:
        d["minutes_id"] = str(m.minutes_id)
    d["file_ids"] = [str(x) for x in m.file_ids]
    for a in d.get("attendees", []):
        if "user_id" in a and a["user_id"]:
            a["user_id"] = str(a["user_id"])
    return d


@router.post("")
async def create_meeting(body: MeetingCreate, me: User = Depends(get_current_user)):
    if body.end_time <= body.start_time:
        raise HTTPException(400, "زمان پایان باید بعد از زمان شروع باشد")

    attendees = [{"user_id": str(me.id), "status": AttendeeStatus.ACCEPTED}]
    for uid in body.attendee_ids:
        if uid != str(me.id):
            attendees.append({"user_id": uid, "status": AttendeeStatus.PENDING})

    meeting = Meeting(
        title=body.title,
        description=body.description,
        meeting_type=body.meeting_type,
        team_id=PydanticObjectId(body.team_id) if body.team_id else None,
        is_all_org=body.is_all_org,
        organizer_id=me.id,
        attendees=attendees,
        start_time=body.start_time,
        end_time=body.end_time,
        location=body.location,
        online_link=body.online_link,
        agenda=body.agenda,
    )
    await meeting.insert()
    return _meeting_to_dict(meeting)


@router.get("")
async def list_meetings(
    upcoming: bool = False,
    team_id: Optional[str] = None,
    me: User = Depends(get_current_user)
):
    conditions = []
    now = datetime.now(timezone.utc)

    if upcoming:
        conditions.append({"start_time": {"$gte": now}})

    if team_id:
        conditions.append({"team_id": PydanticObjectId(team_id)})
    elif me.role not in (UserRole.SUPER_ADMIN, UserRole.MANAGER):
        # کاربر معمولی فقط جلساتی که در آن حضور دارد
        conditions.append({"$or": [
            {"organizer_id": me.id},
            {"attendees.user_id": str(me.id)},
            {"is_all_org": True},
        ]})

    query = {"$and": conditions} if conditions else {}
    meetings = await Meeting.find(query).sort(Meeting.start_time).to_list()
    return [_meeting_to_dict(m) for m in meetings]


@router.get("/{meeting_id}")
async def get_meeting(meeting_id: str, me: User = Depends(get_current_user)):
    meeting = await Meeting.get(meeting_id)
    if not meeting:
        raise HTTPException(404, "جلسه یافت نشد")
    d = _meeting_to_dict(meeting)
    # اضافه کردن اطلاعات شرکت‌کنندگان
    enriched = []
    for a in d.get("attendees", []):
        try:
            user = await User.get(a["user_id"])
            if user:
                a["full_name"] = user.full_name
                a["position"] = user.position
        except Exception:
            pass
        enriched.append(a)
    d["attendees"] = enriched
    return d


@router.put("/{meeting_id}")
async def update_meeting(meeting_id: str, body: MeetingUpdate, me: User = Depends(get_current_user)):
    meeting = await Meeting.get(meeting_id)
    if not meeting:
        raise HTTPException(404, "جلسه یافت نشد")
    if str(meeting.organizer_id) != str(me.id) and me.role != UserRole.SUPER_ADMIN:
        raise HTTPException(403, "دسترسی ندارید")

    update_data = body.model_dump(exclude_none=True)
    for k, v in update_data.items():
        setattr(meeting, k, v)
    meeting.updated_at = datetime.now(timezone.utc)
    await meeting.save()
    return _meeting_to_dict(meeting)


@router.delete("/{meeting_id}")
async def delete_meeting(meeting_id: str, me: User = Depends(get_current_user)):
    meeting = await Meeting.get(meeting_id)
    if not meeting:
        raise HTTPException(404, "جلسه یافت نشد")
    if str(meeting.organizer_id) != str(me.id) and me.role != UserRole.SUPER_ADMIN:
        raise HTTPException(403, "دسترسی ندارید")
    meeting.status = MeetingStatus.CANCELLED
    meeting.updated_at = datetime.now(timezone.utc)
    await meeting.save()
    return {"ok": True}


@router.post("/{meeting_id}/respond")
async def respond_to_meeting(
    meeting_id: str,
    status: AttendeeStatus,
    me: User = Depends(get_current_user)
):
    """پاسخ به دعوت جلسه"""
    meeting = await Meeting.get(meeting_id)
    if not meeting:
        raise HTTPException(404, "جلسه یافت نشد")

    updated = False
    for a in meeting.attendees:
        if a.get("user_id") == str(me.id):
            a["status"] = status
            updated = True
            break

    if not updated:
        meeting.attendees.append({"user_id": str(me.id), "status": status})

    meeting.updated_at = datetime.now(timezone.utc)
    await meeting.save()
    return {"ok": True}


class ProposeTimeBody(BaseModel):
    start_time: datetime
    end_time: datetime
    note: Optional[str] = None


class AcceptProposedTimeBody(BaseModel):
    user_id: str


@router.post("/{meeting_id}/propose-time")
async def propose_new_time(
    meeting_id: str,
    body: ProposeTimeBody,
    me: User = Depends(get_current_user)
):
    """پیشنهاد زمان جدید برای جلسه توسط شرکت‌کننده"""
    meeting = await Meeting.get(meeting_id)
    if not meeting:
        raise HTTPException(404, "جلسه یافت نشد")
    if body.end_time <= body.start_time:
        raise HTTPException(400, "زمان پایان باید بعد از زمان شروع باشد")

    # وضعیت شرکت‌کننده را tentative می‌کند
    for a in meeting.attendees:
        if a.get("user_id") == str(me.id):
            a["status"] = AttendeeStatus.TENTATIVE
            break

    # پیشنهاد را ذخیره می‌کند
    meeting.proposed_times = [p for p in meeting.proposed_times if p.get("user_id") != str(me.id)]
    meeting.proposed_times.append({
        "user_id": str(me.id),
        "start_time": body.start_time.isoformat(),
        "end_time": body.end_time.isoformat(),
        "note": body.note or "",
        "proposed_at": datetime.now(timezone.utc).isoformat(),
    })
    meeting.updated_at = datetime.now(timezone.utc)
    await meeting.save()
    return {"ok": True}


@router.post("/{meeting_id}/accept-proposed-time")
async def accept_proposed_time(
    meeting_id: str,
    body: AcceptProposedTimeBody,
    me: User = Depends(get_current_user)
):
    """برگزارکننده یک پیشنهاد زمان را قبول می‌کند"""
    meeting = await Meeting.get(meeting_id)
    if not meeting:
        raise HTTPException(404, "جلسه یافت نشد")
    if str(meeting.organizer_id) != str(me.id) and me.role not in (UserRole.SUPER_ADMIN, UserRole.MANAGER):
        raise HTTPException(403, "دسترسی ندارید")

    proposal = next((p for p in meeting.proposed_times if p.get("user_id") == body.user_id), None)
    if not proposal:
        raise HTTPException(404, "پیشنهاد یافت نشد")

    meeting.start_time = datetime.fromisoformat(proposal["start_time"])
    meeting.end_time = datetime.fromisoformat(proposal["end_time"])
    meeting.proposed_times = []
    # همه شرکت‌کنندگان دوباره pending می‌شوند
    for a in meeting.attendees:
        if a.get("user_id") != str(me.id):
            a["status"] = AttendeeStatus.PENDING
    meeting.updated_at = datetime.now(timezone.utc)
    await meeting.save()
    return {"ok": True}


@router.post("/{meeting_id}/minutes")
async def create_minutes(meeting_id: str, body: MinutesCreate, me: User = Depends(get_current_user)):
    """ثبت صورت‌جلسه"""
    meeting = await Meeting.get(meeting_id)
    if not meeting:
        raise HTTPException(404, "جلسه یافت نشد")

    minutes = MeetingMinutes(
        meeting_id=meeting.id,
        content=body.content,
        written_by=me.id,
        action_items=body.action_items,
    )
    await minutes.insert()
    meeting.minutes_id = minutes.id
    meeting.status = MeetingStatus.COMPLETED
    meeting.updated_at = datetime.now(timezone.utc)
    await meeting.save()
    return {"ok": True, "minutes_id": str(minutes.id)}


@router.get("/{meeting_id}/minutes")
async def get_minutes(meeting_id: str, me: User = Depends(get_current_user)):
    meeting = await Meeting.get(meeting_id)
    if not meeting or not meeting.minutes_id:
        raise HTTPException(404, "صورت‌جلسه یافت نشد")
    minutes = await MeetingMinutes.get(meeting.minutes_id)
    if not minutes:
        raise HTTPException(404, "صورت‌جلسه یافت نشد")
    d = minutes.model_dump()
    d["id"] = str(minutes.id)
    d["meeting_id"] = str(minutes.meeting_id)
    d["written_by"] = str(minutes.written_by)
    return d
