import base64
from fastapi import APIRouter, HTTPException, Depends, UploadFile, File
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime, timezone
from beanie import PydanticObjectId

from app.models.user import User, Organization
from app.core.permissions import require_member, require_manager, require_super_admin

router = APIRouter(prefix="/api/companies", tags=["companies"])


class CompanyCreate(BaseModel):
    name: str
    official_name: Optional[str] = None
    address: Optional[str] = None
    phone: Optional[str] = None
    website: Optional[str] = None


class CompanyUpdate(BaseModel):
    name: Optional[str] = None
    official_name: Optional[str] = None
    address: Optional[str] = None
    phone: Optional[str] = None
    website: Optional[str] = None


def org_to_dict(org: Organization) -> dict:
    return {
        "id": str(org.id),
        "name": org.name,
        "official_name": org.official_name,
        "address": org.address,
        "phone": org.phone,
        "website": org.website,
        "letterhead_header_data": org.letterhead_header_data,
        "letterhead_footer_data": org.letterhead_footer_data,
        "created_at": org.created_at.isoformat(),
    }


@router.get("")
async def list_companies(current_user: User = Depends(require_member)):
    orgs = await Organization.find_all().to_list()
    return [org_to_dict(o) for o in orgs]


@router.get("/{org_id}")
async def get_company(org_id: str, current_user: User = Depends(require_member)):
    try:
        org = await Organization.get(PydanticObjectId(org_id))
    except Exception:
        raise HTTPException(status_code=404, detail="شرکت یافت نشد")
    if not org:
        raise HTTPException(status_code=404, detail="شرکت یافت نشد")
    return org_to_dict(org)


@router.post("")
async def create_company(body: CompanyCreate, current_user: User = Depends(require_super_admin)):
    org = Organization(
        name=body.name,
        official_name=body.official_name,
        address=body.address,
        phone=body.phone,
        website=body.website,
    )
    await org.insert()
    return org_to_dict(org)


@router.put("/{org_id}")
async def update_company(org_id: str, body: CompanyUpdate, current_user: User = Depends(require_super_admin)):
    try:
        org = await Organization.get(PydanticObjectId(org_id))
    except Exception:
        raise HTTPException(status_code=404, detail="شرکت یافت نشد")
    if not org:
        raise HTTPException(status_code=404, detail="شرکت یافت نشد")
    if body.name is not None:
        org.name = body.name
    if body.official_name is not None:
        org.official_name = body.official_name
    if body.address is not None:
        org.address = body.address
    if body.phone is not None:
        org.phone = body.phone
    if body.website is not None:
        org.website = body.website
    await org.save()
    return org_to_dict(org)


@router.get("/{org_id}/users")
async def get_company_users(org_id: str, current_user: User = Depends(require_manager)):
    try:
        oid = PydanticObjectId(org_id)
    except Exception:
        raise HTTPException(status_code=404, detail="شرکت یافت نشد")
    org = await Organization.get(oid)
    if not org:
        raise HTTPException(status_code=404, detail="شرکت یافت نشد")
    users = await User.find(User.organization_ids == oid).to_list()
    return [
        {
            "id": str(u.id),
            "full_name": u.full_name,
            "email": u.email,
            "role": u.role,
            "position": u.position,
            "is_active": u.is_active,
        }
        for u in users
    ]


@router.post("/{org_id}/users/{user_id}")
async def add_user_to_company(org_id: str, user_id: str, current_user: User = Depends(require_super_admin)):
    try:
        oid = PydanticObjectId(org_id)
        uid = PydanticObjectId(user_id)
    except Exception:
        raise HTTPException(status_code=400, detail="شناسه نامعتبر")
    org = await Organization.get(oid)
    if not org:
        raise HTTPException(status_code=404, detail="شرکت یافت نشد")
    user = await User.get(uid)
    if not user:
        raise HTTPException(status_code=404, detail="کاربر یافت نشد")
    if oid not in user.organization_ids:
        user.organization_ids.append(oid)
        await user.save()
    return {"message": "کاربر به شرکت اضافه شد"}


@router.post("/{org_id}/letterhead/header")
async def upload_letterhead_header(
    org_id: str,
    file: UploadFile = File(...),
    current_user: User = Depends(require_manager)
):
    """آپلود تصویر هدر سربرگ"""
    try:
        oid = PydanticObjectId(org_id)
    except Exception:
        raise HTTPException(status_code=400, detail="شناسه نامعتبر")
    org = await Organization.get(oid)
    if not org:
        raise HTTPException(status_code=404, detail="شرکت یافت نشد")
    content = await file.read()
    mime = file.content_type or "image/png"
    b64 = base64.b64encode(content).decode()
    org.letterhead_header_data = f"data:{mime};base64,{b64}"
    await org.save()
    return {"ok": True}


@router.post("/{org_id}/letterhead/footer")
async def upload_letterhead_footer(
    org_id: str,
    file: UploadFile = File(...),
    current_user: User = Depends(require_manager)
):
    """آپلود تصویر فوتر سربرگ"""
    try:
        oid = PydanticObjectId(org_id)
    except Exception:
        raise HTTPException(status_code=400, detail="شناسه نامعتبر")
    org = await Organization.get(oid)
    if not org:
        raise HTTPException(status_code=404, detail="شرکت یافت نشد")
    content = await file.read()
    mime = file.content_type or "image/png"
    b64 = base64.b64encode(content).decode()
    org.letterhead_footer_data = f"data:{mime};base64,{b64}"
    await org.save()
    return {"ok": True}


@router.delete("/{org_id}/letterhead/header")
async def delete_letterhead_header(org_id: str, current_user: User = Depends(require_manager)):
    try:
        oid = PydanticObjectId(org_id)
    except Exception:
        raise HTTPException(status_code=400, detail="شناسه نامعتبر")
    org = await Organization.get(oid)
    if not org:
        raise HTTPException(status_code=404, detail="شرکت یافت نشد")
    org.letterhead_header_data = None
    await org.save()
    return {"ok": True}


@router.delete("/{org_id}/letterhead/footer")
async def delete_letterhead_footer(org_id: str, current_user: User = Depends(require_manager)):
    try:
        oid = PydanticObjectId(org_id)
    except Exception:
        raise HTTPException(status_code=400, detail="شناسه نامعتبر")
    org = await Organization.get(oid)
    if not org:
        raise HTTPException(status_code=404, detail="شرکت یافت نشد")
    org.letterhead_footer_data = None
    await org.save()
    return {"ok": True}


@router.delete("/{org_id}/users/{user_id}")
async def remove_user_from_company(org_id: str, user_id: str, current_user: User = Depends(require_super_admin)):
    try:
        oid = PydanticObjectId(org_id)
        uid = PydanticObjectId(user_id)
    except Exception:
        raise HTTPException(status_code=400, detail="شناسه نامعتبر")
    org = await Organization.get(oid)
    if not org:
        raise HTTPException(status_code=404, detail="شرکت یافت نشد")
    user = await User.get(uid)
    if not user:
        raise HTTPException(status_code=404, detail="کاربر یافت نشد")
    if oid in user.organization_ids:
        user.organization_ids = [x for x in user.organization_ids if x != oid]
        await user.save()
    return {"message": "کاربر از شرکت حذف شد"}
