from fastapi import APIRouter, Depends, Query
from typing import Optional
from app.models.user import User, Team
from app.core.permissions import require_member

router = APIRouter(prefix="/phonebook", tags=["phonebook"])


@router.get("", dependencies=[Depends(require_member)])
async def phonebook(
    team_id: Optional[str] = Query(None),
    search: Optional[str] = Query(None),
):
    users = await User.find(User.is_active == True).to_list()

    if team_id:
        from beanie import PydanticObjectId
        tid = PydanticObjectId(team_id)
        users = [u for u in users if tid in u.team_ids]

    if search:
        s = search.lower()
        users = [u for u in users if
                 s in u.full_name.lower() or
                 (u.position and s in u.position.lower()) or
                 (u.mobile and s in u.mobile) or
                 (u.extension_number and s in u.extension_number)]

    teams = {str(t.id): t.name for t in await Team.find().to_list()}

    result = []
    for u in users:
        user_teams = [{"id": str(tid), "name": teams.get(str(tid), "")} for tid in u.team_ids]
        result.append({
            "id": str(u.id),
            "full_name": u.full_name,
            "email": u.email,
            "position": u.position,
            "teams": user_teams,
            "extension_number": u.extension_number,
            "mobile": u.mobile,
            "role": u.role,
        })

    return sorted(result, key=lambda x: x["full_name"])
