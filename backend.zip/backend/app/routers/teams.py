from fastapi import APIRouter, Depends, Query
from typing import Optional, List
from beanie import PydanticObjectId
from app.schemas.user import TeamCreate, TeamUpdate, TeamResponse
from app.models.user import Team, User
from app.core.permissions import require_super_admin, require_manager, require_member
from app.core.exceptions import NotFoundError, ConflictError
from app.deps import get_current_user

router = APIRouter(prefix="/teams", tags=["teams"])


def _team_response(team: Team) -> dict:
    return {
        "id": str(team.id),
        "name": team.name,
        "description": team.description,
        "manager_id": str(team.manager_id) if team.manager_id else None,
        "lead_id": str(team.lead_id) if team.lead_id else None,
        "member_ids": [str(m) for m in team.member_ids],
        "is_active": team.is_active,
        "created_at": team.created_at,
    }


@router.get("", dependencies=[Depends(require_member)])
async def list_teams(is_active: Optional[bool] = Query(True)):
    teams = await Team.find(Team.is_active == (is_active if is_active is not None else True)).to_list()
    return [_team_response(t) for t in teams]


@router.post("", dependencies=[Depends(require_super_admin)])
async def create_team(data: TeamCreate):
    team = Team(
        name=data.name,
        description=data.description,
        manager_id=PydanticObjectId(data.manager_id) if data.manager_id else None,
        lead_id=PydanticObjectId(data.lead_id) if data.lead_id else None,
        member_ids=[PydanticObjectId(m) for m in data.member_ids],
    )
    await team.insert()

    # Sync team_ids on users
    for uid in data.member_ids:
        user = await User.get(PydanticObjectId(uid))
        if user and team.id not in user.team_ids:
            user.team_ids.append(team.id)
            await user.save()

    return _team_response(team)


@router.get("/{team_id}", dependencies=[Depends(require_member)])
async def get_team(team_id: str):
    team = await Team.get(PydanticObjectId(team_id))
    if not team:
        raise NotFoundError("تیم یافت نشد")
    return _team_response(team)


@router.put("/{team_id}", dependencies=[Depends(require_manager)])
async def update_team(team_id: str, data: TeamUpdate):
    team = await Team.get(PydanticObjectId(team_id))
    if not team:
        raise NotFoundError("تیم یافت نشد")

    update_data = data.model_dump(exclude_none=True)
    if "member_ids" in update_data:
        update_data["member_ids"] = [PydanticObjectId(m) for m in update_data["member_ids"]]
    if "manager_id" in update_data and update_data["manager_id"]:
        update_data["manager_id"] = PydanticObjectId(update_data["manager_id"])
    if "lead_id" in update_data and update_data["lead_id"]:
        update_data["lead_id"] = PydanticObjectId(update_data["lead_id"])

    for k, v in update_data.items():
        setattr(team, k, v)
    await team.save()
    return _team_response(team)


@router.get("/{team_id}/members", dependencies=[Depends(require_member)])
async def get_team_members(team_id: str):
    team = await Team.get(PydanticObjectId(team_id))
    if not team:
        raise NotFoundError("تیم یافت نشد")
    members = []
    for uid in team.member_ids:
        user = await User.get(uid)
        if user:
            members.append({
                "id": str(user.id),
                "full_name": user.full_name,
                "email": user.email,
                "position": user.position,
                "role": user.role,
                "mobile": user.mobile,
                "extension_number": user.extension_number,
            })
    return members
