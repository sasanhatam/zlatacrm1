from fastapi import APIRouter, Depends, Query, HTTPException
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime, timezone
from beanie import PydanticObjectId

from app.models.attendance import AttendanceRecord
from app.models.user import User
from app.core.permissions import require_member, require_manager
from app.deps import get_current_user
from app.core.activity import log_activity

router = APIRouter(prefix="/attendance", tags=["attendance"])


def _tehran_now():
    from zoneinfo import ZoneInfo
    return datetime.now(ZoneInfo("Asia/Tehran"))


def _tehran_today() -> str:
    return _tehran_now().strftime("%Y-%m-%d")


def _jalali_date_str(dt: datetime) -> str:
    try:
        import jdatetime
        jdt = jdatetime.datetime.fromgregorian(datetime=dt)
        return jdt.strftime("%Y/%m/%d")
    except Exception:
        return dt.strftime("%Y/%m/%d")


def _record_dict(rec: AttendanceRecord, user_name: str = "") -> dict:
    duration = rec.duration_minutes
    if duration is None and rec.clock_out is None and rec.clock_in:
        # live duration
        now_utc = datetime.now(timezone.utc)
        ci = rec.clock_in if rec.clock_in.tzinfo else rec.clock_in.replace(tzinfo=timezone.utc)
        duration = int((now_utc - ci).total_seconds() / 60)

    return {
        "id": str(rec.id),
        "user_id": str(rec.user_id),
        "user_name": user_name,
        "work_date": rec.work_date,
        "jalali_date": rec.jalali_date,
        "clock_in": rec.clock_in.isoformat() if rec.clock_in else None,
        "clock_out": rec.clock_out.isoformat() if rec.clock_out else None,
        "duration_minutes": duration,
        "note": rec.note,
        "is_active": rec.clock_out is None,
    }


class ClockInBody(BaseModel):
    note: Optional[str] = None


class ClockOutBody(BaseModel):
    note: Optional[str] = None


@router.post("/clock-in")
async def clock_in(body: ClockInBody = ClockInBody(), current_user: User = Depends(require_member)):
    today = _tehran_today()
    existing = await AttendanceRecord.find_one(
        AttendanceRecord.user_id == current_user.id,
        AttendanceRecord.work_date == today,
    )
    if existing:
        if existing.clock_out is None:
            raise HTTPException(400, "شما قبلاً شروع به کار کرده‌اید و هنوز خروج نزده‌اید")
        # allow re-clock-in after clock-out (e.g. second shift — create new record)

    now_utc = datetime.now(timezone.utc)
    tehran_now = _tehran_now()
    rec = AttendanceRecord(
        user_id=current_user.id,
        work_date=today,
        jalali_date=_jalali_date_str(tehran_now),
        clock_in=now_utc,
        note=body.note,
    )
    await rec.insert()
    await log_activity("attendance_clock_in", resource_type="attendance", resource_id=str(rec.id),
                       resource_title=current_user.full_name,
                       details={"date": today}, user=current_user)
    return _record_dict(rec, current_user.full_name)


@router.post("/clock-out")
async def clock_out(body: ClockOutBody = ClockOutBody(), current_user: User = Depends(require_member)):
    today = _tehran_today()
    rec = await AttendanceRecord.find_one(
        AttendanceRecord.user_id == current_user.id,
        AttendanceRecord.work_date == today,
        AttendanceRecord.clock_out == None,
    )
    if not rec:
        raise HTTPException(400, "هیچ ورود فعالی برای امروز یافت نشد")

    now_utc = datetime.now(timezone.utc)
    ci = rec.clock_in if rec.clock_in.tzinfo else rec.clock_in.replace(tzinfo=timezone.utc)
    duration = int((now_utc - ci).total_seconds() / 60)

    rec.clock_out = now_utc
    rec.duration_minutes = duration
    if body.note:
        rec.note = body.note
    await rec.save()

    await log_activity("attendance_clock_out", resource_type="attendance", resource_id=str(rec.id),
                       resource_title=current_user.full_name,
                       details={"date": today, "duration_minutes": duration}, user=current_user)
    return _record_dict(rec, current_user.full_name)


@router.get("/today")
async def get_today(current_user: User = Depends(require_member)):
    today = _tehran_today()
    recs = await AttendanceRecord.find(
        AttendanceRecord.user_id == current_user.id,
        AttendanceRecord.work_date == today,
    ).sort(AttendanceRecord.clock_in).to_list()

    active = next((r for r in recs if r.clock_out is None), None)
    return {
        "today": today,
        "records": [_record_dict(r, current_user.full_name) for r in recs],
        "is_clocked_in": active is not None,
        "active_record": _record_dict(active, current_user.full_name) if active else None,
        "total_minutes_today": sum(
            (r.duration_minutes or 0) for r in recs if r.clock_out is not None
        ),
    }


@router.get("/my")
async def get_my_records(
    from_date: Optional[str] = Query(None),
    to_date: Optional[str] = Query(None),
    page: int = Query(1, ge=1),
    limit: int = Query(30, ge=1, le=100),
    current_user: User = Depends(require_member),
):
    filters = [AttendanceRecord.user_id == current_user.id]
    if from_date:
        filters.append(AttendanceRecord.work_date >= from_date)
    if to_date:
        filters.append(AttendanceRecord.work_date <= to_date)

    total = await AttendanceRecord.find(*filters).count()
    recs = await AttendanceRecord.find(*filters).sort(-AttendanceRecord.clock_in) \
        .skip((page - 1) * limit).limit(limit).to_list()

    return {
        "total": total,
        "page": page,
        "items": [_record_dict(r, current_user.full_name) for r in recs],
    }


@router.get("/report")
async def get_report(
    from_date: Optional[str] = Query(None),
    to_date: Optional[str] = Query(None),
    user_id: Optional[str] = Query(None),
    current_user: User = Depends(require_manager),
):
    """گزارش حضور و غیاب برای مدیران"""
    filters = []
    if from_date:
        filters.append(AttendanceRecord.work_date >= from_date)
    if to_date:
        filters.append(AttendanceRecord.work_date <= to_date)
    if user_id:
        filters.append(AttendanceRecord.user_id == PydanticObjectId(user_id))

    recs = await AttendanceRecord.find(*filters).sort(
        [("work_date", -1), ("clock_in", 1)]
    ).to_list()

    # resolve user names
    user_ids = list({r.user_id for r in recs})
    users_map: dict = {}
    for uid in user_ids:
        u = await User.get(uid)
        if u:
            users_map[str(uid)] = {"name": u.full_name, "mobile": u.mobile}

    items = []
    for r in recs:
        u_info = users_map.get(str(r.user_id), {"name": "", "mobile": ""})
        d = _record_dict(r, u_info["name"])
        d["user_mobile"] = u_info["mobile"]
        items.append(d)

    # summary per user
    summary: dict = {}
    for r in recs:
        uid = str(r.user_id)
        if uid not in summary:
            u_info = users_map.get(uid, {"name": "", "mobile": ""})
            summary[uid] = {
                "user_id": uid,
                "user_name": u_info["name"],
                "user_mobile": u_info["mobile"],
                "days_present": 0,
                "total_minutes": 0,
            }
        summary[uid]["days_present"] += 1
        summary[uid]["total_minutes"] += r.duration_minutes or 0

    return {
        "items": items,
        "summary": list(summary.values()),
    }


@router.get("/users-list")
async def list_users_for_attendance(current_user: User = Depends(require_manager)):
    users = await User.find(User.is_active == True).sort(User.full_name).to_list()
    return [{"id": str(u.id), "full_name": u.full_name, "mobile": u.mobile} for u in users]
