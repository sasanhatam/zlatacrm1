from fastapi import APIRouter, Depends, UploadFile, File, Query, HTTPException
from typing import List, Optional
from beanie import PydanticObjectId
from app.schemas.user import UserCreate, UserUpdate, UserResponse, UserProfileUpdate
from app.models.user import User
from app.core.permissions import require_super_admin, require_manager, require_member
from app.core.security import hash_password
from app.core.exceptions import NotFoundError, ConflictError
from app.deps import get_current_user
from app.services.file_service import upload_file
from app.storage import storage
from app.core.activity import log_activity
import base64

router = APIRouter(prefix="/users", tags=["users"])


def _user_response(user: User) -> dict:
    return {
        "id": str(user.id),
        "email": user.email,
        "full_name": user.full_name,
        "role": user.role,
        "position": user.position,
        "team_ids": [str(t) for t in user.team_ids],
        "organization_ids": [str(o) for o in user.organization_ids],
        "extension_number": user.extension_number,
        "mobile": user.mobile,
        "notification_email": user.notification_email,
        "email_notifications_enabled": user.email_notifications_enabled,
        "notification_preferences": user.notification_preferences,
        "is_active": user.is_active,
        "last_login": user.last_login,
        "created_at": user.created_at,
    }


@router.get("", dependencies=[Depends(require_manager)])
async def list_users(
    team_id: Optional[str] = Query(None),
    is_active: Optional[bool] = Query(None),
    search: Optional[str] = Query(None),
):
    query = {}
    if is_active is not None:
        query["is_active"] = is_active

    users = await User.find(User.is_active == (is_active if is_active is not None else True)).to_list()

    if team_id:
        tid = PydanticObjectId(team_id)
        users = [u for u in users if tid in u.team_ids]
    if search:
        s = search.lower()
        users = [u for u in users if s in u.full_name.lower() or s in u.email.lower()]

    return [_user_response(u) for u in users]


@router.post("", dependencies=[Depends(require_manager)])
async def create_user(data: UserCreate, current_user: User = Depends(get_current_user)):
    existing = await User.find_one(User.email == data.email.lower())
    if existing:
        raise ConflictError("این ایمیل قبلاً ثبت شده است")

    team_ids = [PydanticObjectId(t) for t in data.team_ids]
    user = User(
        email=data.email.lower(),
        hashed_password=hash_password(data.password),
        full_name=data.full_name,
        role=data.role,
        position=data.position,
        team_ids=team_ids,
        extension_number=data.extension_number,
        mobile=data.mobile,
        notification_email=data.notification_email,
    )
    await user.insert()
    await log_activity("user_create", resource_type="user", resource_id=str(user.id),
                       resource_title=user.full_name,
                       details={"mobile": user.mobile, "role": user.role},
                       user=current_user)
    return _user_response(user)


@router.get("/{user_id}", dependencies=[Depends(require_member)])
async def get_user(user_id: str):
    user = await User.get(PydanticObjectId(user_id))
    if not user:
        raise NotFoundError("کاربر یافت نشد")
    return _user_response(user)


@router.put("/{user_id}", dependencies=[Depends(require_manager)])
async def update_user(user_id: str, data: UserUpdate, current_user: User = Depends(get_current_user)):
    user = await User.get(PydanticObjectId(user_id))
    if not user:
        raise NotFoundError("کاربر یافت نشد")

    update_data = data.model_dump(exclude_none=True)
    if "team_ids" in update_data:
        update_data["team_ids"] = [PydanticObjectId(t) for t in update_data["team_ids"]]
    if "organization_ids" in update_data:
        update_data["organization_ids"] = [PydanticObjectId(o) for o in update_data["organization_ids"]]

    for k, v in update_data.items():
        setattr(user, k, v)
    await user.save()
    await log_activity("user_update", resource_type="user", resource_id=str(user.id),
                       resource_title=user.full_name,
                       details={k: str(v) for k, v in update_data.items() if k not in ("hashed_password",)},
                       user=current_user)
    return _user_response(user)


@router.delete("/{user_id}/permanent", dependencies=[Depends(require_super_admin)])
async def delete_user_permanent(user_id: str, current_user: User = Depends(get_current_user)):
    user = await User.get(PydanticObjectId(user_id))
    if not user:
        raise NotFoundError("کاربر یافت نشد")
    name = user.full_name
    mobile = user.mobile
    await user.delete()
    await log_activity("user_delete_permanent", resource_type="user", resource_id=user_id,
                       resource_title=name, details={"mobile": mobile}, user=current_user)
    return {"message": "کاربر حذف شد"}


@router.delete("/{user_id}", dependencies=[Depends(require_manager)])
async def deactivate_user(user_id: str, current_user: User = Depends(get_current_user)):
    user = await User.get(PydanticObjectId(user_id))
    if not user:
        raise NotFoundError("کاربر یافت نشد")
    user.is_active = False
    await user.save()
    await log_activity("user_deactivate", resource_type="user", resource_id=str(user.id),
                       resource_title=user.full_name, details={"mobile": user.mobile}, user=current_user)
    return {"message": "کاربر غیرفعال شد"}


@router.put("/me/profile")
async def update_my_profile(
    data: UserProfileUpdate,
    current_user: User = Depends(get_current_user),
):
    update_data = data.model_dump(exclude_none=True)
    for k, v in update_data.items():
        setattr(current_user, k, v)
    await current_user.save()
    return _user_response(current_user)


@router.post("/me/avatar")
async def upload_avatar(
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user),
):
    meta = await upload_file(file, current_user, folder="avatars")
    if current_user.avatar_key:
        try:
            await storage.delete(current_user.avatar_key)
        except Exception:
            pass
    current_user.avatar_key = meta.storage_key
    await current_user.save()
    url = await storage.download_url(meta.storage_key)
    return {"avatar_url": url}


@router.post("/me/signature")
async def upload_signature(
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user),
):
    content = await file.read()
    if len(content) > 1 * 1024 * 1024:
        raise HTTPException(400, "حجم امضا بیش از ۱ مگابایت است")
    mime = file.content_type or "image/png"
    b64 = base64.b64encode(content).decode()
    data_url = f"data:{mime};base64,{b64}"
    current_user.signature_data = data_url
    await current_user.save()
    return {"message": "امضا آپلود شد", "signature_data": data_url}


@router.post("/me/signature/draw")
async def save_drawn_signature(
    data: dict,
    current_user: User = Depends(get_current_user),
):
    """ذخیره امضای کشیده‌شده (canvas → base64)"""
    signature_data = data.get("signature_data", "")
    if not signature_data.startswith("data:image/"):
        raise HTTPException(400, "داده امضا نامعتبر است")
    current_user.signature_data = signature_data
    await current_user.save()
    return {"message": "امضا ذخیره شد", "signature_data": signature_data}


@router.delete("/me/signature")
async def delete_signature(current_user: User = Depends(get_current_user)):
    current_user.signature_data = None
    current_user.signature_key = None
    await current_user.save()
    return {"message": "امضا حذف شد"}


@router.get("/me/signature")
async def get_my_signature(current_user: User = Depends(get_current_user)):
    return {
        "has_signature": bool(current_user.signature_data),
        "signature_data": current_user.signature_data,
    }


@router.post("/me/stamp")
async def upload_stamp(
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user),
):
    """آپلود مهر شخصی (فقط مدیران)"""
    from app.models.user import UserRole
    if current_user.role not in (UserRole.SUPER_ADMIN, UserRole.MANAGER):
        raise HTTPException(403, "فقط مدیران می‌توانند مهر شخصی داشته باشند")
    content = await file.read()
    if len(content) > 2 * 1024 * 1024:
        raise HTTPException(400, "حجم مهر بیش از ۲ مگابایت است")
    mime = file.content_type or "image/png"
    b64 = base64.b64encode(content).decode()
    data_url = f"data:{mime};base64,{b64}"
    current_user.stamp_data = data_url
    await current_user.save()
    return {"message": "مهر آپلود شد", "stamp_data": data_url}


@router.get("/me/stamp")
async def get_my_stamp(current_user: User = Depends(get_current_user)):
    return {
        "has_stamp": bool(current_user.stamp_data),
        "stamp_data": current_user.stamp_data,
    }


@router.delete("/me/stamp")
async def delete_stamp(current_user: User = Depends(get_current_user)):
    from app.models.user import UserRole
    if current_user.role not in (UserRole.SUPER_ADMIN, UserRole.MANAGER):
        raise HTTPException(403, "دسترسی ندارید")
    current_user.stamp_data = None
    await current_user.save()
    return {"message": "مهر حذف شد"}


@router.post("/{user_id}/reset-password", dependencies=[Depends(require_super_admin)])
async def admin_reset_password(user_id: str, new_password: str):
    user = await User.get(PydanticObjectId(user_id))
    if not user:
        raise NotFoundError("کاربر یافت نشد")
    user.hashed_password = hash_password(new_password)
    await user.save()
    return {"message": "رمز عبور تغییر کرد"}
