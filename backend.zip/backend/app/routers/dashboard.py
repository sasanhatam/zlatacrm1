from fastapi import APIRouter, Depends, Query, Response
from typing import Optional
from datetime import datetime, timezone, timedelta
from beanie import PydanticObjectId
from beanie.operators import NotIn
from app.core.permissions import require_manager, require_member
from app.deps import get_current_user
from app.models.user import User, Team
from app.models.task import Task, TaskStatus
import structlog

logger = structlog.get_logger()
router = APIRouter(prefix="/dashboard", tags=["dashboard"])


async def _task_stats(filters: list) -> dict:
    all_tasks = await Task.find(*filters).to_list() if filters else await Task.find().to_list()
    now = datetime.now(timezone.utc)
    stats = {"total": len(all_tasks), "todo": 0, "in_progress": 0,
             "in_review": 0, "done": 0, "blocked": 0, "overdue": 0}
    for t in all_tasks:
        stats[t.status] = stats.get(t.status, 0) + 1
        if t.due_date and t.due_date.replace(tzinfo=timezone.utc) < now and t.status not in (TaskStatus.DONE, TaskStatus.BLOCKED):
            stats["overdue"] += 1
    return stats


@router.get("/overview", dependencies=[Depends(require_member)])
async def overview(
    team_id: Optional[str] = Query(None),
    user_id: Optional[str] = Query(None),
    from_date: Optional[datetime] = Query(None),
    to_date: Optional[datetime] = Query(None),
    current_user: User = Depends(get_current_user),
):
    filters = []
    if team_id:
        filters.append(Task.team_id == PydanticObjectId(team_id))
    if user_id:
        filters.append(Task.assignee_id == PydanticObjectId(user_id))
    if from_date:
        filters.append(Task.created_at >= from_date)
    if to_date:
        filters.append(Task.created_at <= to_date)

    task_stats = await _task_stats(filters)

    # تسک‌های راکد
    stale_days = 7
    stale_threshold = datetime.now(timezone.utc) - timedelta(days=stale_days)
    stale_filters = [
        Task.last_activity_at < stale_threshold,
        NotIn(Task.status, [TaskStatus.DONE, TaskStatus.BLOCKED]),
    ]
    stale_count = await Task.find(*stale_filters).count()

    # آمار تیم‌ها
    teams = await Team.find(Team.is_active == True).to_list()
    team_stats = []
    for team in teams:
        tf = [Task.team_id == team.id]
        if filters:
            tf.extend(filters)
        ts = await _task_stats(tf)
        team_stats.append({
            "team_id": str(team.id),
            "team_name": team.name,
            "task_stats": ts,
            "member_count": len(team.member_ids),
        })

    return {
        "task_stats": task_stats,
        "team_stats": team_stats,
        "stale_tasks_count": stale_count,
        "overdue_tasks_count": task_stats["overdue"],
    }


@router.get("/user-performance", dependencies=[Depends(require_manager)])
async def user_performance(
    team_id: Optional[str] = Query(None),
    from_date: Optional[datetime] = Query(None),
    to_date: Optional[datetime] = Query(None),
):
    filters = []
    if team_id:
        tid = PydanticObjectId(team_id)
        team = await Team.get(tid)
        if not team:
            return []
        user_ids = team.member_ids
    else:
        users_all = await User.find(User.is_active == True).to_list()
        user_ids = [u.id for u in users_all]

    if from_date:
        filters.append(Task.created_at >= from_date)
    if to_date:
        filters.append(Task.created_at <= to_date)

    result = []
    now = datetime.now(timezone.utc)

    for uid in user_ids:
        user = await User.get(uid)
        if not user:
            continue
        ufilters = [Task.assignee_id == uid] + filters
        tasks = await Task.find(*ufilters).to_list()
        total = len(tasks)
        done = [t for t in tasks if t.status == TaskStatus.DONE]
        overdue = [t for t in tasks if t.due_date and
                   t.due_date.replace(tzinfo=timezone.utc) < now and
                   t.status != TaskStatus.DONE]
        on_time = [t for t in done if t.delay_hours is not None and t.delay_hours <= 0]
        delays = [t.delay_hours for t in done if t.delay_hours is not None and t.delay_hours > 0]
        avg_delay = sum(delays) / len(delays) if delays else None
        completion_rate = (len(done) / total * 100) if total > 0 else 0.0

        result.append({
            "user_id": str(uid),
            "full_name": user.full_name,
            "total_assigned": total,
            "completed": len(done),
            "on_time": len(on_time),
            "overdue": len(overdue),
            "avg_delay_hours": round(avg_delay, 2) if avg_delay else None,
            "completion_rate": round(completion_rate, 1),
        })

    return sorted(result, key=lambda x: x["completion_rate"], reverse=True)


@router.get("/stale-tasks", dependencies=[Depends(require_manager)])
async def stale_tasks(days: int = Query(7, ge=1, le=90)):
    threshold = datetime.now(timezone.utc) - timedelta(days=days)
    tasks = await Task.find(
        Task.last_activity_at < threshold,
        NotIn(Task.status, [TaskStatus.DONE, TaskStatus.BLOCKED]),
    ).sort("last_activity_at").to_list()
    return [{
        "id": str(t.id), "title": t.title, "status": t.status,
        "assignee_id": str(t.assignee_id) if t.assignee_id else None,
        "last_activity_at": t.last_activity_at,
        "due_date": t.due_date,
        "days_inactive": (datetime.now(timezone.utc) - t.last_activity_at.replace(tzinfo=timezone.utc)).days,
    } for t in tasks]


@router.get("/export/excel", dependencies=[Depends(require_manager)])
async def export_excel(
    team_id: Optional[str] = Query(None),
    from_date: Optional[datetime] = Query(None),
    to_date: Optional[datetime] = Query(None),
):
    import openpyxl
    from io import BytesIO
    import jdatetime

    filters = []
    if team_id:
        filters.append(Task.team_id == PydanticObjectId(team_id))
    if from_date:
        filters.append(Task.created_at >= from_date)
    if to_date:
        filters.append(Task.created_at <= to_date)

    tasks = await Task.find(*filters).sort("-created_at").to_list()

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Tasks"
    ws.sheet_view.rightToLeft = True

    headers = ["عنوان", "وضعیت", "اولویت", "تیم", "مسئول", "ددلاین", "تاریخ ایجاد", "تاخیر (ساعت)"]
    for col, h in enumerate(headers, 1):
        ws.cell(row=1, column=col, value=h)

    for row_idx, task in enumerate(tasks, 2):
        def jdate(dt):
            if not dt:
                return ""
            dt = dt.replace(tzinfo=timezone.utc) if dt.tzinfo is None else dt
            return jdatetime.datetime.fromgregorian(datetime=dt).strftime("%Y/%m/%d")

        ws.cell(row=row_idx, column=1, value=task.title)
        ws.cell(row=row_idx, column=2, value=task.status)
        ws.cell(row=row_idx, column=3, value=task.priority)
        ws.cell(row=row_idx, column=4, value=str(task.team_id))
        ws.cell(row=row_idx, column=5, value=str(task.assignee_id) if task.assignee_id else "")
        ws.cell(row=row_idx, column=6, value=jdate(task.due_date))
        ws.cell(row=row_idx, column=7, value=jdate(task.created_at))
        ws.cell(row=row_idx, column=8, value=task.delay_hours or 0)

    buffer = BytesIO()
    wb.save(buffer)
    buffer.seek(0)
    return Response(
        content=buffer.read(),
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": "attachment; filename=tasks.xlsx"},
    )
