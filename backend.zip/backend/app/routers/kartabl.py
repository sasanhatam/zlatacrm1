from fastapi import APIRouter, Depends, Query
from typing import Optional, List
from datetime import datetime, timezone
from beanie import PydanticObjectId

from app.models.user import User
from app.models.task import Task, TaskStatus
from app.models.letter import OfficialLetter, LetterReferral
from app.core.permissions import require_member, require_manager
from app.deps import get_current_user

router = APIRouter(prefix="/api/kartabl", tags=["kartabl"])


def _jalali_approx(dt: Optional[datetime]) -> str:
    """Simple Jalali approximation — good enough for display."""
    if not dt:
        return ""
    # Use isoformat; real Jalali conversion is done on frontend
    return dt.isoformat()


@router.get("")
async def get_kartabl(
    type: str = Query("all", description="all|tasks|letters|referrals"),
    sort: str = Query("date", description="date|priority|status"),
    status: str = Query("all", description="all|pending|done"),
    company_id: Optional[str] = Query(None),
    current_user: User = Depends(require_member),
):
    me_id = current_user.id
    items: List[dict] = []

    # --- Tasks ---
    if type in ("all", "tasks"):
        task_query = Task.find(
            {
                "$and": [
                    {"is_archived": {"$ne": True}},
                    {
                        "$or": [
                            {"assignee_id": me_id},
                            {"assignee_ids": me_id},
                            {"created_by": me_id},
                        ]
                    },
                ]
            }
        )
        tasks = await task_query.to_list()
        now_naive = datetime.utcnow()
        for t in tasks:
            is_done = t.status == TaskStatus.DONE
            if status == "pending" and is_done:
                continue
            if status == "done" and not is_done:
                continue
            due = t.due_date
            due_cmp = due.replace(tzinfo=None) if due and due.tzinfo else due
            is_overdue = bool(due_cmp and due_cmp < now_naive and not is_done)
            items.append({
                "id": str(t.id),
                "item_type": "task",
                "title": t.title,
                "priority": t.priority.value if hasattr(t.priority, "value") else str(t.priority),
                "status": t.status.value if hasattr(t.status, "value") else str(t.status),
                "date": t.created_at.isoformat(),
                "jalali_date": _jalali_approx(t.created_at),
                "is_read": True,
                "sender_name": "",
                "due_date": due.isoformat() if due else None,
                "is_overdue": is_overdue,
                "company_id": None,
            })

    # --- Letters (inbox) ---
    if type in ("all", "letters"):
        letters = await OfficialLetter.find(
            OfficialLetter.recipient_user_id == me_id
        ).to_list()
        for ltr in letters:
            is_sent = ltr.status.value in ("sent", "approved", "archived") if hasattr(ltr.status, "value") else ltr.status in ("sent", "approved", "archived")
            if status == "pending" and not is_sent:
                pass  # pending means unread/unprocessed - include
            elif status == "done" and is_sent:
                pass
            elif status == "pending" and is_sent:
                continue
            elif status == "done" and not is_sent:
                continue
            items.append({
                "id": str(ltr.id),
                "item_type": "letter",
                "title": ltr.subject,
                "priority": ltr.priority.value if hasattr(ltr.priority, "value") else str(ltr.priority),
                "status": ltr.status.value if hasattr(ltr.status, "value") else str(ltr.status),
                "date": ltr.created_at.isoformat(),
                "jalali_date": ltr.jalali_date or _jalali_approx(ltr.created_at),
                "is_read": ltr.status.value not in ("draft", "pending") if hasattr(ltr.status, "value") else True,
                "sender_name": "",
                "due_date": None,
                "is_overdue": False,
                "company_id": None,
            })

    # --- Referrals ---
    if type in ("all", "referrals"):
        referrals = await LetterReferral.find(
            LetterReferral.to_user_id == me_id
        ).to_list()
        for ref in referrals:
            is_read = ref.is_read
            if status == "done" and not is_read:
                continue
            if status == "pending" and is_read:
                continue
            # Get letter for title
            try:
                ltr = await OfficialLetter.get(ref.letter_id)
                title = ltr.subject if ltr else "ارجاع نامه"
            except Exception:
                title = "ارجاع نامه"
            items.append({
                "id": str(ref.id),
                "item_type": "referral",
                "title": title,
                "priority": "normal",
                "status": "read" if ref.is_read else "unread",
                "date": ref.created_at.isoformat(),
                "jalali_date": _jalali_approx(ref.created_at),
                "is_read": ref.is_read,
                "sender_name": "",
                "due_date": ref.deadline.isoformat() if ref.deadline else None,
                "is_overdue": bool(ref.deadline and (ref.deadline.replace(tzinfo=None) if ref.deadline.tzinfo else ref.deadline) < datetime.utcnow() and not ref.is_read),
                "company_id": None,
                "letter_id": str(ref.letter_id),
            })

    # --- Sort ---
    priority_order = {"urgent": 0, "high": 1, "medium": 2, "normal": 2, "low": 3}
    if sort == "priority":
        items.sort(key=lambda x: priority_order.get(x.get("priority", "normal"), 2))
    elif sort == "status":
        items.sort(key=lambda x: x.get("status", ""))
    else:  # date (default)
        items.sort(key=lambda x: x.get("date", ""), reverse=True)

    # --- Counts ---
    all_tasks = [i for i in items if i["item_type"] == "task"]
    all_letters = [i for i in items if i["item_type"] == "letter"]
    all_referrals = [i for i in items if i["item_type"] == "referral"]
    unread = [i for i in items if not i.get("is_read", True)]
    overdue = [i for i in items if i.get("is_overdue", False)]

    return {
        "items": items,
        "counts": {
            "total": len(items),
            "tasks": len(all_tasks),
            "letters": len(all_letters),
            "referrals": len(all_referrals),
            "unread": len(unread),
            "overdue": len(overdue),
        },
    }


@router.get("/search")
async def global_search(
    q: str = Query(..., min_length=1),
    limit: int = Query(20, le=50),
    current_user: User = Depends(require_member),
):
    if not q or not q.strip():
        return {"tasks": [], "letters": [], "users": []}

    q_strip = q.strip()
    results_tasks: List[dict] = []
    results_letters: List[dict] = []
    results_users: List[dict] = []

    # Search tasks
    tasks = await Task.find(
        {
            "$and": [
                {"is_archived": {"$ne": True}},
                {
                    "$or": [
                        {"title": {"$regex": q_strip, "$options": "i"}},
                        {"description": {"$regex": q_strip, "$options": "i"}},
                    ]
                },
            ]
        }
    ).limit(limit).to_list()
    for t in tasks:
        results_tasks.append({
            "id": str(t.id),
            "title": t.title,
            "status": t.status.value if hasattr(t.status, "value") else str(t.status),
            "priority": t.priority.value if hasattr(t.priority, "value") else str(t.priority),
        })

    # Search letters
    letters = await OfficialLetter.find(
        {
            "$or": [
                {"subject": {"$regex": q_strip, "$options": "i"}},
                {"letter_number": {"$regex": q_strip, "$options": "i"}},
            ]
        }
    ).limit(limit).to_list()
    for ltr in letters:
        results_letters.append({
            "id": str(ltr.id),
            "subject": ltr.subject,
            "letter_number": ltr.letter_number,
            "status": ltr.status.value if hasattr(ltr.status, "value") else str(ltr.status),
        })

    # Search users (managers and above only)
    from app.models.user import UserRole
    is_manager = current_user.role in (UserRole.SUPER_ADMIN.value, UserRole.MANAGER.value)
    if is_manager:
        users = await User.find(
            {
                "$or": [
                    {"full_name": {"$regex": q_strip, "$options": "i"}},
                    {"email": {"$regex": q_strip, "$options": "i"}},
                ]
            }
        ).limit(limit).to_list()
        for u in users:
            results_users.append({
                "id": str(u.id),
                "full_name": u.full_name,
                "email": u.email,
                "role": u.role,
            })

    return {
        "tasks": results_tasks,
        "letters": results_letters,
        "users": results_users,
    }


@router.get("/counts")
async def get_me_counts(current_user: User = Depends(require_member)):
    me_id = current_user.id
    now = datetime.now(timezone.utc)

    # Tasks pending (not done/archived assigned to me)
    tasks_pending_count = await Task.find(
        {
            "$and": [
                {"is_archived": {"$ne": True}},
                {"status": {"$nin": ["done"]}},
                {
                    "$or": [
                        {"assignee_id": me_id},
                        {"assignee_ids": me_id},
                    ]
                },
            ]
        }
    ).count()

    # Tasks overdue
    tasks_overdue_count = await Task.find(
        {
            "$and": [
                {"is_archived": {"$ne": True}},
                {"status": {"$nin": ["done"]}},
                {"due_date": {"$lt": now}},
                {
                    "$or": [
                        {"assignee_id": me_id},
                        {"assignee_ids": me_id},
                    ]
                },
            ]
        }
    ).count()

    # Letters inbox (unread / pending)
    letters_inbox_count = await OfficialLetter.find(
        {
            "$and": [
                {"recipient_user_id": me_id},
                {"status": {"$in": ["draft", "pending", "approved"]}},
            ]
        }
    ).count()

    # Referrals unread
    referrals_unread = await LetterReferral.find(
        {"to_user_id": me_id, "is_read": False}
    ).count()

    # Kartabl pending = tasks pending + letters inbox + referrals unread
    kartabl_pending = tasks_pending_count + letters_inbox_count + referrals_unread

    return {
        "kartabl_pending": kartabl_pending,
        "kartabl_unread": referrals_unread + letters_inbox_count,
        "letters_inbox": letters_inbox_count,
        "letters_referrals": referrals_unread,
        "tasks_overdue": tasks_overdue_count,
        "tasks_pending": tasks_pending_count,
    }
