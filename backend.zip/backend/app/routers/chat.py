from fastapi import APIRouter, Depends, WebSocket, WebSocketDisconnect, Query, UploadFile, File
from typing import List, Optional
from datetime import datetime, timezone
from beanie import PydanticObjectId
from app.schemas.chat import RoomCreate, RoomResponse, MessageCreate, MessageResponse
from app.models.chat import ChatRoom, Message, RoomType, MessageType
from app.models.notification import Notification, NotificationType
from app.core.permissions import require_member
from app.core.exceptions import NotFoundError, AuthorizationError
from app.core.security import decode_access_token
from app.deps import get_current_user
from app.models.user import User
from app.websocket.manager import manager
from app.services.file_service import upload_file
import structlog

logger = structlog.get_logger()
router = APIRouter(prefix="/chat", tags=["chat"])


def _room_dict(room: ChatRoom) -> dict:
    return {
        "id": str(room.id),
        "name": room.name,
        "type": room.type,
        "member_ids": [str(m) for m in room.member_ids],
        "admin_ids": [str(a) for a in room.admin_ids],
        "last_message_at": room.last_message_at,
        "last_message_preview": room.last_message_preview,
        "created_at": room.created_at,
    }


def _msg_dict(msg: Message) -> dict:
    return {
        "id": str(msg.id),
        "room_id": str(msg.room_id),
        "sender_id": str(msg.sender_id),
        "type": msg.type,
        "content": msg.content,
        "file_id": str(msg.file_id) if msg.file_id else None,
        "mentioned_user_ids": [str(m) for m in msg.mentioned_user_ids],
        "read_by": {k: v.isoformat() for k, v in msg.read_by.items()},
        "is_deleted": msg.is_deleted,
        "created_at": msg.created_at.isoformat(),
    }


@router.get("/rooms", dependencies=[Depends(require_member)])
async def list_my_rooms(current_user: User = Depends(get_current_user)):
    rooms = await ChatRoom.find(
        ChatRoom.member_ids == current_user.id,
        ChatRoom.is_active == True,
    ).sort("-last_message_at").to_list()
    return [_room_dict(r) for r in rooms]


@router.post("/rooms", dependencies=[Depends(require_member)])
async def create_room(data: RoomCreate, current_user: User = Depends(get_current_user)):
    member_ids = [PydanticObjectId(m) for m in data.member_ids]
    if current_user.id not in member_ids:
        member_ids.insert(0, current_user.id)

    # Direct: اگر قبلاً وجود دارد برگردان
    if data.type == RoomType.DIRECT and len(member_ids) == 2:
        existing = await ChatRoom.find_one(
            ChatRoom.type == RoomType.DIRECT,
            ChatRoom.member_ids == member_ids[0],
            ChatRoom.member_ids == member_ids[1],
        )
        if existing:
            return _room_dict(existing)

    room = ChatRoom(
        name=data.name,
        type=data.type,
        member_ids=member_ids,
        admin_ids=[current_user.id],
        created_by=current_user.id,
    )
    await room.insert()
    return _room_dict(room)


@router.get("/rooms/{room_id}/messages", dependencies=[Depends(require_member)])
async def get_messages(
    room_id: str,
    before: Optional[datetime] = Query(None),
    limit: int = Query(50, le=100),
    current_user: User = Depends(get_current_user),
):
    room = await ChatRoom.get(PydanticObjectId(room_id))
    if not room or current_user.id not in room.member_ids:
        raise AuthorizationError("دسترسی مجاز نیست")

    filters = [Message.room_id == room.id, Message.is_deleted == False]
    if before:
        filters.append(Message.created_at < before)

    messages = await Message.find(*filters).sort("-created_at").limit(limit).to_list()
    return [_msg_dict(m) for m in reversed(messages)]


@router.post("/rooms/{room_id}/messages", dependencies=[Depends(require_member)])
async def send_message(
    room_id: str,
    data: MessageCreate,
    current_user: User = Depends(get_current_user),
):
    room = await ChatRoom.get(PydanticObjectId(room_id))
    if not room or current_user.id not in room.member_ids:
        raise AuthorizationError("دسترسی مجاز نیست")

    msg_type = MessageType.TEXT
    if data.file_id:
        from app.models.file import FileMetadata
        fm = await FileMetadata.get(PydanticObjectId(data.file_id))
        msg_type = MessageType.IMAGE if (fm and fm.is_image) else MessageType.FILE

    msg = Message(
        room_id=room.id,
        sender_id=current_user.id,
        type=msg_type,
        content=data.content,
        file_id=PydanticObjectId(data.file_id) if data.file_id else None,
        mentioned_user_ids=[PydanticObjectId(u) for u in data.mentioned_user_ids],
    )
    await msg.insert()

    room.last_message_at = msg.created_at
    room.last_message_preview = (data.content or "📎 فایل")[:60]
    await room.save()

    msg_data = _msg_dict(msg)
    await manager.broadcast_to_room(room_id, {"type": "message", "data": msg_data})

    # نوتیف به اعضا
    for uid in room.member_ids:
        if uid != current_user.id:
            await manager.send_to_user(str(uid), {
                "type": "room_update",
                "data": {"room_id": room_id, "preview": room.last_message_preview},
            })

    return msg_data


@router.post("/rooms/{room_id}/files", dependencies=[Depends(require_member)])
async def upload_chat_file(
    room_id: str,
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user),
):
    room = await ChatRoom.get(PydanticObjectId(room_id))
    if not room or current_user.id not in room.member_ids:
        raise AuthorizationError("دسترسی مجاز نیست")
    meta = await upload_file(file, current_user, folder=f"chat/{room_id}")
    return {"file_id": str(meta.id), "name": meta.original_name,
            "is_image": meta.is_image, "size": meta.size_bytes}


@router.post("/rooms/{room_id}/read", dependencies=[Depends(require_member)])
async def mark_as_read(room_id: str, current_user: User = Depends(get_current_user)):
    now = datetime.now(timezone.utc)
    uid_str = str(current_user.id)
    unread = await Message.find(
        Message.room_id == PydanticObjectId(room_id),
        Message.sender_id != current_user.id,
    ).to_list()
    for msg in unread:
        if uid_str not in msg.read_by:
            msg.read_by[uid_str] = now
            await msg.save()
    return {"marked": len(unread)}


# ─── WebSocket ────────────────────────────────────────────────────────────────

@router.websocket("/ws/{room_id}")
async def websocket_chat(websocket: WebSocket, room_id: str, token: str = Query(...)):
    payload = decode_access_token(token)
    if not payload:
        await websocket.close(code=4001)
        return

    user = await User.get(PydanticObjectId(payload["sub"]))
    if not user:
        await websocket.close(code=4001)
        return

    room = await ChatRoom.get(PydanticObjectId(room_id))
    if not room or user.id not in room.member_ids:
        await websocket.close(code=4003)
        return

    await manager.connect_room(websocket, room_id, str(user.id))
    await manager.broadcast_to_room(room_id, {
        "type": "presence", "data": {"user_id": str(user.id), "online": True}
    })

    try:
        while True:
            data = await websocket.receive_json()
            # typing indicator
            if data.get("type") == "typing":
                await manager.broadcast_to_room(room_id, {
                    "type": "typing",
                    "data": {"user_id": str(user.id), "is_typing": data.get("is_typing", False)},
                }, exclude=websocket)
    except WebSocketDisconnect:
        manager.disconnect_room(websocket, room_id, str(user.id))
        await manager.broadcast_to_room(room_id, {
            "type": "presence", "data": {"user_id": str(user.id), "online": False}
        })
