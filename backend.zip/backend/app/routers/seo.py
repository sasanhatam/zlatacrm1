from fastapi import APIRouter, HTTPException, Depends, UploadFile, File
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime, timezone
from beanie import PydanticObjectId
import base64

from app.models.seo import SEOContent, SEOStatus
from app.models.user import User
from app.core.deps import get_current_user

router = APIRouter(prefix="/api/seo", tags=["seo"])


class SEOCreate(BaseModel):
    title: str
    keyword: str = ""
    url: str = ""
    anchor_text: str = ""
    body_html: str = ""
    seo_title: str = ""
    meta_description: str = ""
    internal_link_text: str = ""
    schema_code: str = ""
    status: SEOStatus = SEOStatus.DRAFT
    assignee_id: Optional[str] = None
    publish_date: Optional[datetime] = None


class SEOUpdate(BaseModel):
    title: Optional[str] = None
    keyword: Optional[str] = None
    url: Optional[str] = None
    anchor_text: Optional[str] = None
    body_html: Optional[str] = None
    seo_title: Optional[str] = None
    meta_description: Optional[str] = None
    internal_link_text: Optional[str] = None
    schema_code: Optional[str] = None
    status: Optional[SEOStatus] = None
    assignee_id: Optional[str] = None
    publish_date: Optional[datetime] = None


def _to_dict(c: SEOContent) -> dict:
    return {
        "id": str(c.id),
        "title": c.title,
        "keyword": c.keyword,
        "url": c.url,
        "anchor_text": c.anchor_text,
        "body_html": c.body_html,
        "seo_title": c.seo_title,
        "meta_description": c.meta_description,
        "internal_link_text": c.internal_link_text,
        "status": c.status,
        "assignee_id": str(c.assignee_id) if c.assignee_id else None,
        "created_by": str(c.created_by),
        "publish_date": c.publish_date,
        "featured_image_data": c.featured_image_data,
        "extra_image_data": c.extra_image_data,
        "schema_code": c.schema_code,
        "created_at": c.created_at,
        "updated_at": c.updated_at,
    }


@router.get("")
async def list_seo(me: User = Depends(get_current_user)):
    items = await SEOContent.find_all().to_list()
    return [_to_dict(i) for i in items]


@router.post("")
async def create_seo(data: SEOCreate, me: User = Depends(get_current_user)):
    item = SEOContent(
        title=data.title,
        keyword=data.keyword,
        url=data.url,
        anchor_text=data.anchor_text,
        body_html=data.body_html,
        seo_title=data.seo_title,
        meta_description=data.meta_description,
        internal_link_text=data.internal_link_text,
        schema_code=data.schema_code,
        status=data.status,
        assignee_id=PydanticObjectId(data.assignee_id) if data.assignee_id else None,
        created_by=me.id,
        publish_date=data.publish_date,
    )
    await item.insert()
    return _to_dict(item)


@router.get("/{item_id}")
async def get_seo(item_id: str, me: User = Depends(get_current_user)):
    item = await SEOContent.get(item_id)
    if not item:
        raise HTTPException(404, "محتوا یافت نشد")
    return _to_dict(item)


@router.put("/{item_id}")
async def update_seo(item_id: str, data: SEOUpdate, me: User = Depends(get_current_user)):
    item = await SEOContent.get(item_id)
    if not item:
        raise HTTPException(404, "محتوا یافت نشد")
    for field, val in data.model_dump(exclude_none=True).items():
        if field == "assignee_id":
            setattr(item, field, PydanticObjectId(val) if val else None)
        else:
            setattr(item, field, val)
    item.updated_at = datetime.now(timezone.utc)
    await item.save()
    return _to_dict(item)


@router.delete("/{item_id}")
async def delete_seo(item_id: str, me: User = Depends(get_current_user)):
    item = await SEOContent.get(item_id)
    if not item:
        raise HTTPException(404, "محتوا یافت نشد")
    await item.delete()
    return {"ok": True}


@router.post("/{item_id}/featured-image")
async def upload_featured_image(
    item_id: str, file: UploadFile = File(...), me: User = Depends(get_current_user)
):
    item = await SEOContent.get(item_id)
    if not item:
        raise HTTPException(404, "محتوا یافت نشد")
    data = await file.read()
    b64 = f"data:{file.content_type};base64,{base64.b64encode(data).decode()}"
    item.featured_image_data = b64
    item.updated_at = datetime.now(timezone.utc)
    await item.save()
    return {"featured_image_data": b64}


@router.post("/{item_id}/extra-images")
async def upload_extra_images(
    item_id: str, files: List[UploadFile] = File(...), me: User = Depends(get_current_user)
):
    item = await SEOContent.get(item_id)
    if not item:
        raise HTTPException(404, "محتوا یافت نشد")
    for f in files:
        data = await f.read()
        b64 = f"data:{f.content_type};base64,{base64.b64encode(data).decode()}"
        item.extra_image_data.append(b64)
    item.updated_at = datetime.now(timezone.utc)
    await item.save()
    return {"extra_image_data": item.extra_image_data}
