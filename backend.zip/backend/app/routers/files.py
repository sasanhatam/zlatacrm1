from fastapi import APIRouter, Depends, UploadFile, File as FastAPIFile, Response
from beanie import PydanticObjectId
from pathlib import Path
from app.models.file import FileMetadata
from app.core.permissions import require_member
from app.core.exceptions import NotFoundError
from app.deps import get_current_user
from app.models.user import User
from app.services.file_service import upload_file, get_file_url
from app.storage import storage
from app.config import settings
import aiofiles

router = APIRouter(prefix="/files", tags=["files"])


@router.post("/upload", dependencies=[Depends(require_member)])
async def upload(
    file: UploadFile = FastAPIFile(...),
    folder: str = "uploads",
    current_user: User = Depends(get_current_user),
):
    meta = await upload_file(file, current_user, folder=folder)
    url = await get_file_url(meta)
    return {
        "file_id": str(meta.id),
        "name": meta.original_name,
        "url": url,
        "size": meta.size_bytes,
        "content_type": meta.content_type,
        "is_image": meta.is_image,
    }


@router.get("/{file_id}/url", dependencies=[Depends(require_member)])
async def get_url(file_id: str):
    meta = await FileMetadata.get(PydanticObjectId(file_id))
    if not meta:
        raise NotFoundError("فایل یافت نشد")
    url = await get_file_url(meta)
    return {"url": url, "name": meta.original_name, "is_image": meta.is_image}


@router.get("/download/{key:path}", dependencies=[Depends(require_member)])
async def download_local(key: str):
    """Local storage direct download endpoint."""
    if settings.STORAGE_BACKEND != "local":
        raise NotFoundError("فایل یافت نشد")

    meta = await FileMetadata.find_one(FileMetadata.storage_key == key)
    if not meta:
        raise NotFoundError("فایل یافت نشد")

    from app.storage.local_provider import LocalStorageProvider
    local = LocalStorageProvider()
    file_path = local.get_local_path(key)

    if not file_path.exists():
        raise NotFoundError("فایل روی دیسک یافت نشد")

    async with aiofiles.open(file_path, "rb") as f:
        data = await f.read()

    return Response(
        content=data,
        media_type=meta.content_type,
        headers={"Content-Disposition": f'attachment; filename="{meta.original_name}"'},
    )
