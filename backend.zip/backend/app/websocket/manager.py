from typing import Dict, Set
from fastapi import WebSocket
import json
import structlog

logger = structlog.get_logger()


class ConnectionManager:
    def __init__(self):
        # room_id -> set of WebSockets
        self._rooms: Dict[str, Set[WebSocket]] = {}
        # user_id -> set of WebSockets (for personal notifications)
        self._users: Dict[str, Set[WebSocket]] = {}

    async def connect_room(self, ws: WebSocket, room_id: str, user_id: str):
        await ws.accept()
        self._rooms.setdefault(room_id, set()).add(ws)
        self._users.setdefault(user_id, set()).add(ws)

    def disconnect_room(self, ws: WebSocket, room_id: str, user_id: str):
        self._rooms.get(room_id, set()).discard(ws)
        self._users.get(user_id, set()).discard(ws)

    async def connect_user(self, ws: WebSocket, user_id: str):
        await ws.accept()
        self._users.setdefault(user_id, set()).add(ws)

    def disconnect_user(self, ws: WebSocket, user_id: str):
        self._users.get(user_id, set()).discard(ws)

    async def broadcast_to_room(self, room_id: str, data: dict, exclude: WebSocket = None):
        dead = set()
        for ws in list(self._rooms.get(room_id, set())):
            if ws is exclude:
                continue
            try:
                await ws.send_json(data)
            except Exception:
                dead.add(ws)
        self._rooms[room_id] = self._rooms.get(room_id, set()) - dead

    async def send_to_user(self, user_id: str, data: dict):
        dead = set()
        for ws in list(self._users.get(user_id, set())):
            try:
                await ws.send_json(data)
            except Exception:
                dead.add(ws)
        self._users[user_id] = self._users.get(user_id, set()) - dead

    def is_online(self, user_id: str) -> bool:
        return bool(self._users.get(user_id))


manager = ConnectionManager()
