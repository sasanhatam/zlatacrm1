from beanie import init_beanie
from app.config import settings
import structlog
import os

logger = structlog.get_logger()
client = None


async def connect_db():
    global client

    use_mock = os.environ.get("USE_MONGOMOCK", "false").lower() == "true"

    if use_mock:
        # حالت dev بدون MongoDB واقعی
        from mongomock_motor import AsyncMongoMockClient
        client = AsyncMongoMockClient()
        logger.info("database_connected_mock")
    else:
        from motor.motor_asyncio import AsyncIOMotorClient
        client = AsyncIOMotorClient(settings.MONGO_URL)
        logger.info("database_connected", db=settings.MONGO_DB)

    from app.models.user import User, Team, Organization, RegistrationRequest
    from app.models.task import Task, TaskAuditLog, SubTask, TaskComment, TaskReferral
    from app.models.chat import ChatRoom, Message
    from app.models.notification import Notification, Announcement
    from app.models.letter import OfficialLetter, LetterCounter, LetterReferral, LetterComment
    from app.models.file import FileMetadata
    from app.models.system import SystemSettings, PushSubscription, RefreshToken
    from app.models.meeting import Meeting, MeetingMinutes
    from app.models.leave import LeaveRequest, LeaveBalance
    from app.models.seo import SEOContent
    from app.models.activity_log import ActivityLog
    from app.models.attendance import AttendanceRecord

    await init_beanie(
        database=client[settings.MONGO_DB],
        document_models=[
            User, Team, Organization, RegistrationRequest,
            Task, TaskAuditLog, SubTask, TaskComment, TaskReferral,
            ChatRoom, Message,
            Notification, Announcement,
            OfficialLetter, LetterCounter, LetterReferral, LetterComment,
            FileMetadata,
            SystemSettings, PushSubscription, RefreshToken,
            Meeting, MeetingMinutes,
            LeaveRequest, LeaveBalance,
            SEOContent,
            ActivityLog,
            AttendanceRecord,
        ],
    )


async def disconnect_db():
    global client
    if client:
        client.close()
