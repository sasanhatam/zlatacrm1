from app.models.letter import OfficialLetter
from app.models.system import SystemSettings
import jdatetime
from datetime import timezone


async def generate_letter_pdf(letter: OfficialLetter) -> bytes:
    settings_doc = await SystemSettings.find_one()
    org_name = settings_doc.org_name if settings_doc else "Zlata Management"
    org_address = settings_doc.org_address if settings_doc else ""
    org_phone = settings_doc.org_phone if settings_doc else ""

    jalali_date = letter.jalali_date or jdatetime.date.today().strftime("%Y/%m/%d")
    letter_type_label = "صادره" if letter.letter_type == "outgoing" else "وارده"

    html = f"""<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<style>
  @import url('https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;600;700&display=swap');
  * {{ box-sizing: border-box; margin: 0; padding: 0; }}
  body {{ font-family: 'Vazirmatn', Tahoma, Arial, sans-serif; direction: rtl; color: #222;
         font-size: 13px; line-height: 1.8; padding: 40px; }}
  .letterhead {{ display: flex; justify-content: space-between; align-items: flex-start;
                border-bottom: 3px solid #1e3a5f; padding-bottom: 20px; margin-bottom: 30px; }}
  .org-info {{ text-align: right; }}
  .org-name {{ font-size: 20px; font-weight: 700; color: #1e3a5f; }}
  .org-sub {{ font-size: 11px; color: #666; margin-top: 4px; }}
  .letter-meta {{ text-align: left; font-size: 12px; }}
  .meta-row {{ margin-bottom: 4px; }}
  .meta-label {{ font-weight: 600; color: #1e3a5f; }}
  h2.subject {{ font-size: 16px; color: #1e3a5f; margin: 24px 0 16px; text-align: center; }}
  .body-text {{ text-align: justify; line-height: 2; font-size: 13px; min-height: 200px; }}
  .signature {{ margin-top: 60px; text-align: left; }}
  .signature-name {{ font-weight: 700; font-size: 14px; }}
  .signature-position {{ font-size: 12px; color: #666; }}
  .footer {{ margin-top: 40px; border-top: 1px solid #ccc; padding-top: 12px;
             font-size: 11px; color: #999; text-align: center; }}
</style>
</head>
<body>
<div class="letterhead">
  <div class="org-info">
    <div class="org-name">{org_name}</div>
    <div class="org-sub">{org_address}</div>
    {f'<div class="org-sub">تلفن: {org_phone}</div>' if org_phone else ''}
  </div>
  <div class="letter-meta">
    <div class="meta-row"><span class="meta-label">شماره:</span> {letter.letter_number}</div>
    <div class="meta-row"><span class="meta-label">تاریخ:</span> {jalali_date}</div>
    <div class="meta-row"><span class="meta-label">نوع:</span> نامه {letter_type_label}</div>
  </div>
</div>

<div>
  <div class="meta-row"><span class="meta-label">گیرنده:</span> {letter.recipient_name}
    {f' — {letter.recipient_organization}' if letter.recipient_organization else ''}</div>
</div>

<h2 class="subject">موضوع: {letter.subject}</h2>

<div class="body-text">{letter.body.replace(chr(10), '<br>')}</div>

<div class="signature">
  <div class="signature-name">{letter.signature_name or ''}</div>
  <div class="signature-position">{letter.signature_position or ''}</div>
</div>

<div class="footer">{org_name} — {org_address}</div>
</body>
</html>"""

    try:
        from weasyprint import HTML
        pdf_bytes = HTML(string=html, base_url=None).write_pdf()
        return pdf_bytes
    except Exception:
        # fallback: return HTML as bytes if weasyprint not available
        return html.encode("utf-8")
