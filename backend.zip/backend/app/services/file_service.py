import uuid
import os
from slugify import slugify
from pathlib import Path
from fastapi import UploadFile
from app.models.file import FileMetadata
from app.models.user import User
from app.storage import storage
from app.config import settings
from app.core.exceptions import FileTooLargeError
import structlog

logger = structlog.get_logger()

ALLOWED_TYPES = {
    "image/jpeg", "image/png", "image/gif", "image/webp", "image/svg+xml",
    "application/pdf", "application/msword",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "application/vnd.ms-excel",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "application/zip", "text/plain", "video/mp4", "audio/mpeg",
}

IMAGE_TYPES = {"image/jpeg", "image/png", "image/gif", "image/webp"}

MAX_BYTES = settings.MAX_FILE_SIZE_MB * 1024 * 1024


def sanitize_filename(filename: str) -> str:
    name, ext = os.path.splitext(filename)
    safe_name = slugify(name, allow_unicode=False) or "file"
    safe_ext = ext.lower()[:10]
    return f"{safe_name}{safe_ext}"


async def upload_file(file: UploadFile, uploader: User, folder: str = "uploads") -> FileMetadata:
    data = await file.read()

    if len(data) > MAX_BYTES:
        raise FileTooLargeError(settings.MAX_FILE_SIZE_MB)

    content_type = file.content_type or "application/octet-stream"
    sanitized = sanitize_filename(file.filename or "file")
    unique_key = f"{folder}/{uuid.uuid4().hex}_{sanitized}"

    await storage.upload(unique_key, data, content_type)

    meta = FileMetadata(
        original_name=file.filename or "file",
        sanitized_name=sanitized,
        storage_key=unique_key,
        content_type=content_type,
        size_bytes=len(data),
        uploaded_by=uploader.id,
        storage_backend=settings.STORAGE_BACKEND,
        is_image=content_type in IMAGE_TYPES,
    )
    await meta.insert()
    logger.info("file_uploaded", key=unique_key, size=len(data), user=str(uploader.id))
    return meta


async def get_file_url(file_meta: FileMetadata) -> str:
    return await storage.download_url(file_meta.storage_key)


async def delete_file(file_meta: FileMetadata) -> None:
    await storage.delete(file_meta.storage_key)
    await file_meta.delete()
