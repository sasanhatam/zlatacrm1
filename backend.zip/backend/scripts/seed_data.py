"""اسکریپت ایجاد داده‌های اولیه (seed)
اجرا: python scripts/seed_data.py
"""
import asyncio
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.database import connect_db
from app.models.user import User, Team
from app.models.task import Task, TaskStatus, TaskPriority
from app.models.system import SystemSettings
from app.core.security import hash_password
from datetime import datetime, timezone, timedelta


async def main():
    await connect_db()
    print("✅ اتصال به دیتابیس برقرار شد")

    # پاک کردن داده‌های قبلی (اختیاری)
    # await User.delete_all()

    # ─── Super Admin ───────────────────────────────────────────────
    admin = await User.find_one(User.email == "admin@zlata.ir")
    if not admin:
        admin = User(
            email="admin@zlata.ir",
            hashed_password=hash_password("Admin@12345"),
            full_name="مدیر سیستم",
            role="super_admin",
            position="مدیرعامل",
            notification_email="admin@zlata.ir",
            is_active=True,
        )
        await admin.insert()
        print(f"✅ Super Admin ایجاد شد: admin@zlata.ir / Admin@12345")
    else:
        print("ℹ️  Super Admin از قبل وجود دارد")

    # ─── Users ─────────────────────────────────────────────────────
    users_data = [
        {"email": "manager@zlata.ir", "name": "مدیر پروژه", "role": "manager", "position": "مدیر پروژه"},
        {"email": "lead@zlata.ir", "name": "سرتیم فنی", "role": "team_lead", "position": "سرتیم"},
        {"email": "ali@zlata.ir", "name": "علی احمدی", "role": "member", "position": "برنامه‌نویس"},
        {"email": "sara@zlata.ir", "name": "سارا محمدی", "role": "member", "position": "طراح UI"},
        {"email": "reza@zlata.ir", "name": "رضا کریمی", "role": "member", "position": "تست‌نویس"},
    ]

    created_users = {"admin": admin}
    for ud in users_data:
        u = await User.find_one(User.email == ud["email"])
        if not u:
            u = User(
                email=ud["email"],
                hashed_password=hash_password("Pass@1234"),
                full_name=ud["name"],
                role=ud["role"],
                position=ud["position"],
                notification_email=ud["email"],
                mobile=f"091{hash(ud['email']) % 100000000:08d}"[:11],
                extension_number=str(100 + users_data.index(ud) + 1),
            )
            await u.insert()
            print(f"✅ کاربر ایجاد شد: {ud['email']} / Pass@1234")
        created_users[ud["role"]] = u

    # ─── Teams ─────────────────────────────────────────────────────
    team1 = await Team.find_one(Team.name == "تیم فنی")
    if not team1:
        team1 = Team(
            name="تیم فنی",
            description="تیم توسعه‌دهندگان و برنامه‌نویسان",
            manager_id=created_users["manager"].id,
            lead_id=created_users["team_lead"].id,
            member_ids=[
                created_users["manager"].id,
                created_users["team_lead"].id,
                created_users["member"].id,
            ],
        )
        await team1.insert()
        print("✅ تیم فنی ایجاد شد")

    team2 = await Team.find_one(Team.name == "تیم طراحی")
    if not team2:
        team2 = Team(
            name="تیم طراحی",
            description="طراحان UI/UX",
            manager_id=created_users["manager"].id,
            member_ids=[created_users["manager"].id, created_users["member"].id],
        )
        await team2.insert()
        print("✅ تیم طراحی ایجاد شد")

    # update team_ids on users
    for user_key, team in [("manager", team1), ("team_lead", team1), ("member", team1)]:
        if user_key in created_users:
            u = created_users[user_key]
            if team.id not in u.team_ids:
                u.team_ids.append(team.id)
                await u.save()

    # ─── Tasks ─────────────────────────────────────────────────────
    now = datetime.now(timezone.utc)
    tasks_data = [
        {
            "title": "راه‌اندازی محیط توسعه",
            "description": "نصب Docker، clone مخزن، اجرای docker-compose",
            "priority": TaskPriority.HIGH,
            "status": TaskStatus.DONE,
            "due_date": now - timedelta(days=2),
        },
        {
            "title": "طراحی دیتابیس",
            "description": "مدل‌سازی مجموعه‌های MongoDB برای تسک‌ها و کاربران",
            "priority": TaskPriority.URGENT,
            "status": TaskStatus.IN_PROGRESS,
            "due_date": now + timedelta(days=1),
        },
        {
            "title": "پیاده‌سازی API احراز هویت",
            "description": "اندپوینت‌های لاگین، رفرش توکن و لاگ‌اوت",
            "priority": TaskPriority.HIGH,
            "status": TaskStatus.TODO,
            "due_date": now + timedelta(days=3),
        },
        {
            "title": "طراحی رابط کاربری داشبورد",
            "description": "موکاپ صفحه اصلی در Figma",
            "priority": TaskPriority.MEDIUM,
            "status": TaskStatus.TODO,
            "due_date": now + timedelta(days=5),
        },
        {
            "title": "بررسی تسک‌های معوق",
            "description": "این تسک عمداً بدون ددلاین و معوق است",
            "priority": TaskPriority.LOW,
            "status": TaskStatus.BLOCKED,
            "due_date": now - timedelta(days=10),
        },
    ]

    for td in tasks_data:
        exists = await Task.find_one(Task.title == td["title"])
        if not exists:
            task = Task(
                title=td["title"],
                description=td["description"],
                team_id=team1.id,
                assignee_id=created_users.get("member", admin).id,
                created_by=admin.id,
                priority=td["priority"],
                status=td["status"],
                due_date=td["due_date"],
                tags=["نمونه"],
            )
            if td["status"] == TaskStatus.DONE:
                task.completed_at = now - timedelta(hours=2)
                task.delay_hours = -2.0  # زودتر از موعد
            await task.insert()
            print(f"✅ تسک ایجاد شد: {td['title']}")

    # ─── System Settings ───────────────────────────────────────────
    sys_settings = await SystemSettings.find_one()
    if not sys_settings:
        sys_settings = SystemSettings(
            org_name="Zlata Management",
            org_address="تهران، ایران",
            stale_task_days=7,
        )
        await sys_settings.insert()
        print("✅ تنظیمات سیستم ایجاد شد")

    print("\n🎉 Seed data با موفقیت بارگذاری شد!")
    print("📧 حساب Super Admin: admin@zlata.ir / Admin@12345")
    print("📧 سایر کاربران: رمز عبور Pass@1234")


if __name__ == "__main__":
    asyncio.run(main())
